(function() {
    const a = document.createElement("link").relList;
    if (a && a.supports && a.supports("modulepreload")) return;
    for (const h of document.querySelectorAll('link[rel="modulepreload"]')) r(h);
    new MutationObserver(h => {
        for (const d of h)
            if (d.type === "childList")
                for (const m of d.addedNodes) m.tagName === "LINK" && m.rel === "modulepreload" && r(m)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function l(h) {
        const d = {};
        return h.integrity && (d.integrity = h.integrity), h.referrerPolicy && (d.referrerPolicy = h.referrerPolicy), h.crossOrigin === "use-credentials" ? d.credentials = "include" : h.crossOrigin === "anonymous" ? d.credentials = "omit" : d.credentials = "same-origin", d
    }

    function r(h) {
        if (h.ep) return;
        h.ep = !0;
        const d = l(h);
        fetch(h.href, d)
    }
})();

function wm(s) {
    return s && s.__esModule && Object.prototype.hasOwnProperty.call(s, "default") ? s.default : s
}
var fu = {
        exports: {}
    },
    ns = {};
var Kf;

function uv() {
    if (Kf) return ns;
    Kf = 1;
    var s = Symbol.for("react.transitional.element"),
        a = Symbol.for("react.fragment");

    function l(r, h, d) {
        var m = null;
        if (d !== void 0 && (m = "" + d), h.key !== void 0 && (m = "" + h.key), "key" in h) {
            d = {};
            for (var g in h) g !== "key" && (d[g] = h[g])
        } else d = h;
        return h = d.ref, {
            $$typeof: s,
            type: r,
            key: m,
            ref: h !== void 0 ? h : null,
            props: d
        }
    }
    return ns.Fragment = a, ns.jsx = l, ns.jsxs = l, ns
}
var $f;

function cv() {
    return $f || ($f = 1, fu.exports = uv()), fu.exports
}
var u = cv(),
    mu = {
        exports: {}
    },
    te = {};
var Yf;

function hv() {
    if (Yf) return te;
    Yf = 1;
    var s = Symbol.for("react.transitional.element"),
        a = Symbol.for("react.portal"),
        l = Symbol.for("react.fragment"),
        r = Symbol.for("react.strict_mode"),
        h = Symbol.for("react.profiler"),
        d = Symbol.for("react.consumer"),
        m = Symbol.for("react.context"),
        g = Symbol.for("react.forward_ref"),
        y = Symbol.for("react.suspense"),
        v = Symbol.for("react.memo"),
        _ = Symbol.for("react.lazy"),
        w = Symbol.for("react.activity"),
        E = Symbol.iterator;

    function O(S) {
        return S === null || typeof S != "object" ? null : (S = E && S[E] || S["@@iterator"], typeof S == "function" ? S : null)
    }
    var k = {
            isMounted: function() {
                return !1
            },
            enqueueForceUpdate: function() {},
            enqueueReplaceState: function() {},
            enqueueSetState: function() {}
        },
        B = Object.assign,
        L = {};

    function H(S, M, K) {
        this.props = S, this.context = M, this.refs = L, this.updater = K || k
    }
    H.prototype.isReactComponent = {}, H.prototype.setState = function(S, M) {
        if (typeof S != "object" && typeof S != "function" && S != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, S, M, "setState")
    }, H.prototype.forceUpdate = function(S) {
        this.updater.enqueueForceUpdate(this, S, "forceUpdate")
    };

    function $() {}
    $.prototype = H.prototype;

    function q(S, M, K) {
        this.props = S, this.context = M, this.refs = L, this.updater = K || k
    }
    var I = q.prototype = new $;
    I.constructor = q, B(I, H.prototype), I.isPureReactComponent = !0;
    var ye = Array.isArray;

    function ie() {}
    var J = {
            H: null,
            A: null,
            T: null,
            S: null
        },
        Ne = Object.prototype.hasOwnProperty;

    function Me(S, M, K) {
        var V = K.ref;
        return {
            $$typeof: s,
            type: S,
            key: M,
            ref: V !== void 0 ? V : null,
            props: K
        }
    }

    function da(S, M) {
        return Me(S.type, M, S.props)
    }

    function Ht(S) {
        return typeof S == "object" && S !== null && S.$$typeof === s
    }

    function at(S) {
        var M = {
            "=": "=0",
            ":": "=2"
        };
        return "$" + S.replace(/[=:]/g, function(K) {
            return M[K]
        })
    }
    var Hn = /\/+/g;

    function Vt(S, M) {
        return typeof S == "object" && S !== null && S.key != null ? at("" + S.key) : M.toString(36)
    }

    function Ut(S) {
        switch (S.status) {
            case "fulfilled":
                return S.value;
            case "rejected":
                throw S.reason;
            default:
                switch (typeof S.status == "string" ? S.then(ie, ie) : (S.status = "pending", S.then(function(M) {
                    S.status === "pending" && (S.status = "fulfilled", S.value = M)
                }, function(M) {
                    S.status === "pending" && (S.status = "rejected", S.reason = M)
                })), S.status) {
                    case "fulfilled":
                        return S.value;
                    case "rejected":
                        throw S.reason
                }
        }
        throw S
    }

    function D(S, M, K, V, ne) {
        var le = typeof S;
        (le === "undefined" || le === "boolean") && (S = null);
        var ge = !1;
        if (S === null) ge = !0;
        else switch (le) {
            case "bigint":
            case "string":
            case "number":
                ge = !0;
                break;
            case "object":
                switch (S.$$typeof) {
                    case s:
                    case a:
                        ge = !0;
                        break;
                    case _:
                        return ge = S._init, D(ge(S._payload), M, K, V, ne)
                }
        }
        if (ge) return ne = ne(S), ge = V === "" ? "." + Vt(S, 0) : V, ye(ne) ? (K = "", ge != null && (K = ge.replace(Hn, "$&/") + "/"), D(ne, M, K, "", function(ui) {
            return ui
        })) : ne != null && (Ht(ne) && (ne = da(ne, K + (ne.key == null || S && S.key === ne.key ? "" : ("" + ne.key).replace(Hn, "$&/") + "/") + ge)), M.push(ne)), 1;
        ge = 0;
        var tt = V === "" ? "." : V + ":";
        if (ye(S))
            for (var Ue = 0; Ue < S.length; Ue++) V = S[Ue], le = tt + Vt(V, Ue), ge += D(V, M, K, le, ne);
        else if (Ue = O(S), typeof Ue == "function")
            for (S = Ue.call(S), Ue = 0; !(V = S.next()).done;) V = V.value, le = tt + Vt(V, Ue++), ge += D(V, M, K, le, ne);
        else if (le === "object") {
            if (typeof S.then == "function") return D(Ut(S), M, K, V, ne);
            throw M = String(S), Error("Objects are not valid as a React child (found: " + (M === "[object Object]" ? "object with keys {" + Object.keys(S).join(", ") + "}" : M) + "). If you meant to render a collection of children, use an array instead.")
        }
        return ge
    }

    function G(S, M, K) {
        if (S == null) return S;
        var V = [],
            ne = 0;
        return D(S, V, "", "", function(le) {
            return M.call(K, le, ne++)
        }), V
    }

    function ee(S) {
        if (S._status === -1) {
            var M = S._result;
            M = M(), M.then(function(K) {
                (S._status === 0 || S._status === -1) && (S._status = 1, S._result = K)
            }, function(K) {
                (S._status === 0 || S._status === -1) && (S._status = 2, S._result = K)
            }), S._status === -1 && (S._status = 0, S._result = M)
        }
        if (S._status === 1) return S._result.default;
        throw S._result
    }
    var be = typeof reportError == "function" ? reportError : function(S) {
            if (typeof window == "object" && typeof window.ErrorEvent == "function") {
                var M = new window.ErrorEvent("error", {
                    bubbles: !0,
                    cancelable: !0,
                    message: typeof S == "object" && S !== null && typeof S.message == "string" ? String(S.message) : String(S),
                    error: S
                });
                if (!window.dispatchEvent(M)) return
            } else if (typeof process == "object" && typeof process.emit == "function") {
                process.emit("uncaughtException", S);
                return
            }
            console.error(S)
        },
        we = {
            map: G,
            forEach: function(S, M, K) {
                G(S, function() {
                    M.apply(this, arguments)
                }, K)
            },
            count: function(S) {
                var M = 0;
                return G(S, function() {
                    M++
                }), M
            },
            toArray: function(S) {
                return G(S, function(M) {
                    return M
                }) || []
            },
            only: function(S) {
                if (!Ht(S)) throw Error("React.Children.only expected to receive a single React element child.");
                return S
            }
        };
    return te.Activity = w, te.Children = we, te.Component = H, te.Fragment = l, te.Profiler = h, te.PureComponent = q, te.StrictMode = r, te.Suspense = y, te.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = J, te.__COMPILER_RUNTIME = {
        __proto__: null,
        c: function(S) {
            return J.H.useMemoCache(S)
        }
    }, te.cache = function(S) {
        return function() {
            return S.apply(null, arguments)
        }
    }, te.cacheSignal = function() {
        return null
    }, te.cloneElement = function(S, M, K) {
        if (S == null) throw Error("The argument must be a React element, but you passed " + S + ".");
        var V = B({}, S.props),
            ne = S.key;
        if (M != null)
            for (le in M.key !== void 0 && (ne = "" + M.key), M) !Ne.call(M, le) || le === "key" || le === "__self" || le === "__source" || le === "ref" && M.ref === void 0 || (V[le] = M[le]);
        var le = arguments.length - 2;
        if (le === 1) V.children = K;
        else if (1 < le) {
            for (var ge = Array(le), tt = 0; tt < le; tt++) ge[tt] = arguments[tt + 2];
            V.children = ge
        }
        return Me(S.type, ne, V)
    }, te.createContext = function(S) {
        return S = {
            $$typeof: m,
            _currentValue: S,
            _currentValue2: S,
            _threadCount: 0,
            Provider: null,
            Consumer: null
        }, S.Provider = S, S.Consumer = {
            $$typeof: d,
            _context: S
        }, S
    }, te.createElement = function(S, M, K) {
        var V, ne = {},
            le = null;
        if (M != null)
            for (V in M.key !== void 0 && (le = "" + M.key), M) Ne.call(M, V) && V !== "key" && V !== "__self" && V !== "__source" && (ne[V] = M[V]);
        var ge = arguments.length - 2;
        if (ge === 1) ne.children = K;
        else if (1 < ge) {
            for (var tt = Array(ge), Ue = 0; Ue < ge; Ue++) tt[Ue] = arguments[Ue + 2];
            ne.children = tt
        }
        if (S && S.defaultProps)
            for (V in ge = S.defaultProps, ge) ne[V] === void 0 && (ne[V] = ge[V]);
        return Me(S, le, ne)
    }, te.createRef = function() {
        return {
            current: null
        }
    }, te.forwardRef = function(S) {
        return {
            $$typeof: g,
            render: S
        }
    }, te.isValidElement = Ht, te.lazy = function(S) {
        return {
            $$typeof: _,
            _payload: {
                _status: -1,
                _result: S
            },
            _init: ee
        }
    }, te.memo = function(S, M) {
        return {
            $$typeof: v,
            type: S,
            compare: M === void 0 ? null : M
        }
    }, te.startTransition = function(S) {
        var M = J.T,
            K = {};
        J.T = K;
        try {
            var V = S(),
                ne = J.S;
            ne !== null && ne(K, V), typeof V == "object" && V !== null && typeof V.then == "function" && V.then(ie, be)
        } catch (le) {
            be(le)
        } finally {
            M !== null && K.types !== null && (M.types = K.types), J.T = M
        }
    }, te.unstable_useCacheRefresh = function() {
        return J.H.useCacheRefresh()
    }, te.use = function(S) {
        return J.H.use(S)
    }, te.useActionState = function(S, M, K) {
        return J.H.useActionState(S, M, K)
    }, te.useCallback = function(S, M) {
        return J.H.useCallback(S, M)
    }, te.useContext = function(S) {
        return J.H.useContext(S)
    }, te.useDebugValue = function() {}, te.useDeferredValue = function(S, M) {
        return J.H.useDeferredValue(S, M)
    }, te.useEffect = function(S, M) {
        return J.H.useEffect(S, M)
    }, te.useEffectEvent = function(S) {
        return J.H.useEffectEvent(S)
    }, te.useId = function() {
        return J.H.useId()
    }, te.useImperativeHandle = function(S, M, K) {
        return J.H.useImperativeHandle(S, M, K)
    }, te.useInsertionEffect = function(S, M) {
        return J.H.useInsertionEffect(S, M)
    }, te.useLayoutEffect = function(S, M) {
        return J.H.useLayoutEffect(S, M)
    }, te.useMemo = function(S, M) {
        return J.H.useMemo(S, M)
    }, te.useOptimistic = function(S, M) {
        return J.H.useOptimistic(S, M)
    }, te.useReducer = function(S, M, K) {
        return J.H.useReducer(S, M, K)
    }, te.useRef = function(S) {
        return J.H.useRef(S)
    }, te.useState = function(S) {
        return J.H.useState(S)
    }, te.useSyncExternalStore = function(S, M, K) {
        return J.H.useSyncExternalStore(S, M, K)
    }, te.useTransition = function() {
        return J.H.useTransition()
    }, te.version = "19.2.4", te
}
var Vf;

function Mu() {
    return Vf || (Vf = 1, mu.exports = hv()), mu.exports
}
var Xe = Mu();
const dv = wm(Xe);
var gu = {
        exports: {}
    },
    as = {},
    pu = {
        exports: {}
    },
    vu = {};
var Xf;

function fv() {
    return Xf || (Xf = 1, (function(s) {
        function a(D, G) {
            var ee = D.length;
            D.push(G);
            e: for (; 0 < ee;) {
                var be = ee - 1 >>> 1,
                    we = D[be];
                if (0 < h(we, G)) D[be] = G, D[ee] = we, ee = be;
                else break e
            }
        }

        function l(D) {
            return D.length === 0 ? null : D[0]
        }

        function r(D) {
            if (D.length === 0) return null;
            var G = D[0],
                ee = D.pop();
            if (ee !== G) {
                D[0] = ee;
                e: for (var be = 0, we = D.length, S = we >>> 1; be < S;) {
                    var M = 2 * (be + 1) - 1,
                        K = D[M],
                        V = M + 1,
                        ne = D[V];
                    if (0 > h(K, ee)) V < we && 0 > h(ne, K) ? (D[be] = ne, D[V] = ee, be = V) : (D[be] = K, D[M] = ee, be = M);
                    else if (V < we && 0 > h(ne, ee)) D[be] = ne, D[V] = ee, be = V;
                    else break e
                }
            }
            return G
        }

        function h(D, G) {
            var ee = D.sortIndex - G.sortIndex;
            return ee !== 0 ? ee : D.id - G.id
        }
        if (s.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
            var d = performance;
            s.unstable_now = function() {
                return d.now()
            }
        } else {
            var m = Date,
                g = m.now();
            s.unstable_now = function() {
                return m.now() - g
            }
        }
        var y = [],
            v = [],
            _ = 1,
            w = null,
            E = 3,
            O = !1,
            k = !1,
            B = !1,
            L = !1,
            H = typeof setTimeout == "function" ? setTimeout : null,
            $ = typeof clearTimeout == "function" ? clearTimeout : null,
            q = typeof setImmediate < "u" ? setImmediate : null;

        function I(D) {
            for (var G = l(v); G !== null;) {
                if (G.callback === null) r(v);
                else if (G.startTime <= D) r(v), G.sortIndex = G.expirationTime, a(y, G);
                else break;
                G = l(v)
            }
        }

        function ye(D) {
            if (B = !1, I(D), !k)
                if (l(y) !== null) k = !0, ie || (ie = !0, at());
                else {
                    var G = l(v);
                    G !== null && Ut(ye, G.startTime - D)
                }
        }
        var ie = !1,
            J = -1,
            Ne = 5,
            Me = -1;

        function da() {
            return L ? !0 : !(s.unstable_now() - Me < Ne)
        }

        function Ht() {
            if (L = !1, ie) {
                var D = s.unstable_now();
                Me = D;
                var G = !0;
                try {
                    e: {
                        k = !1,
                        B && (B = !1, $(J), J = -1),
                        O = !0;
                        var ee = E;
                        try {
                            t: {
                                for (I(D), w = l(y); w !== null && !(w.expirationTime > D && da());) {
                                    var be = w.callback;
                                    if (typeof be == "function") {
                                        w.callback = null, E = w.priorityLevel;
                                        var we = be(w.expirationTime <= D);
                                        if (D = s.unstable_now(), typeof we == "function") {
                                            w.callback = we, I(D), G = !0;
                                            break t
                                        }
                                        w === l(y) && r(y), I(D)
                                    } else r(y);
                                    w = l(y)
                                }
                                if (w !== null) G = !0;
                                else {
                                    var S = l(v);
                                    S !== null && Ut(ye, S.startTime - D), G = !1
                                }
                            }
                            break e
                        }
                        finally {
                            w = null, E = ee, O = !1
                        }
                        G = void 0
                    }
                }
                finally {
                    G ? at() : ie = !1
                }
            }
        }
        var at;
        if (typeof q == "function") at = function() {
            q(Ht)
        };
        else if (typeof MessageChannel < "u") {
            var Hn = new MessageChannel,
                Vt = Hn.port2;
            Hn.port1.onmessage = Ht, at = function() {
                Vt.postMessage(null)
            }
        } else at = function() {
            H(Ht, 0)
        };

        function Ut(D, G) {
            J = H(function() {
                D(s.unstable_now())
            }, G)
        }
        s.unstable_IdlePriority = 5, s.unstable_ImmediatePriority = 1, s.unstable_LowPriority = 4, s.unstable_NormalPriority = 3, s.unstable_Profiling = null, s.unstable_UserBlockingPriority = 2, s.unstable_cancelCallback = function(D) {
            D.callback = null
        }, s.unstable_forceFrameRate = function(D) {
            0 > D || 125 < D ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : Ne = 0 < D ? Math.floor(1e3 / D) : 5
        }, s.unstable_getCurrentPriorityLevel = function() {
            return E
        }, s.unstable_next = function(D) {
            switch (E) {
                case 1:
                case 2:
                case 3:
                    var G = 3;
                    break;
                default:
                    G = E
            }
            var ee = E;
            E = G;
            try {
                return D()
            } finally {
                E = ee
            }
        }, s.unstable_requestPaint = function() {
            L = !0
        }, s.unstable_runWithPriority = function(D, G) {
            switch (D) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    break;
                default:
                    D = 3
            }
            var ee = E;
            E = D;
            try {
                return G()
            } finally {
                E = ee
            }
        }, s.unstable_scheduleCallback = function(D, G, ee) {
            var be = s.unstable_now();
            switch (typeof ee == "object" && ee !== null ? (ee = ee.delay, ee = typeof ee == "number" && 0 < ee ? be + ee : be) : ee = be, D) {
                case 1:
                    var we = -1;
                    break;
                case 2:
                    we = 250;
                    break;
                case 5:
                    we = 1073741823;
                    break;
                case 4:
                    we = 1e4;
                    break;
                default:
                    we = 5e3
            }
            return we = ee + we, D = {
                id: _++,
                callback: G,
                priorityLevel: D,
                startTime: ee,
                expirationTime: we,
                sortIndex: -1
            }, ee > be ? (D.sortIndex = ee, a(v, D), l(y) === null && D === l(v) && (B ? ($(J), J = -1) : B = !0, Ut(ye, ee - be))) : (D.sortIndex = we, a(y, D), k || O || (k = !0, ie || (ie = !0, at()))), D
        }, s.unstable_shouldYield = da, s.unstable_wrapCallback = function(D) {
            var G = E;
            return function() {
                var ee = E;
                E = G;
                try {
                    return D.apply(this, arguments)
                } finally {
                    E = ee
                }
            }
        }
    })(vu)), vu
}
var Qf;

function mv() {
    return Qf || (Qf = 1, pu.exports = fv()), pu.exports
}
var yu = {
        exports: {}
    },
    et = {};
var Jf;

function gv() {
    if (Jf) return et;
    Jf = 1;
    var s = Mu();

    function a(y) {
        var v = "https://react.dev/errors/" + y;
        if (1 < arguments.length) {
            v += "?args[]=" + encodeURIComponent(arguments[1]);
            for (var _ = 2; _ < arguments.length; _++) v += "&args[]=" + encodeURIComponent(arguments[_])
        }
        return "Minified React error #" + y + "; visit " + v + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }

    function l() {}
    var r = {
            d: {
                f: l,
                r: function() {
                    throw Error(a(522))
                },
                D: l,
                C: l,
                L: l,
                m: l,
                X: l,
                S: l,
                M: l
            },
            p: 0,
            findDOMNode: null
        },
        h = Symbol.for("react.portal");

    function d(y, v, _) {
        var w = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
        return {
            $$typeof: h,
            key: w == null ? null : "" + w,
            children: y,
            containerInfo: v,
            implementation: _
        }
    }
    var m = s.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

    function g(y, v) {
        if (y === "font") return "";
        if (typeof v == "string") return v === "use-credentials" ? v : ""
    }
    return et.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = r, et.createPortal = function(y, v) {
        var _ = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
        if (!v || v.nodeType !== 1 && v.nodeType !== 9 && v.nodeType !== 11) throw Error(a(299));
        return d(y, v, null, _)
    }, et.flushSync = function(y) {
        var v = m.T,
            _ = r.p;
        try {
            if (m.T = null, r.p = 2, y) return y()
        } finally {
            m.T = v, r.p = _, r.d.f()
        }
    }, et.preconnect = function(y, v) {
        typeof y == "string" && (v ? (v = v.crossOrigin, v = typeof v == "string" ? v === "use-credentials" ? v : "" : void 0) : v = null, r.d.C(y, v))
    }, et.prefetchDNS = function(y) {
        typeof y == "string" && r.d.D(y)
    }, et.preinit = function(y, v) {
        if (typeof y == "string" && v && typeof v.as == "string") {
            var _ = v.as,
                w = g(_, v.crossOrigin),
                E = typeof v.integrity == "string" ? v.integrity : void 0,
                O = typeof v.fetchPriority == "string" ? v.fetchPriority : void 0;
            _ === "style" ? r.d.S(y, typeof v.precedence == "string" ? v.precedence : void 0, {
                crossOrigin: w,
                integrity: E,
                fetchPriority: O
            }) : _ === "script" && r.d.X(y, {
                crossOrigin: w,
                integrity: E,
                fetchPriority: O,
                nonce: typeof v.nonce == "string" ? v.nonce : void 0
            })
        }
    }, et.preinitModule = function(y, v) {
        if (typeof y == "string")
            if (typeof v == "object" && v !== null) {
                if (v.as == null || v.as === "script") {
                    var _ = g(v.as, v.crossOrigin);
                    r.d.M(y, {
                        crossOrigin: _,
                        integrity: typeof v.integrity == "string" ? v.integrity : void 0,
                        nonce: typeof v.nonce == "string" ? v.nonce : void 0
                    })
                }
            } else v == null && r.d.M(y)
    }, et.preload = function(y, v) {
        if (typeof y == "string" && typeof v == "object" && v !== null && typeof v.as == "string") {
            var _ = v.as,
                w = g(_, v.crossOrigin);
            r.d.L(y, _, {
                crossOrigin: w,
                integrity: typeof v.integrity == "string" ? v.integrity : void 0,
                nonce: typeof v.nonce == "string" ? v.nonce : void 0,
                type: typeof v.type == "string" ? v.type : void 0,
                fetchPriority: typeof v.fetchPriority == "string" ? v.fetchPriority : void 0,
                referrerPolicy: typeof v.referrerPolicy == "string" ? v.referrerPolicy : void 0,
                imageSrcSet: typeof v.imageSrcSet == "string" ? v.imageSrcSet : void 0,
                imageSizes: typeof v.imageSizes == "string" ? v.imageSizes : void 0,
                media: typeof v.media == "string" ? v.media : void 0
            })
        }
    }, et.preloadModule = function(y, v) {
        if (typeof y == "string")
            if (v) {
                var _ = g(v.as, v.crossOrigin);
                r.d.m(y, {
                    as: typeof v.as == "string" && v.as !== "script" ? v.as : void 0,
                    crossOrigin: _,
                    integrity: typeof v.integrity == "string" ? v.integrity : void 0
                })
            } else r.d.m(y)
    }, et.requestFormReset = function(y) {
        r.d.r(y)
    }, et.unstable_batchedUpdates = function(y, v) {
        return y(v)
    }, et.useFormState = function(y, v, _) {
        return m.H.useFormState(y, v, _)
    }, et.useFormStatus = function() {
        return m.H.useHostTransitionStatus()
    }, et.version = "19.2.4", et
}
var Zf;

function pv() {
    if (Zf) return yu.exports;
    Zf = 1;

    function s() {
        if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s)
        } catch (a) {
            console.error(a)
        }
    }
    return s(), yu.exports = gv(), yu.exports
}
var If;

function vv() {
    if (If) return as;
    If = 1;
    var s = mv(),
        a = Mu(),
        l = pv();

    function r(e) {
        var t = "https://react.dev/errors/" + e;
        if (1 < arguments.length) {
            t += "?args[]=" + encodeURIComponent(arguments[1]);
            for (var n = 2; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n])
        }
        return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }

    function h(e) {
        return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
    }

    function d(e) {
        var t = e,
            n = e;
        if (e.alternate)
            for (; t.return;) t = t.return;
        else {
            e = t;
            do t = e, (t.flags & 4098) !== 0 && (n = t.return), e = t.return; while (e)
        }
        return t.tag === 3 ? n : null
    }

    function m(e) {
        if (e.tag === 13) {
            var t = e.memoizedState;
            if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
        }
        return null
    }

    function g(e) {
        if (e.tag === 31) {
            var t = e.memoizedState;
            if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
        }
        return null
    }

    function y(e) {
        if (d(e) !== e) throw Error(r(188))
    }

    function v(e) {
        var t = e.alternate;
        if (!t) {
            if (t = d(e), t === null) throw Error(r(188));
            return t !== e ? null : e
        }
        for (var n = e, i = t;;) {
            var o = n.return;
            if (o === null) break;
            var c = o.alternate;
            if (c === null) {
                if (i = o.return, i !== null) {
                    n = i;
                    continue
                }
                break
            }
            if (o.child === c.child) {
                for (c = o.child; c;) {
                    if (c === n) return y(o), e;
                    if (c === i) return y(o), t;
                    c = c.sibling
                }
                throw Error(r(188))
            }
            if (n.return !== i.return) n = o, i = c;
            else {
                for (var f = !1, p = o.child; p;) {
                    if (p === n) {
                        f = !0, n = o, i = c;
                        break
                    }
                    if (p === i) {
                        f = !0, i = o, n = c;
                        break
                    }
                    p = p.sibling
                }
                if (!f) {
                    for (p = c.child; p;) {
                        if (p === n) {
                            f = !0, n = c, i = o;
                            break
                        }
                        if (p === i) {
                            f = !0, i = c, n = o;
                            break
                        }
                        p = p.sibling
                    }
                    if (!f) throw Error(r(189))
                }
            }
            if (n.alternate !== i) throw Error(r(190))
        }
        if (n.tag !== 3) throw Error(r(188));
        return n.stateNode.current === n ? e : t
    }

    function _(e) {
        var t = e.tag;
        if (t === 5 || t === 26 || t === 27 || t === 6) return e;
        for (e = e.child; e !== null;) {
            if (t = _(e), t !== null) return t;
            e = e.sibling
        }
        return null
    }
    var w = Object.assign,
        E = Symbol.for("react.element"),
        O = Symbol.for("react.transitional.element"),
        k = Symbol.for("react.portal"),
        B = Symbol.for("react.fragment"),
        L = Symbol.for("react.strict_mode"),
        H = Symbol.for("react.profiler"),
        $ = Symbol.for("react.consumer"),
        q = Symbol.for("react.context"),
        I = Symbol.for("react.forward_ref"),
        ye = Symbol.for("react.suspense"),
        ie = Symbol.for("react.suspense_list"),
        J = Symbol.for("react.memo"),
        Ne = Symbol.for("react.lazy"),
        Me = Symbol.for("react.activity"),
        da = Symbol.for("react.memo_cache_sentinel"),
        Ht = Symbol.iterator;

    function at(e) {
        return e === null || typeof e != "object" ? null : (e = Ht && e[Ht] || e["@@iterator"], typeof e == "function" ? e : null)
    }
    var Hn = Symbol.for("react.client.reference");

    function Vt(e) {
        if (e == null) return null;
        if (typeof e == "function") return e.$$typeof === Hn ? null : e.displayName || e.name || null;
        if (typeof e == "string") return e;
        switch (e) {
            case B:
                return "Fragment";
            case H:
                return "Profiler";
            case L:
                return "StrictMode";
            case ye:
                return "Suspense";
            case ie:
                return "SuspenseList";
            case Me:
                return "Activity"
        }
        if (typeof e == "object") switch (e.$$typeof) {
            case k:
                return "Portal";
            case q:
                return e.displayName || "Context";
            case $:
                return (e._context.displayName || "Context") + ".Consumer";
            case I:
                var t = e.render;
                return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
            case J:
                return t = e.displayName || null, t !== null ? t : Vt(e.type) || "Memo";
            case Ne:
                t = e._payload, e = e._init;
                try {
                    return Vt(e(t))
                } catch {}
        }
        return null
    }
    var Ut = Array.isArray,
        D = a.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
        G = l.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
        ee = {
            pending: !1,
            data: null,
            method: null,
            action: null
        },
        be = [],
        we = -1;

    function S(e) {
        return {
            current: e
        }
    }

    function M(e) {
        0 > we || (e.current = be[we], be[we] = null, we--)
    }

    function K(e, t) {
        we++, be[we] = e.current, e.current = t
    }
    var V = S(null),
        ne = S(null),
        le = S(null),
        ge = S(null);

    function tt(e, t) {
        switch (K(le, t), K(ne, e), K(V, null), t.nodeType) {
            case 9:
            case 11:
                e = (e = t.documentElement) && (e = e.namespaceURI) ? hf(e) : 0;
                break;
            default:
                if (e = t.tagName, t = t.namespaceURI) t = hf(t), e = df(t, e);
                else switch (e) {
                    case "svg":
                        e = 1;
                        break;
                    case "math":
                        e = 2;
                        break;
                    default:
                        e = 0
                }
        }
        M(V), K(V, e)
    }

    function Ue() {
        M(V), M(ne), M(le)
    }

    function ui(e) {
        e.memoizedState !== null && K(ge, e);
        var t = V.current,
            n = df(t, e.type);
        t !== n && (K(ne, e), K(V, n))
    }

    function ps(e) {
        ne.current === e && (M(V), M(ne)), ge.current === e && (M(ge), Wi._currentValue = ee)
    }
    var Jl, Hu;

    function Gn(e) {
        if (Jl === void 0) try {
            throw Error()
        } catch (n) {
            var t = n.stack.trim().match(/\n( *(at )?)/);
            Jl = t && t[1] || "", Hu = -1 < n.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < n.stack.indexOf("@") ? "@unknown:0:0" : ""
        }
        return `
` + Jl + e + Hu
    }
    var Zl = !1;

    function Il(e, t) {
        if (!e || Zl) return "";
        Zl = !0;
        var n = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        try {
            var i = {
                DetermineComponentFrameRoot: function() {
                    try {
                        if (t) {
                            var z = function() {
                                throw Error()
                            };
                            if (Object.defineProperty(z.prototype, "props", {
                                    set: function() {
                                        throw Error()
                                    }
                                }), typeof Reflect == "object" && Reflect.construct) {
                                try {
                                    Reflect.construct(z, [])
                                } catch (R) {
                                    var N = R
                                }
                                Reflect.construct(e, [], z)
                            } else {
                                try {
                                    z.call()
                                } catch (R) {
                                    N = R
                                }
                                e.call(z.prototype)
                            }
                        } else {
                            try {
                                throw Error()
                            } catch (R) {
                                N = R
                            }(z = e()) && typeof z.catch == "function" && z.catch(function() {})
                        }
                    } catch (R) {
                        if (R && N && typeof R.stack == "string") return [R.stack, N.stack]
                    }
                    return [null, null]
                }
            };
            i.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
            var o = Object.getOwnPropertyDescriptor(i.DetermineComponentFrameRoot, "name");
            o && o.configurable && Object.defineProperty(i.DetermineComponentFrameRoot, "name", {
                value: "DetermineComponentFrameRoot"
            });
            var c = i.DetermineComponentFrameRoot(),
                f = c[0],
                p = c[1];
            if (f && p) {
                var b = f.split(`
`),
                    A = p.split(`
`);
                for (o = i = 0; i < b.length && !b[i].includes("DetermineComponentFrameRoot");) i++;
                for (; o < A.length && !A[o].includes("DetermineComponentFrameRoot");) o++;
                if (i === b.length || o === A.length)
                    for (i = b.length - 1, o = A.length - 1; 1 <= i && 0 <= o && b[i] !== A[o];) o--;
                for (; 1 <= i && 0 <= o; i--, o--)
                    if (b[i] !== A[o]) {
                        if (i !== 1 || o !== 1)
                            do
                                if (i--, o--, 0 > o || b[i] !== A[o]) {
                                    var C = `
` + b[i].replace(" at new ", " at ");
                                    return e.displayName && C.includes("<anonymous>") && (C = C.replace("<anonymous>", e.displayName)), C
                                }
                        while (1 <= i && 0 <= o);
                        break
                    }
            }
        } finally {
            Zl = !1, Error.prepareStackTrace = n
        }
        return (n = e ? e.displayName || e.name : "") ? Gn(n) : ""
    }

    function Hm(e, t) {
        switch (e.tag) {
            case 26:
            case 27:
            case 5:
                return Gn(e.type);
            case 16:
                return Gn("Lazy");
            case 13:
                return e.child !== t && t !== null ? Gn("Suspense Fallback") : Gn("Suspense");
            case 19:
                return Gn("SuspenseList");
            case 0:
            case 15:
                return Il(e.type, !1);
            case 11:
                return Il(e.type.render, !1);
            case 1:
                return Il(e.type, !0);
            case 31:
                return Gn("Activity");
            default:
                return ""
        }
    }

    function Gu(e) {
        try {
            var t = "",
                n = null;
            do t += Hm(e, n), n = e, e = e.return; while (e);
            return t
        } catch (i) {
            return `
Error generating stack: ` + i.message + `
` + i.stack
        }
    }
    var Pl = Object.prototype.hasOwnProperty,
        Wl = s.unstable_scheduleCallback,
        Fl = s.unstable_cancelCallback,
        Gm = s.unstable_shouldYield,
        Km = s.unstable_requestPaint,
        ht = s.unstable_now,
        $m = s.unstable_getCurrentPriorityLevel,
        Ku = s.unstable_ImmediatePriority,
        $u = s.unstable_UserBlockingPriority,
        vs = s.unstable_NormalPriority,
        Ym = s.unstable_LowPriority,
        Yu = s.unstable_IdlePriority,
        Vm = s.log,
        Xm = s.unstable_setDisableYieldValue,
        ci = null,
        dt = null;

    function fn(e) {
        if (typeof Vm == "function" && Xm(e), dt && typeof dt.setStrictMode == "function") try {
            dt.setStrictMode(ci, e)
        } catch {}
    }
    var ft = Math.clz32 ? Math.clz32 : Zm,
        Qm = Math.log,
        Jm = Math.LN2;

    function Zm(e) {
        return e >>>= 0, e === 0 ? 32 : 31 - (Qm(e) / Jm | 0) | 0
    }
    var ys = 256,
        bs = 262144,
        _s = 4194304;

    function Kn(e) {
        var t = e & 42;
        if (t !== 0) return t;
        switch (e & -e) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 4:
                return 4;
            case 8:
                return 8;
            case 16:
                return 16;
            case 32:
                return 32;
            case 64:
                return 64;
            case 128:
                return 128;
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
                return e & 261888;
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
                return e & 3932160;
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
                return e & 62914560;
            case 67108864:
                return 67108864;
            case 134217728:
                return 134217728;
            case 268435456:
                return 268435456;
            case 536870912:
                return 536870912;
            case 1073741824:
                return 0;
            default:
                return e
        }
    }

    function js(e, t, n) {
        var i = e.pendingLanes;
        if (i === 0) return 0;
        var o = 0,
            c = e.suspendedLanes,
            f = e.pingedLanes;
        e = e.warmLanes;
        var p = i & 134217727;
        return p !== 0 ? (i = p & ~c, i !== 0 ? o = Kn(i) : (f &= p, f !== 0 ? o = Kn(f) : n || (n = p & ~e, n !== 0 && (o = Kn(n))))) : (p = i & ~c, p !== 0 ? o = Kn(p) : f !== 0 ? o = Kn(f) : n || (n = i & ~e, n !== 0 && (o = Kn(n)))), o === 0 ? 0 : t !== 0 && t !== o && (t & c) === 0 && (c = o & -o, n = t & -t, c >= n || c === 32 && (n & 4194048) !== 0) ? t : o
    }

    function hi(e, t) {
        return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0
    }

    function Im(e, t) {
        switch (e) {
            case 1:
            case 2:
            case 4:
            case 8:
            case 64:
                return t + 250;
            case 16:
            case 32:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
                return t + 5e3;
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
                return -1;
            case 67108864:
            case 134217728:
            case 268435456:
            case 536870912:
            case 1073741824:
                return -1;
            default:
                return -1
        }
    }

    function Vu() {
        var e = _s;
        return _s <<= 1, (_s & 62914560) === 0 && (_s = 4194304), e
    }

    function er(e) {
        for (var t = [], n = 0; 31 > n; n++) t.push(e);
        return t
    }

    function di(e, t) {
        e.pendingLanes |= t, t !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0)
    }

    function Pm(e, t, n, i, o, c) {
        var f = e.pendingLanes;
        e.pendingLanes = n, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= n, e.entangledLanes &= n, e.errorRecoveryDisabledLanes &= n, e.shellSuspendCounter = 0;
        var p = e.entanglements,
            b = e.expirationTimes,
            A = e.hiddenUpdates;
        for (n = f & ~n; 0 < n;) {
            var C = 31 - ft(n),
                z = 1 << C;
            p[C] = 0, b[C] = -1;
            var N = A[C];
            if (N !== null)
                for (A[C] = null, C = 0; C < N.length; C++) {
                    var R = N[C];
                    R !== null && (R.lane &= -536870913)
                }
            n &= ~z
        }
        i !== 0 && Xu(e, i, 0), c !== 0 && o === 0 && e.tag !== 0 && (e.suspendedLanes |= c & ~(f & ~t))
    }

    function Xu(e, t, n) {
        e.pendingLanes |= t, e.suspendedLanes &= ~t;
        var i = 31 - ft(t);
        e.entangledLanes |= t, e.entanglements[i] = e.entanglements[i] | 1073741824 | n & 261930
    }

    function Qu(e, t) {
        var n = e.entangledLanes |= t;
        for (e = e.entanglements; n;) {
            var i = 31 - ft(n),
                o = 1 << i;
            o & t | e[i] & t && (e[i] |= t), n &= ~o
        }
    }

    function Ju(e, t) {
        var n = t & -t;
        return n = (n & 42) !== 0 ? 1 : tr(n), (n & (e.suspendedLanes | t)) !== 0 ? 0 : n
    }

    function tr(e) {
        switch (e) {
            case 2:
                e = 1;
                break;
            case 8:
                e = 4;
                break;
            case 32:
                e = 16;
                break;
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
                e = 128;
                break;
            case 268435456:
                e = 134217728;
                break;
            default:
                e = 0
        }
        return e
    }

    function nr(e) {
        return e &= -e, 2 < e ? 8 < e ? (e & 134217727) !== 0 ? 32 : 268435456 : 8 : 2
    }

    function Zu() {
        var e = G.p;
        return e !== 0 ? e : (e = window.event, e === void 0 ? 32 : zf(e.type))
    }

    function Iu(e, t) {
        var n = G.p;
        try {
            return G.p = e, t()
        } finally {
            G.p = n
        }
    }
    var mn = Math.random().toString(36).slice(2),
        Qe = "__reactFiber$" + mn,
        it = "__reactProps$" + mn,
        fa = "__reactContainer$" + mn,
        ar = "__reactEvents$" + mn,
        Wm = "__reactListeners$" + mn,
        Fm = "__reactHandles$" + mn,
        Pu = "__reactResources$" + mn,
        fi = "__reactMarker$" + mn;

    function ir(e) {
        delete e[Qe], delete e[it], delete e[ar], delete e[Wm], delete e[Fm]
    }

    function ma(e) {
        var t = e[Qe];
        if (t) return t;
        for (var n = e.parentNode; n;) {
            if (t = n[fa] || n[Qe]) {
                if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                    for (e = bf(e); e !== null;) {
                        if (n = e[Qe]) return n;
                        e = bf(e)
                    }
                return t
            }
            e = n, n = e.parentNode
        }
        return null
    }

    function ga(e) {
        if (e = e[Qe] || e[fa]) {
            var t = e.tag;
            if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3) return e
        }
        return null
    }

    function mi(e) {
        var t = e.tag;
        if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
        throw Error(r(33))
    }

    function pa(e) {
        var t = e[Pu];
        return t || (t = e[Pu] = {
            hoistableStyles: new Map,
            hoistableScripts: new Map
        }), t
    }

    function Ye(e) {
        e[fi] = !0
    }
    var Wu = new Set,
        Fu = {};

    function $n(e, t) {
        va(e, t), va(e + "Capture", t)
    }

    function va(e, t) {
        for (Fu[e] = t, e = 0; e < t.length; e++) Wu.add(t[e])
    }
    var eg = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),
        ec = {},
        tc = {};

    function tg(e) {
        return Pl.call(tc, e) ? !0 : Pl.call(ec, e) ? !1 : eg.test(e) ? tc[e] = !0 : (ec[e] = !0, !1)
    }

    function Ss(e, t, n) {
        if (tg(t))
            if (n === null) e.removeAttribute(t);
            else {
                switch (typeof n) {
                    case "undefined":
                    case "function":
                    case "symbol":
                        e.removeAttribute(t);
                        return;
                    case "boolean":
                        var i = t.toLowerCase().slice(0, 5);
                        if (i !== "data-" && i !== "aria-") {
                            e.removeAttribute(t);
                            return
                        }
                }
                e.setAttribute(t, "" + n)
            }
    }

    function ws(e, t, n) {
        if (n === null) e.removeAttribute(t);
        else {
            switch (typeof n) {
                case "undefined":
                case "function":
                case "symbol":
                case "boolean":
                    e.removeAttribute(t);
                    return
            }
            e.setAttribute(t, "" + n)
        }
    }

    function Xt(e, t, n, i) {
        if (i === null) e.removeAttribute(n);
        else {
            switch (typeof i) {
                case "undefined":
                case "function":
                case "symbol":
                case "boolean":
                    e.removeAttribute(n);
                    return
            }
            e.setAttributeNS(t, n, "" + i)
        }
    }

    function wt(e) {
        switch (typeof e) {
            case "bigint":
            case "boolean":
            case "number":
            case "string":
            case "undefined":
                return e;
            case "object":
                return e;
            default:
                return ""
        }
    }

    function nc(e) {
        var t = e.type;
        return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
    }

    function ng(e, t, n) {
        var i = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
        if (!e.hasOwnProperty(t) && typeof i < "u" && typeof i.get == "function" && typeof i.set == "function") {
            var o = i.get,
                c = i.set;
            return Object.defineProperty(e, t, {
                configurable: !0,
                get: function() {
                    return o.call(this)
                },
                set: function(f) {
                    n = "" + f, c.call(this, f)
                }
            }), Object.defineProperty(e, t, {
                enumerable: i.enumerable
            }), {
                getValue: function() {
                    return n
                },
                setValue: function(f) {
                    n = "" + f
                },
                stopTracking: function() {
                    e._valueTracker = null, delete e[t]
                }
            }
        }
    }

    function sr(e) {
        if (!e._valueTracker) {
            var t = nc(e) ? "checked" : "value";
            e._valueTracker = ng(e, t, "" + e[t])
        }
    }

    function ac(e) {
        if (!e) return !1;
        var t = e._valueTracker;
        if (!t) return !0;
        var n = t.getValue(),
            i = "";
        return e && (i = nc(e) ? e.checked ? "true" : "false" : e.value), e = i, e !== n ? (t.setValue(e), !0) : !1
    }

    function xs(e) {
        if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
        try {
            return e.activeElement || e.body
        } catch {
            return e.body
        }
    }
    var ag = /[\n"\\]/g;

    function xt(e) {
        return e.replace(ag, function(t) {
            return "\\" + t.charCodeAt(0).toString(16) + " "
        })
    }

    function lr(e, t, n, i, o, c, f, p) {
        e.name = "", f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" ? e.type = f : e.removeAttribute("type"), t != null ? f === "number" ? (t === 0 && e.value === "" || e.value != t) && (e.value = "" + wt(t)) : e.value !== "" + wt(t) && (e.value = "" + wt(t)) : f !== "submit" && f !== "reset" || e.removeAttribute("value"), t != null ? rr(e, f, wt(t)) : n != null ? rr(e, f, wt(n)) : i != null && e.removeAttribute("value"), o == null && c != null && (e.defaultChecked = !!c), o != null && (e.checked = o && typeof o != "function" && typeof o != "symbol"), p != null && typeof p != "function" && typeof p != "symbol" && typeof p != "boolean" ? e.name = "" + wt(p) : e.removeAttribute("name")
    }

    function ic(e, t, n, i, o, c, f, p) {
        if (c != null && typeof c != "function" && typeof c != "symbol" && typeof c != "boolean" && (e.type = c), t != null || n != null) {
            if (!(c !== "submit" && c !== "reset" || t != null)) {
                sr(e);
                return
            }
            n = n != null ? "" + wt(n) : "", t = t != null ? "" + wt(t) : n, p || t === e.value || (e.value = t), e.defaultValue = t
        }
        i = i ? ? o, i = typeof i != "function" && typeof i != "symbol" && !!i, e.checked = p ? e.checked : !!i, e.defaultChecked = !!i, f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" && (e.name = f), sr(e)
    }

    function rr(e, t, n) {
        t === "number" && xs(e.ownerDocument) === e || e.defaultValue === "" + n || (e.defaultValue = "" + n)
    }

    function ya(e, t, n, i) {
        if (e = e.options, t) {
            t = {};
            for (var o = 0; o < n.length; o++) t["$" + n[o]] = !0;
            for (n = 0; n < e.length; n++) o = t.hasOwnProperty("$" + e[n].value), e[n].selected !== o && (e[n].selected = o), o && i && (e[n].defaultSelected = !0)
        } else {
            for (n = "" + wt(n), t = null, o = 0; o < e.length; o++) {
                if (e[o].value === n) {
                    e[o].selected = !0, i && (e[o].defaultSelected = !0);
                    return
                }
                t !== null || e[o].disabled || (t = e[o])
            }
            t !== null && (t.selected = !0)
        }
    }

    function sc(e, t, n) {
        if (t != null && (t = "" + wt(t), t !== e.value && (e.value = t), n == null)) {
            e.defaultValue !== t && (e.defaultValue = t);
            return
        }
        e.defaultValue = n != null ? "" + wt(n) : ""
    }

    function lc(e, t, n, i) {
        if (t == null) {
            if (i != null) {
                if (n != null) throw Error(r(92));
                if (Ut(i)) {
                    if (1 < i.length) throw Error(r(93));
                    i = i[0]
                }
                n = i
            }
            n == null && (n = ""), t = n
        }
        n = wt(t), e.defaultValue = n, i = e.textContent, i === n && i !== "" && i !== null && (e.value = i), sr(e)
    }

    function ba(e, t) {
        if (t) {
            var n = e.firstChild;
            if (n && n === e.lastChild && n.nodeType === 3) {
                n.nodeValue = t;
                return
            }
        }
        e.textContent = t
    }
    var ig = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));

    function rc(e, t, n) {
        var i = t.indexOf("--") === 0;
        n == null || typeof n == "boolean" || n === "" ? i ? e.setProperty(t, "") : t === "float" ? e.cssFloat = "" : e[t] = "" : i ? e.setProperty(t, n) : typeof n != "number" || n === 0 || ig.has(t) ? t === "float" ? e.cssFloat = n : e[t] = ("" + n).trim() : e[t] = n + "px"
    }

    function oc(e, t, n) {
        if (t != null && typeof t != "object") throw Error(r(62));
        if (e = e.style, n != null) {
            for (var i in n) !n.hasOwnProperty(i) || t != null && t.hasOwnProperty(i) || (i.indexOf("--") === 0 ? e.setProperty(i, "") : i === "float" ? e.cssFloat = "" : e[i] = "");
            for (var o in t) i = t[o], t.hasOwnProperty(o) && n[o] !== i && rc(e, o, i)
        } else
            for (var c in t) t.hasOwnProperty(c) && rc(e, c, t[c])
    }

    function or(e) {
        if (e.indexOf("-") === -1) return !1;
        switch (e) {
            case "annotation-xml":
            case "color-profile":
            case "font-face":
            case "font-face-src":
            case "font-face-uri":
            case "font-face-format":
            case "font-face-name":
            case "missing-glyph":
                return !1;
            default:
                return !0
        }
    }
    var sg = new Map([
            ["acceptCharset", "accept-charset"],
            ["htmlFor", "for"],
            ["httpEquiv", "http-equiv"],
            ["crossOrigin", "crossorigin"],
            ["accentHeight", "accent-height"],
            ["alignmentBaseline", "alignment-baseline"],
            ["arabicForm", "arabic-form"],
            ["baselineShift", "baseline-shift"],
            ["capHeight", "cap-height"],
            ["clipPath", "clip-path"],
            ["clipRule", "clip-rule"],
            ["colorInterpolation", "color-interpolation"],
            ["colorInterpolationFilters", "color-interpolation-filters"],
            ["colorProfile", "color-profile"],
            ["colorRendering", "color-rendering"],
            ["dominantBaseline", "dominant-baseline"],
            ["enableBackground", "enable-background"],
            ["fillOpacity", "fill-opacity"],
            ["fillRule", "fill-rule"],
            ["floodColor", "flood-color"],
            ["floodOpacity", "flood-opacity"],
            ["fontFamily", "font-family"],
            ["fontSize", "font-size"],
            ["fontSizeAdjust", "font-size-adjust"],
            ["fontStretch", "font-stretch"],
            ["fontStyle", "font-style"],
            ["fontVariant", "font-variant"],
            ["fontWeight", "font-weight"],
            ["glyphName", "glyph-name"],
            ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
            ["glyphOrientationVertical", "glyph-orientation-vertical"],
            ["horizAdvX", "horiz-adv-x"],
            ["horizOriginX", "horiz-origin-x"],
            ["imageRendering", "image-rendering"],
            ["letterSpacing", "letter-spacing"],
            ["lightingColor", "lighting-color"],
            ["markerEnd", "marker-end"],
            ["markerMid", "marker-mid"],
            ["markerStart", "marker-start"],
            ["overlinePosition", "overline-position"],
            ["overlineThickness", "overline-thickness"],
            ["paintOrder", "paint-order"],
            ["panose-1", "panose-1"],
            ["pointerEvents", "pointer-events"],
            ["renderingIntent", "rendering-intent"],
            ["shapeRendering", "shape-rendering"],
            ["stopColor", "stop-color"],
            ["stopOpacity", "stop-opacity"],
            ["strikethroughPosition", "strikethrough-position"],
            ["strikethroughThickness", "strikethrough-thickness"],
            ["strokeDasharray", "stroke-dasharray"],
            ["strokeDashoffset", "stroke-dashoffset"],
            ["strokeLinecap", "stroke-linecap"],
            ["strokeLinejoin", "stroke-linejoin"],
            ["strokeMiterlimit", "stroke-miterlimit"],
            ["strokeOpacity", "stroke-opacity"],
            ["strokeWidth", "stroke-width"],
            ["textAnchor", "text-anchor"],
            ["textDecoration", "text-decoration"],
            ["textRendering", "text-rendering"],
            ["transformOrigin", "transform-origin"],
            ["underlinePosition", "underline-position"],
            ["underlineThickness", "underline-thickness"],
            ["unicodeBidi", "unicode-bidi"],
            ["unicodeRange", "unicode-range"],
            ["unitsPerEm", "units-per-em"],
            ["vAlphabetic", "v-alphabetic"],
            ["vHanging", "v-hanging"],
            ["vIdeographic", "v-ideographic"],
            ["vMathematical", "v-mathematical"],
            ["vectorEffect", "vector-effect"],
            ["vertAdvY", "vert-adv-y"],
            ["vertOriginX", "vert-origin-x"],
            ["vertOriginY", "vert-origin-y"],
            ["wordSpacing", "word-spacing"],
            ["writingMode", "writing-mode"],
            ["xmlnsXlink", "xmlns:xlink"],
            ["xHeight", "x-height"]
        ]),
        lg = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;

    function Es(e) {
        return lg.test("" + e) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : e
    }

    function Qt() {}
    var ur = null;

    function cr(e) {
        return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
    }
    var _a = null,
        ja = null;

    function uc(e) {
        var t = ga(e);
        if (t && (e = t.stateNode)) {
            var n = e[it] || null;
            e: switch (e = t.stateNode, t.type) {
                case "input":
                    if (lr(e, n.value, n.defaultValue, n.defaultValue, n.checked, n.defaultChecked, n.type, n.name), t = n.name, n.type === "radio" && t != null) {
                        for (n = e; n.parentNode;) n = n.parentNode;
                        for (n = n.querySelectorAll('input[name="' + xt("" + t) + '"][type="radio"]'), t = 0; t < n.length; t++) {
                            var i = n[t];
                            if (i !== e && i.form === e.form) {
                                var o = i[it] || null;
                                if (!o) throw Error(r(90));
                                lr(i, o.value, o.defaultValue, o.defaultValue, o.checked, o.defaultChecked, o.type, o.name)
                            }
                        }
                        for (t = 0; t < n.length; t++) i = n[t], i.form === e.form && ac(i)
                    }
                    break e;
                case "textarea":
                    sc(e, n.value, n.defaultValue);
                    break e;
                case "select":
                    t = n.value, t != null && ya(e, !!n.multiple, t, !1)
            }
        }
    }
    var hr = !1;

    function cc(e, t, n) {
        if (hr) return e(t, n);
        hr = !0;
        try {
            var i = e(t);
            return i
        } finally {
            if (hr = !1, (_a !== null || ja !== null) && (dl(), _a && (t = _a, e = ja, ja = _a = null, uc(t), e)))
                for (t = 0; t < e.length; t++) uc(e[t])
        }
    }

    function gi(e, t) {
        var n = e.stateNode;
        if (n === null) return null;
        var i = n[it] || null;
        if (i === null) return null;
        n = i[t];
        e: switch (t) {
            case "onClick":
            case "onClickCapture":
            case "onDoubleClick":
            case "onDoubleClickCapture":
            case "onMouseDown":
            case "onMouseDownCapture":
            case "onMouseMove":
            case "onMouseMoveCapture":
            case "onMouseUp":
            case "onMouseUpCapture":
            case "onMouseEnter":
                (i = !i.disabled) || (e = e.type, i = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !i;
                break e;
            default:
                e = !1
        }
        if (e) return null;
        if (n && typeof n != "function") throw Error(r(231, t, typeof n));
        return n
    }
    var Jt = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
        dr = !1;
    if (Jt) try {
        var pi = {};
        Object.defineProperty(pi, "passive", {
            get: function() {
                dr = !0
            }
        }), window.addEventListener("test", pi, pi), window.removeEventListener("test", pi, pi)
    } catch {
        dr = !1
    }
    var gn = null,
        fr = null,
        Ts = null;

    function hc() {
        if (Ts) return Ts;
        var e, t = fr,
            n = t.length,
            i, o = "value" in gn ? gn.value : gn.textContent,
            c = o.length;
        for (e = 0; e < n && t[e] === o[e]; e++);
        var f = n - e;
        for (i = 1; i <= f && t[n - i] === o[c - i]; i++);
        return Ts = o.slice(e, 1 < i ? 1 - i : void 0)
    }

    function As(e) {
        var t = e.keyCode;
        return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
    }

    function Os() {
        return !0
    }

    function dc() {
        return !1
    }

    function st(e) {
        function t(n, i, o, c, f) {
            this._reactName = n, this._targetInst = o, this.type = i, this.nativeEvent = c, this.target = f, this.currentTarget = null;
            for (var p in e) e.hasOwnProperty(p) && (n = e[p], this[p] = n ? n(c) : c[p]);
            return this.isDefaultPrevented = (c.defaultPrevented != null ? c.defaultPrevented : c.returnValue === !1) ? Os : dc, this.isPropagationStopped = dc, this
        }
        return w(t.prototype, {
            preventDefault: function() {
                this.defaultPrevented = !0;
                var n = this.nativeEvent;
                n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = Os)
            },
            stopPropagation: function() {
                var n = this.nativeEvent;
                n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = Os)
            },
            persist: function() {},
            isPersistent: Os
        }), t
    }
    var Yn = {
            eventPhase: 0,
            bubbles: 0,
            cancelable: 0,
            timeStamp: function(e) {
                return e.timeStamp || Date.now()
            },
            defaultPrevented: 0,
            isTrusted: 0
        },
        Ns = st(Yn),
        vi = w({}, Yn, {
            view: 0,
            detail: 0
        }),
        rg = st(vi),
        mr, gr, yi, Rs = w({}, vi, {
            screenX: 0,
            screenY: 0,
            clientX: 0,
            clientY: 0,
            pageX: 0,
            pageY: 0,
            ctrlKey: 0,
            shiftKey: 0,
            altKey: 0,
            metaKey: 0,
            getModifierState: vr,
            button: 0,
            buttons: 0,
            relatedTarget: function(e) {
                return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
            },
            movementX: function(e) {
                return "movementX" in e ? e.movementX : (e !== yi && (yi && e.type === "mousemove" ? (mr = e.screenX - yi.screenX, gr = e.screenY - yi.screenY) : gr = mr = 0, yi = e), mr)
            },
            movementY: function(e) {
                return "movementY" in e ? e.movementY : gr
            }
        }),
        fc = st(Rs),
        og = w({}, Rs, {
            dataTransfer: 0
        }),
        ug = st(og),
        cg = w({}, vi, {
            relatedTarget: 0
        }),
        pr = st(cg),
        hg = w({}, Yn, {
            animationName: 0,
            elapsedTime: 0,
            pseudoElement: 0
        }),
        dg = st(hg),
        fg = w({}, Yn, {
            clipboardData: function(e) {
                return "clipboardData" in e ? e.clipboardData : window.clipboardData
            }
        }),
        mg = st(fg),
        gg = w({}, Yn, {
            data: 0
        }),
        mc = st(gg),
        pg = {
            Esc: "Escape",
            Spacebar: " ",
            Left: "ArrowLeft",
            Up: "ArrowUp",
            Right: "ArrowRight",
            Down: "ArrowDown",
            Del: "Delete",
            Win: "OS",
            Menu: "ContextMenu",
            Apps: "ContextMenu",
            Scroll: "ScrollLock",
            MozPrintableKey: "Unidentified"
        },
        vg = {
            8: "Backspace",
            9: "Tab",
            12: "Clear",
            13: "Enter",
            16: "Shift",
            17: "Control",
            18: "Alt",
            19: "Pause",
            20: "CapsLock",
            27: "Escape",
            32: " ",
            33: "PageUp",
            34: "PageDown",
            35: "End",
            36: "Home",
            37: "ArrowLeft",
            38: "ArrowUp",
            39: "ArrowRight",
            40: "ArrowDown",
            45: "Insert",
            46: "Delete",
            112: "F1",
            113: "F2",
            114: "F3",
            115: "F4",
            116: "F5",
            117: "F6",
            118: "F7",
            119: "F8",
            120: "F9",
            121: "F10",
            122: "F11",
            123: "F12",
            144: "NumLock",
            145: "ScrollLock",
            224: "Meta"
        },
        yg = {
            Alt: "altKey",
            Control: "ctrlKey",
            Meta: "metaKey",
            Shift: "shiftKey"
        };

    function bg(e) {
        var t = this.nativeEvent;
        return t.getModifierState ? t.getModifierState(e) : (e = yg[e]) ? !!t[e] : !1
    }

    function vr() {
        return bg
    }
    var _g = w({}, vi, {
            key: function(e) {
                if (e.key) {
                    var t = pg[e.key] || e.key;
                    if (t !== "Unidentified") return t
                }
                return e.type === "keypress" ? (e = As(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? vg[e.keyCode] || "Unidentified" : ""
            },
            code: 0,
            location: 0,
            ctrlKey: 0,
            shiftKey: 0,
            altKey: 0,
            metaKey: 0,
            repeat: 0,
            locale: 0,
            getModifierState: vr,
            charCode: function(e) {
                return e.type === "keypress" ? As(e) : 0
            },
            keyCode: function(e) {
                return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
            },
            which: function(e) {
                return e.type === "keypress" ? As(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
            }
        }),
        jg = st(_g),
        Sg = w({}, Rs, {
            pointerId: 0,
            width: 0,
            height: 0,
            pressure: 0,
            tangentialPressure: 0,
            tiltX: 0,
            tiltY: 0,
            twist: 0,
            pointerType: 0,
            isPrimary: 0
        }),
        gc = st(Sg),
        wg = w({}, vi, {
            touches: 0,
            targetTouches: 0,
            changedTouches: 0,
            altKey: 0,
            metaKey: 0,
            ctrlKey: 0,
            shiftKey: 0,
            getModifierState: vr
        }),
        xg = st(wg),
        Eg = w({}, Yn, {
            propertyName: 0,
            elapsedTime: 0,
            pseudoElement: 0
        }),
        Tg = st(Eg),
        Ag = w({}, Rs, {
            deltaX: function(e) {
                return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
            },
            deltaY: function(e) {
                return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
            },
            deltaZ: 0,
            deltaMode: 0
        }),
        Og = st(Ag),
        Ng = w({}, Yn, {
            newState: 0,
            oldState: 0
        }),
        Rg = st(Ng),
        Cg = [9, 13, 27, 32],
        yr = Jt && "CompositionEvent" in window,
        bi = null;
    Jt && "documentMode" in document && (bi = document.documentMode);
    var Dg = Jt && "TextEvent" in window && !bi,
        pc = Jt && (!yr || bi && 8 < bi && 11 >= bi),
        vc = " ",
        yc = !1;

    function bc(e, t) {
        switch (e) {
            case "keyup":
                return Cg.indexOf(t.keyCode) !== -1;
            case "keydown":
                return t.keyCode !== 229;
            case "keypress":
            case "mousedown":
            case "focusout":
                return !0;
            default:
                return !1
        }
    }

    function _c(e) {
        return e = e.detail, typeof e == "object" && "data" in e ? e.data : null
    }
    var Sa = !1;

    function Ug(e, t) {
        switch (e) {
            case "compositionend":
                return _c(t);
            case "keypress":
                return t.which !== 32 ? null : (yc = !0, vc);
            case "textInput":
                return e = t.data, e === vc && yc ? null : e;
            default:
                return null
        }
    }

    function kg(e, t) {
        if (Sa) return e === "compositionend" || !yr && bc(e, t) ? (e = hc(), Ts = fr = gn = null, Sa = !1, e) : null;
        switch (e) {
            case "paste":
                return null;
            case "keypress":
                if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                    if (t.char && 1 < t.char.length) return t.char;
                    if (t.which) return String.fromCharCode(t.which)
                }
                return null;
            case "compositionend":
                return pc && t.locale !== "ko" ? null : t.data;
            default:
                return null
        }
    }
    var zg = {
        color: !0,
        date: !0,
        datetime: !0,
        "datetime-local": !0,
        email: !0,
        month: !0,
        number: !0,
        password: !0,
        range: !0,
        search: !0,
        tel: !0,
        text: !0,
        time: !0,
        url: !0,
        week: !0
    };

    function jc(e) {
        var t = e && e.nodeName && e.nodeName.toLowerCase();
        return t === "input" ? !!zg[e.type] : t === "textarea"
    }

    function Sc(e, t, n, i) {
        _a ? ja ? ja.push(i) : ja = [i] : _a = i, t = bl(t, "onChange"), 0 < t.length && (n = new Ns("onChange", "change", null, n, i), e.push({
            event: n,
            listeners: t
        }))
    }
    var _i = null,
        ji = null;

    function Mg(e) {
        sf(e, 0)
    }

    function Cs(e) {
        var t = mi(e);
        if (ac(t)) return e
    }

    function wc(e, t) {
        if (e === "change") return t
    }
    var xc = !1;
    if (Jt) {
        var br;
        if (Jt) {
            var _r = "oninput" in document;
            if (!_r) {
                var Ec = document.createElement("div");
                Ec.setAttribute("oninput", "return;"), _r = typeof Ec.oninput == "function"
            }
            br = _r
        } else br = !1;
        xc = br && (!document.documentMode || 9 < document.documentMode)
    }

    function Tc() {
        _i && (_i.detachEvent("onpropertychange", Ac), ji = _i = null)
    }

    function Ac(e) {
        if (e.propertyName === "value" && Cs(ji)) {
            var t = [];
            Sc(t, ji, e, cr(e)), cc(Mg, t)
        }
    }

    function Bg(e, t, n) {
        e === "focusin" ? (Tc(), _i = t, ji = n, _i.attachEvent("onpropertychange", Ac)) : e === "focusout" && Tc()
    }

    function qg(e) {
        if (e === "selectionchange" || e === "keyup" || e === "keydown") return Cs(ji)
    }

    function Lg(e, t) {
        if (e === "click") return Cs(t)
    }

    function Hg(e, t) {
        if (e === "input" || e === "change") return Cs(t)
    }

    function Gg(e, t) {
        return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
    }
    var mt = typeof Object.is == "function" ? Object.is : Gg;

    function Si(e, t) {
        if (mt(e, t)) return !0;
        if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
        var n = Object.keys(e),
            i = Object.keys(t);
        if (n.length !== i.length) return !1;
        for (i = 0; i < n.length; i++) {
            var o = n[i];
            if (!Pl.call(t, o) || !mt(e[o], t[o])) return !1
        }
        return !0
    }

    function Oc(e) {
        for (; e && e.firstChild;) e = e.firstChild;
        return e
    }

    function Nc(e, t) {
        var n = Oc(e);
        e = 0;
        for (var i; n;) {
            if (n.nodeType === 3) {
                if (i = e + n.textContent.length, e <= t && i >= t) return {
                    node: n,
                    offset: t - e
                };
                e = i
            }
            e: {
                for (; n;) {
                    if (n.nextSibling) {
                        n = n.nextSibling;
                        break e
                    }
                    n = n.parentNode
                }
                n = void 0
            }
            n = Oc(n)
        }
    }

    function Rc(e, t) {
        return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? Rc(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
    }

    function Cc(e) {
        e = e != null && e.ownerDocument != null && e.ownerDocument.defaultView != null ? e.ownerDocument.defaultView : window;
        for (var t = xs(e.document); t instanceof e.HTMLIFrameElement;) {
            try {
                var n = typeof t.contentWindow.location.href == "string"
            } catch {
                n = !1
            }
            if (n) e = t.contentWindow;
            else break;
            t = xs(e.document)
        }
        return t
    }

    function jr(e) {
        var t = e && e.nodeName && e.nodeName.toLowerCase();
        return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true")
    }
    var Kg = Jt && "documentMode" in document && 11 >= document.documentMode,
        wa = null,
        Sr = null,
        wi = null,
        wr = !1;

    function Dc(e, t, n) {
        var i = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
        wr || wa == null || wa !== xs(i) || (i = wa, "selectionStart" in i && jr(i) ? i = {
            start: i.selectionStart,
            end: i.selectionEnd
        } : (i = (i.ownerDocument && i.ownerDocument.defaultView || window).getSelection(), i = {
            anchorNode: i.anchorNode,
            anchorOffset: i.anchorOffset,
            focusNode: i.focusNode,
            focusOffset: i.focusOffset
        }), wi && Si(wi, i) || (wi = i, i = bl(Sr, "onSelect"), 0 < i.length && (t = new Ns("onSelect", "select", null, t, n), e.push({
            event: t,
            listeners: i
        }), t.target = wa)))
    }

    function Vn(e, t) {
        var n = {};
        return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
    }
    var xa = {
            animationend: Vn("Animation", "AnimationEnd"),
            animationiteration: Vn("Animation", "AnimationIteration"),
            animationstart: Vn("Animation", "AnimationStart"),
            transitionrun: Vn("Transition", "TransitionRun"),
            transitionstart: Vn("Transition", "TransitionStart"),
            transitioncancel: Vn("Transition", "TransitionCancel"),
            transitionend: Vn("Transition", "TransitionEnd")
        },
        xr = {},
        Uc = {};
    Jt && (Uc = document.createElement("div").style, "AnimationEvent" in window || (delete xa.animationend.animation, delete xa.animationiteration.animation, delete xa.animationstart.animation), "TransitionEvent" in window || delete xa.transitionend.transition);

    function Xn(e) {
        if (xr[e]) return xr[e];
        if (!xa[e]) return e;
        var t = xa[e],
            n;
        for (n in t)
            if (t.hasOwnProperty(n) && n in Uc) return xr[e] = t[n];
        return e
    }
    var kc = Xn("animationend"),
        zc = Xn("animationiteration"),
        Mc = Xn("animationstart"),
        $g = Xn("transitionrun"),
        Yg = Xn("transitionstart"),
        Vg = Xn("transitioncancel"),
        Bc = Xn("transitionend"),
        qc = new Map,
        Er = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
    Er.push("scrollEnd");

    function kt(e, t) {
        qc.set(e, t), $n(t, [e])
    }
    var Ds = typeof reportError == "function" ? reportError : function(e) {
            if (typeof window == "object" && typeof window.ErrorEvent == "function") {
                var t = new window.ErrorEvent("error", {
                    bubbles: !0,
                    cancelable: !0,
                    message: typeof e == "object" && e !== null && typeof e.message == "string" ? String(e.message) : String(e),
                    error: e
                });
                if (!window.dispatchEvent(t)) return
            } else if (typeof process == "object" && typeof process.emit == "function") {
                process.emit("uncaughtException", e);
                return
            }
            console.error(e)
        },
        Et = [],
        Ea = 0,
        Tr = 0;

    function Us() {
        for (var e = Ea, t = Tr = Ea = 0; t < e;) {
            var n = Et[t];
            Et[t++] = null;
            var i = Et[t];
            Et[t++] = null;
            var o = Et[t];
            Et[t++] = null;
            var c = Et[t];
            if (Et[t++] = null, i !== null && o !== null) {
                var f = i.pending;
                f === null ? o.next = o : (o.next = f.next, f.next = o), i.pending = o
            }
            c !== 0 && Lc(n, o, c)
        }
    }

    function ks(e, t, n, i) {
        Et[Ea++] = e, Et[Ea++] = t, Et[Ea++] = n, Et[Ea++] = i, Tr |= i, e.lanes |= i, e = e.alternate, e !== null && (e.lanes |= i)
    }

    function Ar(e, t, n, i) {
        return ks(e, t, n, i), zs(e)
    }

    function Qn(e, t) {
        return ks(e, null, null, t), zs(e)
    }

    function Lc(e, t, n) {
        e.lanes |= n;
        var i = e.alternate;
        i !== null && (i.lanes |= n);
        for (var o = !1, c = e.return; c !== null;) c.childLanes |= n, i = c.alternate, i !== null && (i.childLanes |= n), c.tag === 22 && (e = c.stateNode, e === null || e._visibility & 1 || (o = !0)), e = c, c = c.return;
        return e.tag === 3 ? (c = e.stateNode, o && t !== null && (o = 31 - ft(n), e = c.hiddenUpdates, i = e[o], i === null ? e[o] = [t] : i.push(t), t.lane = n | 536870912), c) : null
    }

    function zs(e) {
        if (50 < Vi) throw Vi = 0, Bo = null, Error(r(185));
        for (var t = e.return; t !== null;) e = t, t = e.return;
        return e.tag === 3 ? e.stateNode : null
    }
    var Ta = {};

    function Xg(e, t, n, i) {
        this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = i, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
    }

    function gt(e, t, n, i) {
        return new Xg(e, t, n, i)
    }

    function Or(e) {
        return e = e.prototype, !(!e || !e.isReactComponent)
    }

    function Zt(e, t) {
        var n = e.alternate;
        return n === null ? (n = gt(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 65011712, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
            lanes: t.lanes,
            firstContext: t.firstContext
        }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n.refCleanup = e.refCleanup, n
    }

    function Hc(e, t) {
        e.flags &= 65011714;
        var n = e.alternate;
        return n === null ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = n.childLanes, e.lanes = n.lanes, e.child = n.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = n.memoizedProps, e.memoizedState = n.memoizedState, e.updateQueue = n.updateQueue, e.type = n.type, t = n.dependencies, e.dependencies = t === null ? null : {
            lanes: t.lanes,
            firstContext: t.firstContext
        }), e
    }

    function Ms(e, t, n, i, o, c) {
        var f = 0;
        if (i = e, typeof e == "function") Or(e) && (f = 1);
        else if (typeof e == "string") f = Pp(e, n, V.current) ? 26 : e === "html" || e === "head" || e === "body" ? 27 : 5;
        else e: switch (e) {
            case Me:
                return e = gt(31, n, t, o), e.elementType = Me, e.lanes = c, e;
            case B:
                return Jn(n.children, o, c, t);
            case L:
                f = 8, o |= 24;
                break;
            case H:
                return e = gt(12, n, t, o | 2), e.elementType = H, e.lanes = c, e;
            case ye:
                return e = gt(13, n, t, o), e.elementType = ye, e.lanes = c, e;
            case ie:
                return e = gt(19, n, t, o), e.elementType = ie, e.lanes = c, e;
            default:
                if (typeof e == "object" && e !== null) switch (e.$$typeof) {
                    case q:
                        f = 10;
                        break e;
                    case $:
                        f = 9;
                        break e;
                    case I:
                        f = 11;
                        break e;
                    case J:
                        f = 14;
                        break e;
                    case Ne:
                        f = 16, i = null;
                        break e
                }
                f = 29, n = Error(r(130, e === null ? "null" : typeof e, "")), i = null
        }
        return t = gt(f, n, t, o), t.elementType = e, t.type = i, t.lanes = c, t
    }

    function Jn(e, t, n, i) {
        return e = gt(7, e, i, t), e.lanes = n, e
    }

    function Nr(e, t, n) {
        return e = gt(6, e, null, t), e.lanes = n, e
    }

    function Gc(e) {
        var t = gt(18, null, null, 0);
        return t.stateNode = e, t
    }

    function Rr(e, t, n) {
        return t = gt(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
            containerInfo: e.containerInfo,
            pendingChildren: null,
            implementation: e.implementation
        }, t
    }
    var Kc = new WeakMap;

    function Tt(e, t) {
        if (typeof e == "object" && e !== null) {
            var n = Kc.get(e);
            return n !== void 0 ? n : (t = {
                value: e,
                source: t,
                stack: Gu(t)
            }, Kc.set(e, t), t)
        }
        return {
            value: e,
            source: t,
            stack: Gu(t)
        }
    }
    var Aa = [],
        Oa = 0,
        Bs = null,
        xi = 0,
        At = [],
        Ot = 0,
        pn = null,
        Gt = 1,
        Kt = "";

    function It(e, t) {
        Aa[Oa++] = xi, Aa[Oa++] = Bs, Bs = e, xi = t
    }

    function $c(e, t, n) {
        At[Ot++] = Gt, At[Ot++] = Kt, At[Ot++] = pn, pn = e;
        var i = Gt;
        e = Kt;
        var o = 32 - ft(i) - 1;
        i &= ~(1 << o), n += 1;
        var c = 32 - ft(t) + o;
        if (30 < c) {
            var f = o - o % 5;
            c = (i & (1 << f) - 1).toString(32), i >>= f, o -= f, Gt = 1 << 32 - ft(t) + o | n << o | i, Kt = c + e
        } else Gt = 1 << c | n << o | i, Kt = e
    }

    function Cr(e) {
        e.return !== null && (It(e, 1), $c(e, 1, 0))
    }

    function Dr(e) {
        for (; e === Bs;) Bs = Aa[--Oa], Aa[Oa] = null, xi = Aa[--Oa], Aa[Oa] = null;
        for (; e === pn;) pn = At[--Ot], At[Ot] = null, Kt = At[--Ot], At[Ot] = null, Gt = At[--Ot], At[Ot] = null
    }

    function Yc(e, t) {
        At[Ot++] = Gt, At[Ot++] = Kt, At[Ot++] = pn, Gt = t.id, Kt = t.overflow, pn = e
    }
    var Je = null,
        Te = null,
        he = !1,
        vn = null,
        Nt = !1,
        Ur = Error(r(519));

    function yn(e) {
        var t = Error(r(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML", ""));
        throw Ei(Tt(t, e)), Ur
    }

    function Vc(e) {
        var t = e.stateNode,
            n = e.type,
            i = e.memoizedProps;
        switch (t[Qe] = e, t[it] = i, n) {
            case "dialog":
                oe("cancel", t), oe("close", t);
                break;
            case "iframe":
            case "object":
            case "embed":
                oe("load", t);
                break;
            case "video":
            case "audio":
                for (n = 0; n < Qi.length; n++) oe(Qi[n], t);
                break;
            case "source":
                oe("error", t);
                break;
            case "img":
            case "image":
            case "link":
                oe("error", t), oe("load", t);
                break;
            case "details":
                oe("toggle", t);
                break;
            case "input":
                oe("invalid", t), ic(t, i.value, i.defaultValue, i.checked, i.defaultChecked, i.type, i.name, !0);
                break;
            case "select":
                oe("invalid", t);
                break;
            case "textarea":
                oe("invalid", t), lc(t, i.value, i.defaultValue, i.children)
        }
        n = i.children, typeof n != "string" && typeof n != "number" && typeof n != "bigint" || t.textContent === "" + n || i.suppressHydrationWarning === !0 || uf(t.textContent, n) ? (i.popover != null && (oe("beforetoggle", t), oe("toggle", t)), i.onScroll != null && oe("scroll", t), i.onScrollEnd != null && oe("scrollend", t), i.onClick != null && (t.onclick = Qt), t = !0) : t = !1, t || yn(e, !0)
    }

    function Xc(e) {
        for (Je = e.return; Je;) switch (Je.tag) {
            case 5:
            case 31:
            case 13:
                Nt = !1;
                return;
            case 27:
            case 3:
                Nt = !0;
                return;
            default:
                Je = Je.return
        }
    }

    function Na(e) {
        if (e !== Je) return !1;
        if (!he) return Xc(e), he = !0, !1;
        var t = e.tag,
            n;
        if ((n = t !== 3 && t !== 27) && ((n = t === 5) && (n = e.type, n = !(n !== "form" && n !== "button") || Wo(e.type, e.memoizedProps)), n = !n), n && Te && yn(e), Xc(e), t === 13) {
            if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(r(317));
            Te = yf(e)
        } else if (t === 31) {
            if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(r(317));
            Te = yf(e)
        } else t === 27 ? (t = Te, Dn(e.type) ? (e = au, au = null, Te = e) : Te = t) : Te = Je ? Ct(e.stateNode.nextSibling) : null;
        return !0
    }

    function Zn() {
        Te = Je = null, he = !1
    }

    function kr() {
        var e = vn;
        return e !== null && (ut === null ? ut = e : ut.push.apply(ut, e), vn = null), e
    }

    function Ei(e) {
        vn === null ? vn = [e] : vn.push(e)
    }
    var zr = S(null),
        In = null,
        Pt = null;

    function bn(e, t, n) {
        K(zr, t._currentValue), t._currentValue = n
    }

    function Wt(e) {
        e._currentValue = zr.current, M(zr)
    }

    function Mr(e, t, n) {
        for (; e !== null;) {
            var i = e.alternate;
            if ((e.childLanes & t) !== t ? (e.childLanes |= t, i !== null && (i.childLanes |= t)) : i !== null && (i.childLanes & t) !== t && (i.childLanes |= t), e === n) break;
            e = e.return
        }
    }

    function Br(e, t, n, i) {
        var o = e.child;
        for (o !== null && (o.return = e); o !== null;) {
            var c = o.dependencies;
            if (c !== null) {
                var f = o.child;
                c = c.firstContext;
                e: for (; c !== null;) {
                    var p = c;
                    c = o;
                    for (var b = 0; b < t.length; b++)
                        if (p.context === t[b]) {
                            c.lanes |= n, p = c.alternate, p !== null && (p.lanes |= n), Mr(c.return, n, e), i || (f = null);
                            break e
                        }
                    c = p.next
                }
            } else if (o.tag === 18) {
                if (f = o.return, f === null) throw Error(r(341));
                f.lanes |= n, c = f.alternate, c !== null && (c.lanes |= n), Mr(f, n, e), f = null
            } else f = o.child;
            if (f !== null) f.return = o;
            else
                for (f = o; f !== null;) {
                    if (f === e) {
                        f = null;
                        break
                    }
                    if (o = f.sibling, o !== null) {
                        o.return = f.return, f = o;
                        break
                    }
                    f = f.return
                }
            o = f
        }
    }

    function Ra(e, t, n, i) {
        e = null;
        for (var o = t, c = !1; o !== null;) {
            if (!c) {
                if ((o.flags & 524288) !== 0) c = !0;
                else if ((o.flags & 262144) !== 0) break
            }
            if (o.tag === 10) {
                var f = o.alternate;
                if (f === null) throw Error(r(387));
                if (f = f.memoizedProps, f !== null) {
                    var p = o.type;
                    mt(o.pendingProps.value, f.value) || (e !== null ? e.push(p) : e = [p])
                }
            } else if (o === ge.current) {
                if (f = o.alternate, f === null) throw Error(r(387));
                f.memoizedState.memoizedState !== o.memoizedState.memoizedState && (e !== null ? e.push(Wi) : e = [Wi])
            }
            o = o.return
        }
        e !== null && Br(t, e, n, i), t.flags |= 262144
    }

    function qs(e) {
        for (e = e.firstContext; e !== null;) {
            if (!mt(e.context._currentValue, e.memoizedValue)) return !0;
            e = e.next
        }
        return !1
    }

    function Pn(e) {
        In = e, Pt = null, e = e.dependencies, e !== null && (e.firstContext = null)
    }

    function Ze(e) {
        return Qc(In, e)
    }

    function Ls(e, t) {
        return In === null && Pn(e), Qc(e, t)
    }

    function Qc(e, t) {
        var n = t._currentValue;
        if (t = {
                context: t,
                memoizedValue: n,
                next: null
            }, Pt === null) {
            if (e === null) throw Error(r(308));
            Pt = t, e.dependencies = {
                lanes: 0,
                firstContext: t
            }, e.flags |= 524288
        } else Pt = Pt.next = t;
        return n
    }
    var Qg = typeof AbortController < "u" ? AbortController : function() {
            var e = [],
                t = this.signal = {
                    aborted: !1,
                    addEventListener: function(n, i) {
                        e.push(i)
                    }
                };
            this.abort = function() {
                t.aborted = !0, e.forEach(function(n) {
                    return n()
                })
            }
        },
        Jg = s.unstable_scheduleCallback,
        Zg = s.unstable_NormalPriority,
        Be = {
            $$typeof: q,
            Consumer: null,
            Provider: null,
            _currentValue: null,
            _currentValue2: null,
            _threadCount: 0
        };

    function qr() {
        return {
            controller: new Qg,
            data: new Map,
            refCount: 0
        }
    }

    function Ti(e) {
        e.refCount--, e.refCount === 0 && Jg(Zg, function() {
            e.controller.abort()
        })
    }
    var Ai = null,
        Lr = 0,
        Ca = 0,
        Da = null;

    function Ig(e, t) {
        if (Ai === null) {
            var n = Ai = [];
            Lr = 0, Ca = $o(), Da = {
                status: "pending",
                value: void 0,
                then: function(i) {
                    n.push(i)
                }
            }
        }
        return Lr++, t.then(Jc, Jc), t
    }

    function Jc() {
        if (--Lr === 0 && Ai !== null) {
            Da !== null && (Da.status = "fulfilled");
            var e = Ai;
            Ai = null, Ca = 0, Da = null;
            for (var t = 0; t < e.length; t++)(0, e[t])()
        }
    }

    function Pg(e, t) {
        var n = [],
            i = {
                status: "pending",
                value: null,
                reason: null,
                then: function(o) {
                    n.push(o)
                }
            };
        return e.then(function() {
            i.status = "fulfilled", i.value = t;
            for (var o = 0; o < n.length; o++)(0, n[o])(t)
        }, function(o) {
            for (i.status = "rejected", i.reason = o, o = 0; o < n.length; o++)(0, n[o])(void 0)
        }), i
    }
    var Zc = D.S;
    D.S = function(e, t) {
        Dd = ht(), typeof t == "object" && t !== null && typeof t.then == "function" && Ig(e, t), Zc !== null && Zc(e, t)
    };
    var Wn = S(null);

    function Hr() {
        var e = Wn.current;
        return e !== null ? e : xe.pooledCache
    }

    function Hs(e, t) {
        t === null ? K(Wn, Wn.current) : K(Wn, t.pool)
    }

    function Ic() {
        var e = Hr();
        return e === null ? null : {
            parent: Be._currentValue,
            pool: e
        }
    }
    var Ua = Error(r(460)),
        Gr = Error(r(474)),
        Gs = Error(r(542)),
        Ks = {
            then: function() {}
        };

    function Pc(e) {
        return e = e.status, e === "fulfilled" || e === "rejected"
    }

    function Wc(e, t, n) {
        switch (n = e[n], n === void 0 ? e.push(t) : n !== t && (t.then(Qt, Qt), t = n), t.status) {
            case "fulfilled":
                return t.value;
            case "rejected":
                throw e = t.reason, eh(e), e;
            default:
                if (typeof t.status == "string") t.then(Qt, Qt);
                else {
                    if (e = xe, e !== null && 100 < e.shellSuspendCounter) throw Error(r(482));
                    e = t, e.status = "pending", e.then(function(i) {
                        if (t.status === "pending") {
                            var o = t;
                            o.status = "fulfilled", o.value = i
                        }
                    }, function(i) {
                        if (t.status === "pending") {
                            var o = t;
                            o.status = "rejected", o.reason = i
                        }
                    })
                }
                switch (t.status) {
                    case "fulfilled":
                        return t.value;
                    case "rejected":
                        throw e = t.reason, eh(e), e
                }
                throw ea = t, Ua
        }
    }

    function Fn(e) {
        try {
            var t = e._init;
            return t(e._payload)
        } catch (n) {
            throw n !== null && typeof n == "object" && typeof n.then == "function" ? (ea = n, Ua) : n
        }
    }
    var ea = null;

    function Fc() {
        if (ea === null) throw Error(r(459));
        var e = ea;
        return ea = null, e
    }

    function eh(e) {
        if (e === Ua || e === Gs) throw Error(r(483))
    }
    var ka = null,
        Oi = 0;

    function $s(e) {
        var t = Oi;
        return Oi += 1, ka === null && (ka = []), Wc(ka, e, t)
    }

    function Ni(e, t) {
        t = t.props.ref, e.ref = t !== void 0 ? t : null
    }

    function Ys(e, t) {
        throw t.$$typeof === E ? Error(r(525)) : (e = Object.prototype.toString.call(t), Error(r(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e)))
    }

    function th(e) {
        function t(x, j) {
            if (e) {
                var T = x.deletions;
                T === null ? (x.deletions = [j], x.flags |= 16) : T.push(j)
            }
        }

        function n(x, j) {
            if (!e) return null;
            for (; j !== null;) t(x, j), j = j.sibling;
            return null
        }

        function i(x) {
            for (var j = new Map; x !== null;) x.key !== null ? j.set(x.key, x) : j.set(x.index, x), x = x.sibling;
            return j
        }

        function o(x, j) {
            return x = Zt(x, j), x.index = 0, x.sibling = null, x
        }

        function c(x, j, T) {
            return x.index = T, e ? (T = x.alternate, T !== null ? (T = T.index, T < j ? (x.flags |= 67108866, j) : T) : (x.flags |= 67108866, j)) : (x.flags |= 1048576, j)
        }

        function f(x) {
            return e && x.alternate === null && (x.flags |= 67108866), x
        }

        function p(x, j, T, U) {
            return j === null || j.tag !== 6 ? (j = Nr(T, x.mode, U), j.return = x, j) : (j = o(j, T), j.return = x, j)
        }

        function b(x, j, T, U) {
            var Z = T.type;
            return Z === B ? C(x, j, T.props.children, U, T.key) : j !== null && (j.elementType === Z || typeof Z == "object" && Z !== null && Z.$$typeof === Ne && Fn(Z) === j.type) ? (j = o(j, T.props), Ni(j, T), j.return = x, j) : (j = Ms(T.type, T.key, T.props, null, x.mode, U), Ni(j, T), j.return = x, j)
        }

        function A(x, j, T, U) {
            return j === null || j.tag !== 4 || j.stateNode.containerInfo !== T.containerInfo || j.stateNode.implementation !== T.implementation ? (j = Rr(T, x.mode, U), j.return = x, j) : (j = o(j, T.children || []), j.return = x, j)
        }

        function C(x, j, T, U, Z) {
            return j === null || j.tag !== 7 ? (j = Jn(T, x.mode, U, Z), j.return = x, j) : (j = o(j, T), j.return = x, j)
        }

        function z(x, j, T) {
            if (typeof j == "string" && j !== "" || typeof j == "number" || typeof j == "bigint") return j = Nr("" + j, x.mode, T), j.return = x, j;
            if (typeof j == "object" && j !== null) {
                switch (j.$$typeof) {
                    case O:
                        return T = Ms(j.type, j.key, j.props, null, x.mode, T), Ni(T, j), T.return = x, T;
                    case k:
                        return j = Rr(j, x.mode, T), j.return = x, j;
                    case Ne:
                        return j = Fn(j), z(x, j, T)
                }
                if (Ut(j) || at(j)) return j = Jn(j, x.mode, T, null), j.return = x, j;
                if (typeof j.then == "function") return z(x, $s(j), T);
                if (j.$$typeof === q) return z(x, Ls(x, j), T);
                Ys(x, j)
            }
            return null
        }

        function N(x, j, T, U) {
            var Z = j !== null ? j.key : null;
            if (typeof T == "string" && T !== "" || typeof T == "number" || typeof T == "bigint") return Z !== null ? null : p(x, j, "" + T, U);
            if (typeof T == "object" && T !== null) {
                switch (T.$$typeof) {
                    case O:
                        return T.key === Z ? b(x, j, T, U) : null;
                    case k:
                        return T.key === Z ? A(x, j, T, U) : null;
                    case Ne:
                        return T = Fn(T), N(x, j, T, U)
                }
                if (Ut(T) || at(T)) return Z !== null ? null : C(x, j, T, U, null);
                if (typeof T.then == "function") return N(x, j, $s(T), U);
                if (T.$$typeof === q) return N(x, j, Ls(x, T), U);
                Ys(x, T)
            }
            return null
        }

        function R(x, j, T, U, Z) {
            if (typeof U == "string" && U !== "" || typeof U == "number" || typeof U == "bigint") return x = x.get(T) || null, p(j, x, "" + U, Z);
            if (typeof U == "object" && U !== null) {
                switch (U.$$typeof) {
                    case O:
                        return x = x.get(U.key === null ? T : U.key) || null, b(j, x, U, Z);
                    case k:
                        return x = x.get(U.key === null ? T : U.key) || null, A(j, x, U, Z);
                    case Ne:
                        return U = Fn(U), R(x, j, T, U, Z)
                }
                if (Ut(U) || at(U)) return x = x.get(T) || null, C(j, x, U, Z, null);
                if (typeof U.then == "function") return R(x, j, T, $s(U), Z);
                if (U.$$typeof === q) return R(x, j, T, Ls(j, U), Z);
                Ys(j, U)
            }
            return null
        }

        function Y(x, j, T, U) {
            for (var Z = null, de = null, X = j, se = j = 0, ce = null; X !== null && se < T.length; se++) {
                X.index > se ? (ce = X, X = null) : ce = X.sibling;
                var fe = N(x, X, T[se], U);
                if (fe === null) {
                    X === null && (X = ce);
                    break
                }
                e && X && fe.alternate === null && t(x, X), j = c(fe, j, se), de === null ? Z = fe : de.sibling = fe, de = fe, X = ce
            }
            if (se === T.length) return n(x, X), he && It(x, se), Z;
            if (X === null) {
                for (; se < T.length; se++) X = z(x, T[se], U), X !== null && (j = c(X, j, se), de === null ? Z = X : de.sibling = X, de = X);
                return he && It(x, se), Z
            }
            for (X = i(X); se < T.length; se++) ce = R(X, x, se, T[se], U), ce !== null && (e && ce.alternate !== null && X.delete(ce.key === null ? se : ce.key), j = c(ce, j, se), de === null ? Z = ce : de.sibling = ce, de = ce);
            return e && X.forEach(function(Bn) {
                return t(x, Bn)
            }), he && It(x, se), Z
        }

        function P(x, j, T, U) {
            if (T == null) throw Error(r(151));
            for (var Z = null, de = null, X = j, se = j = 0, ce = null, fe = T.next(); X !== null && !fe.done; se++, fe = T.next()) {
                X.index > se ? (ce = X, X = null) : ce = X.sibling;
                var Bn = N(x, X, fe.value, U);
                if (Bn === null) {
                    X === null && (X = ce);
                    break
                }
                e && X && Bn.alternate === null && t(x, X), j = c(Bn, j, se), de === null ? Z = Bn : de.sibling = Bn, de = Bn, X = ce
            }
            if (fe.done) return n(x, X), he && It(x, se), Z;
            if (X === null) {
                for (; !fe.done; se++, fe = T.next()) fe = z(x, fe.value, U), fe !== null && (j = c(fe, j, se), de === null ? Z = fe : de.sibling = fe, de = fe);
                return he && It(x, se), Z
            }
            for (X = i(X); !fe.done; se++, fe = T.next()) fe = R(X, x, se, fe.value, U), fe !== null && (e && fe.alternate !== null && X.delete(fe.key === null ? se : fe.key), j = c(fe, j, se), de === null ? Z = fe : de.sibling = fe, de = fe);
            return e && X.forEach(function(ov) {
                return t(x, ov)
            }), he && It(x, se), Z
        }

        function Se(x, j, T, U) {
            if (typeof T == "object" && T !== null && T.type === B && T.key === null && (T = T.props.children), typeof T == "object" && T !== null) {
                switch (T.$$typeof) {
                    case O:
                        e: {
                            for (var Z = T.key; j !== null;) {
                                if (j.key === Z) {
                                    if (Z = T.type, Z === B) {
                                        if (j.tag === 7) {
                                            n(x, j.sibling), U = o(j, T.props.children), U.return = x, x = U;
                                            break e
                                        }
                                    } else if (j.elementType === Z || typeof Z == "object" && Z !== null && Z.$$typeof === Ne && Fn(Z) === j.type) {
                                        n(x, j.sibling), U = o(j, T.props), Ni(U, T), U.return = x, x = U;
                                        break e
                                    }
                                    n(x, j);
                                    break
                                } else t(x, j);
                                j = j.sibling
                            }
                            T.type === B ? (U = Jn(T.props.children, x.mode, U, T.key), U.return = x, x = U) : (U = Ms(T.type, T.key, T.props, null, x.mode, U), Ni(U, T), U.return = x, x = U)
                        }
                        return f(x);
                    case k:
                        e: {
                            for (Z = T.key; j !== null;) {
                                if (j.key === Z)
                                    if (j.tag === 4 && j.stateNode.containerInfo === T.containerInfo && j.stateNode.implementation === T.implementation) {
                                        n(x, j.sibling), U = o(j, T.children || []), U.return = x, x = U;
                                        break e
                                    } else {
                                        n(x, j);
                                        break
                                    }
                                else t(x, j);
                                j = j.sibling
                            }
                            U = Rr(T, x.mode, U),
                            U.return = x,
                            x = U
                        }
                        return f(x);
                    case Ne:
                        return T = Fn(T), Se(x, j, T, U)
                }
                if (Ut(T)) return Y(x, j, T, U);
                if (at(T)) {
                    if (Z = at(T), typeof Z != "function") throw Error(r(150));
                    return T = Z.call(T), P(x, j, T, U)
                }
                if (typeof T.then == "function") return Se(x, j, $s(T), U);
                if (T.$$typeof === q) return Se(x, j, Ls(x, T), U);
                Ys(x, T)
            }
            return typeof T == "string" && T !== "" || typeof T == "number" || typeof T == "bigint" ? (T = "" + T, j !== null && j.tag === 6 ? (n(x, j.sibling), U = o(j, T), U.return = x, x = U) : (n(x, j), U = Nr(T, x.mode, U), U.return = x, x = U), f(x)) : n(x, j)
        }
        return function(x, j, T, U) {
            try {
                Oi = 0;
                var Z = Se(x, j, T, U);
                return ka = null, Z
            } catch (X) {
                if (X === Ua || X === Gs) throw X;
                var de = gt(29, X, null, x.mode);
                return de.lanes = U, de.return = x, de
            }
        }
    }
    var ta = th(!0),
        nh = th(!1),
        _n = !1;

    function Kr(e) {
        e.updateQueue = {
            baseState: e.memoizedState,
            firstBaseUpdate: null,
            lastBaseUpdate: null,
            shared: {
                pending: null,
                lanes: 0,
                hiddenCallbacks: null
            },
            callbacks: null
        }
    }

    function $r(e, t) {
        e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
            baseState: e.baseState,
            firstBaseUpdate: e.firstBaseUpdate,
            lastBaseUpdate: e.lastBaseUpdate,
            shared: e.shared,
            callbacks: null
        })
    }

    function jn(e) {
        return {
            lane: e,
            tag: 0,
            payload: null,
            callback: null,
            next: null
        }
    }

    function Sn(e, t, n) {
        var i = e.updateQueue;
        if (i === null) return null;
        if (i = i.shared, (me & 2) !== 0) {
            var o = i.pending;
            return o === null ? t.next = t : (t.next = o.next, o.next = t), i.pending = t, t = zs(e), Lc(e, null, n), t
        }
        return ks(e, i, t, n), zs(e)
    }

    function Ri(e, t, n) {
        if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194048) !== 0)) {
            var i = t.lanes;
            i &= e.pendingLanes, n |= i, t.lanes = n, Qu(e, n)
        }
    }

    function Yr(e, t) {
        var n = e.updateQueue,
            i = e.alternate;
        if (i !== null && (i = i.updateQueue, n === i)) {
            var o = null,
                c = null;
            if (n = n.firstBaseUpdate, n !== null) {
                do {
                    var f = {
                        lane: n.lane,
                        tag: n.tag,
                        payload: n.payload,
                        callback: null,
                        next: null
                    };
                    c === null ? o = c = f : c = c.next = f, n = n.next
                } while (n !== null);
                c === null ? o = c = t : c = c.next = t
            } else o = c = t;
            n = {
                baseState: i.baseState,
                firstBaseUpdate: o,
                lastBaseUpdate: c,
                shared: i.shared,
                callbacks: i.callbacks
            }, e.updateQueue = n;
            return
        }
        e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
    }
    var Vr = !1;

    function Ci() {
        if (Vr) {
            var e = Da;
            if (e !== null) throw e
        }
    }

    function Di(e, t, n, i) {
        Vr = !1;
        var o = e.updateQueue;
        _n = !1;
        var c = o.firstBaseUpdate,
            f = o.lastBaseUpdate,
            p = o.shared.pending;
        if (p !== null) {
            o.shared.pending = null;
            var b = p,
                A = b.next;
            b.next = null, f === null ? c = A : f.next = A, f = b;
            var C = e.alternate;
            C !== null && (C = C.updateQueue, p = C.lastBaseUpdate, p !== f && (p === null ? C.firstBaseUpdate = A : p.next = A, C.lastBaseUpdate = b))
        }
        if (c !== null) {
            var z = o.baseState;
            f = 0, C = A = b = null, p = c;
            do {
                var N = p.lane & -536870913,
                    R = N !== p.lane;
                if (R ? (ue & N) === N : (i & N) === N) {
                    N !== 0 && N === Ca && (Vr = !0), C !== null && (C = C.next = {
                        lane: 0,
                        tag: p.tag,
                        payload: p.payload,
                        callback: null,
                        next: null
                    });
                    e: {
                        var Y = e,
                            P = p;N = t;
                        var Se = n;
                        switch (P.tag) {
                            case 1:
                                if (Y = P.payload, typeof Y == "function") {
                                    z = Y.call(Se, z, N);
                                    break e
                                }
                                z = Y;
                                break e;
                            case 3:
                                Y.flags = Y.flags & -65537 | 128;
                            case 0:
                                if (Y = P.payload, N = typeof Y == "function" ? Y.call(Se, z, N) : Y, N == null) break e;
                                z = w({}, z, N);
                                break e;
                            case 2:
                                _n = !0
                        }
                    }
                    N = p.callback, N !== null && (e.flags |= 64, R && (e.flags |= 8192), R = o.callbacks, R === null ? o.callbacks = [N] : R.push(N))
                } else R = {
                    lane: N,
                    tag: p.tag,
                    payload: p.payload,
                    callback: p.callback,
                    next: null
                }, C === null ? (A = C = R, b = z) : C = C.next = R, f |= N;
                if (p = p.next, p === null) {
                    if (p = o.shared.pending, p === null) break;
                    R = p, p = R.next, R.next = null, o.lastBaseUpdate = R, o.shared.pending = null
                }
            } while (!0);
            C === null && (b = z), o.baseState = b, o.firstBaseUpdate = A, o.lastBaseUpdate = C, c === null && (o.shared.lanes = 0), An |= f, e.lanes = f, e.memoizedState = z
        }
    }

    function ah(e, t) {
        if (typeof e != "function") throw Error(r(191, e));
        e.call(t)
    }

    function ih(e, t) {
        var n = e.callbacks;
        if (n !== null)
            for (e.callbacks = null, e = 0; e < n.length; e++) ah(n[e], t)
    }
    var za = S(null),
        Vs = S(0);

    function sh(e, t) {
        e = on, K(Vs, e), K(za, t), on = e | t.baseLanes
    }

    function Xr() {
        K(Vs, on), K(za, za.current)
    }

    function Qr() {
        on = Vs.current, M(za), M(Vs)
    }
    var pt = S(null),
        Rt = null;

    function wn(e) {
        var t = e.alternate;
        K(ke, ke.current & 1), K(pt, e), Rt === null && (t === null || za.current !== null || t.memoizedState !== null) && (Rt = e)
    }

    function Jr(e) {
        K(ke, ke.current), K(pt, e), Rt === null && (Rt = e)
    }

    function lh(e) {
        e.tag === 22 ? (K(ke, ke.current), K(pt, e), Rt === null && (Rt = e)) : xn()
    }

    function xn() {
        K(ke, ke.current), K(pt, pt.current)
    }

    function vt(e) {
        M(pt), Rt === e && (Rt = null), M(ke)
    }
    var ke = S(0);

    function Xs(e) {
        for (var t = e; t !== null;) {
            if (t.tag === 13) {
                var n = t.memoizedState;
                if (n !== null && (n = n.dehydrated, n === null || tu(n) || nu(n))) return t
            } else if (t.tag === 19 && (t.memoizedProps.revealOrder === "forwards" || t.memoizedProps.revealOrder === "backwards" || t.memoizedProps.revealOrder === "unstable_legacy-backwards" || t.memoizedProps.revealOrder === "together")) {
                if ((t.flags & 128) !== 0) return t
            } else if (t.child !== null) {
                t.child.return = t, t = t.child;
                continue
            }
            if (t === e) break;
            for (; t.sibling === null;) {
                if (t.return === null || t.return === e) return null;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
        return null
    }
    var Ft = 0,
        ae = null,
        _e = null,
        qe = null,
        Qs = !1,
        Ma = !1,
        na = !1,
        Js = 0,
        Ui = 0,
        Ba = null,
        Wg = 0;

    function Re() {
        throw Error(r(321))
    }

    function Zr(e, t) {
        if (t === null) return !1;
        for (var n = 0; n < t.length && n < e.length; n++)
            if (!mt(e[n], t[n])) return !1;
        return !0
    }

    function Ir(e, t, n, i, o, c) {
        return Ft = c, ae = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, D.H = e === null || e.memoizedState === null ? $h : ho, na = !1, c = n(i, o), na = !1, Ma && (c = oh(t, n, i, o)), rh(e), c
    }

    function rh(e) {
        D.H = Mi;
        var t = _e !== null && _e.next !== null;
        if (Ft = 0, qe = _e = ae = null, Qs = !1, Ui = 0, Ba = null, t) throw Error(r(300));
        e === null || Le || (e = e.dependencies, e !== null && qs(e) && (Le = !0))
    }

    function oh(e, t, n, i) {
        ae = e;
        var o = 0;
        do {
            if (Ma && (Ba = null), Ui = 0, Ma = !1, 25 <= o) throw Error(r(301));
            if (o += 1, qe = _e = null, e.updateQueue != null) {
                var c = e.updateQueue;
                c.lastEffect = null, c.events = null, c.stores = null, c.memoCache != null && (c.memoCache.index = 0)
            }
            D.H = Yh, c = t(n, i)
        } while (Ma);
        return c
    }

    function Fg() {
        var e = D.H,
            t = e.useState()[0];
        return t = typeof t.then == "function" ? ki(t) : t, e = e.useState()[0], (_e !== null ? _e.memoizedState : null) !== e && (ae.flags |= 1024), t
    }

    function Pr() {
        var e = Js !== 0;
        return Js = 0, e
    }

    function Wr(e, t, n) {
        t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~n
    }

    function Fr(e) {
        if (Qs) {
            for (e = e.memoizedState; e !== null;) {
                var t = e.queue;
                t !== null && (t.pending = null), e = e.next
            }
            Qs = !1
        }
        Ft = 0, qe = _e = ae = null, Ma = !1, Ui = Js = 0, Ba = null
    }

    function nt() {
        var e = {
            memoizedState: null,
            baseState: null,
            baseQueue: null,
            queue: null,
            next: null
        };
        return qe === null ? ae.memoizedState = qe = e : qe = qe.next = e, qe
    }

    function ze() {
        if (_e === null) {
            var e = ae.alternate;
            e = e !== null ? e.memoizedState : null
        } else e = _e.next;
        var t = qe === null ? ae.memoizedState : qe.next;
        if (t !== null) qe = t, _e = e;
        else {
            if (e === null) throw ae.alternate === null ? Error(r(467)) : Error(r(310));
            _e = e, e = {
                memoizedState: _e.memoizedState,
                baseState: _e.baseState,
                baseQueue: _e.baseQueue,
                queue: _e.queue,
                next: null
            }, qe === null ? ae.memoizedState = qe = e : qe = qe.next = e
        }
        return qe
    }

    function Zs() {
        return {
            lastEffect: null,
            events: null,
            stores: null,
            memoCache: null
        }
    }

    function ki(e) {
        var t = Ui;
        return Ui += 1, Ba === null && (Ba = []), e = Wc(Ba, e, t), t = ae, (qe === null ? t.memoizedState : qe.next) === null && (t = t.alternate, D.H = t === null || t.memoizedState === null ? $h : ho), e
    }

    function Is(e) {
        if (e !== null && typeof e == "object") {
            if (typeof e.then == "function") return ki(e);
            if (e.$$typeof === q) return Ze(e)
        }
        throw Error(r(438, String(e)))
    }

    function eo(e) {
        var t = null,
            n = ae.updateQueue;
        if (n !== null && (t = n.memoCache), t == null) {
            var i = ae.alternate;
            i !== null && (i = i.updateQueue, i !== null && (i = i.memoCache, i != null && (t = {
                data: i.data.map(function(o) {
                    return o.slice()
                }),
                index: 0
            })))
        }
        if (t == null && (t = {
                data: [],
                index: 0
            }), n === null && (n = Zs(), ae.updateQueue = n), n.memoCache = t, n = t.data[t.index], n === void 0)
            for (n = t.data[t.index] = Array(e), i = 0; i < e; i++) n[i] = da;
        return t.index++, n
    }

    function en(e, t) {
        return typeof t == "function" ? t(e) : t
    }

    function Ps(e) {
        var t = ze();
        return to(t, _e, e)
    }

    function to(e, t, n) {
        var i = e.queue;
        if (i === null) throw Error(r(311));
        i.lastRenderedReducer = n;
        var o = e.baseQueue,
            c = i.pending;
        if (c !== null) {
            if (o !== null) {
                var f = o.next;
                o.next = c.next, c.next = f
            }
            t.baseQueue = o = c, i.pending = null
        }
        if (c = e.baseState, o === null) e.memoizedState = c;
        else {
            t = o.next;
            var p = f = null,
                b = null,
                A = t,
                C = !1;
            do {
                var z = A.lane & -536870913;
                if (z !== A.lane ? (ue & z) === z : (Ft & z) === z) {
                    var N = A.revertLane;
                    if (N === 0) b !== null && (b = b.next = {
                        lane: 0,
                        revertLane: 0,
                        gesture: null,
                        action: A.action,
                        hasEagerState: A.hasEagerState,
                        eagerState: A.eagerState,
                        next: null
                    }), z === Ca && (C = !0);
                    else if ((Ft & N) === N) {
                        A = A.next, N === Ca && (C = !0);
                        continue
                    } else z = {
                        lane: 0,
                        revertLane: A.revertLane,
                        gesture: null,
                        action: A.action,
                        hasEagerState: A.hasEagerState,
                        eagerState: A.eagerState,
                        next: null
                    }, b === null ? (p = b = z, f = c) : b = b.next = z, ae.lanes |= N, An |= N;
                    z = A.action, na && n(c, z), c = A.hasEagerState ? A.eagerState : n(c, z)
                } else N = {
                    lane: z,
                    revertLane: A.revertLane,
                    gesture: A.gesture,
                    action: A.action,
                    hasEagerState: A.hasEagerState,
                    eagerState: A.eagerState,
                    next: null
                }, b === null ? (p = b = N, f = c) : b = b.next = N, ae.lanes |= z, An |= z;
                A = A.next
            } while (A !== null && A !== t);
            if (b === null ? f = c : b.next = p, !mt(c, e.memoizedState) && (Le = !0, C && (n = Da, n !== null))) throw n;
            e.memoizedState = c, e.baseState = f, e.baseQueue = b, i.lastRenderedState = c
        }
        return o === null && (i.lanes = 0), [e.memoizedState, i.dispatch]
    }

    function no(e) {
        var t = ze(),
            n = t.queue;
        if (n === null) throw Error(r(311));
        n.lastRenderedReducer = e;
        var i = n.dispatch,
            o = n.pending,
            c = t.memoizedState;
        if (o !== null) {
            n.pending = null;
            var f = o = o.next;
            do c = e(c, f.action), f = f.next; while (f !== o);
            mt(c, t.memoizedState) || (Le = !0), t.memoizedState = c, t.baseQueue === null && (t.baseState = c), n.lastRenderedState = c
        }
        return [c, i]
    }

    function uh(e, t, n) {
        var i = ae,
            o = ze(),
            c = he;
        if (c) {
            if (n === void 0) throw Error(r(407));
            n = n()
        } else n = t();
        var f = !mt((_e || o).memoizedState, n);
        if (f && (o.memoizedState = n, Le = !0), o = o.queue, so(dh.bind(null, i, o, e), [e]), o.getSnapshot !== t || f || qe !== null && qe.memoizedState.tag & 1) {
            if (i.flags |= 2048, qa(9, {
                    destroy: void 0
                }, hh.bind(null, i, o, n, t), null), xe === null) throw Error(r(349));
            c || (Ft & 127) !== 0 || ch(i, t, n)
        }
        return n
    }

    function ch(e, t, n) {
        e.flags |= 16384, e = {
            getSnapshot: t,
            value: n
        }, t = ae.updateQueue, t === null ? (t = Zs(), ae.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
    }

    function hh(e, t, n, i) {
        t.value = n, t.getSnapshot = i, fh(t) && mh(e)
    }

    function dh(e, t, n) {
        return n(function() {
            fh(t) && mh(e)
        })
    }

    function fh(e) {
        var t = e.getSnapshot;
        e = e.value;
        try {
            var n = t();
            return !mt(e, n)
        } catch {
            return !0
        }
    }

    function mh(e) {
        var t = Qn(e, 2);
        t !== null && ct(t, e, 2)
    }

    function ao(e) {
        var t = nt();
        if (typeof e == "function") {
            var n = e;
            if (e = n(), na) {
                fn(!0);
                try {
                    n()
                } finally {
                    fn(!1)
                }
            }
        }
        return t.memoizedState = t.baseState = e, t.queue = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: en,
            lastRenderedState: e
        }, t
    }

    function gh(e, t, n, i) {
        return e.baseState = n, to(e, _e, typeof i == "function" ? i : en)
    }

    function ep(e, t, n, i, o) {
        if (el(e)) throw Error(r(485));
        if (e = t.action, e !== null) {
            var c = {
                payload: o,
                action: e,
                next: null,
                isTransition: !0,
                status: "pending",
                value: null,
                reason: null,
                listeners: [],
                then: function(f) {
                    c.listeners.push(f)
                }
            };
            D.T !== null ? n(!0) : c.isTransition = !1, i(c), n = t.pending, n === null ? (c.next = t.pending = c, ph(t, c)) : (c.next = n.next, t.pending = n.next = c)
        }
    }

    function ph(e, t) {
        var n = t.action,
            i = t.payload,
            o = e.state;
        if (t.isTransition) {
            var c = D.T,
                f = {};
            D.T = f;
            try {
                var p = n(o, i),
                    b = D.S;
                b !== null && b(f, p), vh(e, t, p)
            } catch (A) {
                io(e, t, A)
            } finally {
                c !== null && f.types !== null && (c.types = f.types), D.T = c
            }
        } else try {
            c = n(o, i), vh(e, t, c)
        } catch (A) {
            io(e, t, A)
        }
    }

    function vh(e, t, n) {
        n !== null && typeof n == "object" && typeof n.then == "function" ? n.then(function(i) {
            yh(e, t, i)
        }, function(i) {
            return io(e, t, i)
        }) : yh(e, t, n)
    }

    function yh(e, t, n) {
        t.status = "fulfilled", t.value = n, bh(t), e.state = n, t = e.pending, t !== null && (n = t.next, n === t ? e.pending = null : (n = n.next, t.next = n, ph(e, n)))
    }

    function io(e, t, n) {
        var i = e.pending;
        if (e.pending = null, i !== null) {
            i = i.next;
            do t.status = "rejected", t.reason = n, bh(t), t = t.next; while (t !== i)
        }
        e.action = null
    }

    function bh(e) {
        e = e.listeners;
        for (var t = 0; t < e.length; t++)(0, e[t])()
    }

    function _h(e, t) {
        return t
    }

    function jh(e, t) {
        if (he) {
            var n = xe.formState;
            if (n !== null) {
                e: {
                    var i = ae;
                    if (he) {
                        if (Te) {
                            t: {
                                for (var o = Te, c = Nt; o.nodeType !== 8;) {
                                    if (!c) {
                                        o = null;
                                        break t
                                    }
                                    if (o = Ct(o.nextSibling), o === null) {
                                        o = null;
                                        break t
                                    }
                                }
                                c = o.data,
                                o = c === "F!" || c === "F" ? o : null
                            }
                            if (o) {
                                Te = Ct(o.nextSibling), i = o.data === "F!";
                                break e
                            }
                        }
                        yn(i)
                    }
                    i = !1
                }
                i && (t = n[0])
            }
        }
        return n = nt(), n.memoizedState = n.baseState = t, i = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: _h,
            lastRenderedState: t
        }, n.queue = i, n = Hh.bind(null, ae, i), i.dispatch = n, i = ao(!1), c = co.bind(null, ae, !1, i.queue), i = nt(), o = {
            state: t,
            dispatch: null,
            action: e,
            pending: null
        }, i.queue = o, n = ep.bind(null, ae, o, c, n), o.dispatch = n, i.memoizedState = e, [t, n, !1]
    }

    function Sh(e) {
        var t = ze();
        return wh(t, _e, e)
    }

    function wh(e, t, n) {
        if (t = to(e, t, _h)[0], e = Ps(en)[0], typeof t == "object" && t !== null && typeof t.then == "function") try {
            var i = ki(t)
        } catch (f) {
            throw f === Ua ? Gs : f
        } else i = t;
        t = ze();
        var o = t.queue,
            c = o.dispatch;
        return n !== t.memoizedState && (ae.flags |= 2048, qa(9, {
            destroy: void 0
        }, tp.bind(null, o, n), null)), [i, c, e]
    }

    function tp(e, t) {
        e.action = t
    }

    function xh(e) {
        var t = ze(),
            n = _e;
        if (n !== null) return wh(t, n, e);
        ze(), t = t.memoizedState, n = ze();
        var i = n.queue.dispatch;
        return n.memoizedState = e, [t, i, !1]
    }

    function qa(e, t, n, i) {
        return e = {
            tag: e,
            create: n,
            deps: i,
            inst: t,
            next: null
        }, t = ae.updateQueue, t === null && (t = Zs(), ae.updateQueue = t), n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (i = n.next, n.next = e, e.next = i, t.lastEffect = e), e
    }

    function Eh() {
        return ze().memoizedState
    }

    function Ws(e, t, n, i) {
        var o = nt();
        ae.flags |= e, o.memoizedState = qa(1 | t, {
            destroy: void 0
        }, n, i === void 0 ? null : i)
    }

    function Fs(e, t, n, i) {
        var o = ze();
        i = i === void 0 ? null : i;
        var c = o.memoizedState.inst;
        _e !== null && i !== null && Zr(i, _e.memoizedState.deps) ? o.memoizedState = qa(t, c, n, i) : (ae.flags |= e, o.memoizedState = qa(1 | t, c, n, i))
    }

    function Th(e, t) {
        Ws(8390656, 8, e, t)
    }

    function so(e, t) {
        Fs(2048, 8, e, t)
    }

    function np(e) {
        ae.flags |= 4;
        var t = ae.updateQueue;
        if (t === null) t = Zs(), ae.updateQueue = t, t.events = [e];
        else {
            var n = t.events;
            n === null ? t.events = [e] : n.push(e)
        }
    }

    function Ah(e) {
        var t = ze().memoizedState;
        return np({
                ref: t,
                nextImpl: e
            }),
            function() {
                if ((me & 2) !== 0) throw Error(r(440));
                return t.impl.apply(void 0, arguments)
            }
    }

    function Oh(e, t) {
        return Fs(4, 2, e, t)
    }

    function Nh(e, t) {
        return Fs(4, 4, e, t)
    }

    function Rh(e, t) {
        if (typeof t == "function") {
            e = e();
            var n = t(e);
            return function() {
                typeof n == "function" ? n() : t(null)
            }
        }
        if (t != null) return e = e(), t.current = e,
            function() {
                t.current = null
            }
    }

    function Ch(e, t, n) {
        n = n != null ? n.concat([e]) : null, Fs(4, 4, Rh.bind(null, t, e), n)
    }

    function lo() {}

    function Dh(e, t) {
        var n = ze();
        t = t === void 0 ? null : t;
        var i = n.memoizedState;
        return t !== null && Zr(t, i[1]) ? i[0] : (n.memoizedState = [e, t], e)
    }

    function Uh(e, t) {
        var n = ze();
        t = t === void 0 ? null : t;
        var i = n.memoizedState;
        if (t !== null && Zr(t, i[1])) return i[0];
        if (i = e(), na) {
            fn(!0);
            try {
                e()
            } finally {
                fn(!1)
            }
        }
        return n.memoizedState = [i, t], i
    }

    function ro(e, t, n) {
        return n === void 0 || (Ft & 1073741824) !== 0 && (ue & 261930) === 0 ? e.memoizedState = t : (e.memoizedState = n, e = kd(), ae.lanes |= e, An |= e, n)
    }

    function kh(e, t, n, i) {
        return mt(n, t) ? n : za.current !== null ? (e = ro(e, n, i), mt(e, t) || (Le = !0), e) : (Ft & 42) === 0 || (Ft & 1073741824) !== 0 && (ue & 261930) === 0 ? (Le = !0, e.memoizedState = n) : (e = kd(), ae.lanes |= e, An |= e, t)
    }

    function zh(e, t, n, i, o) {
        var c = G.p;
        G.p = c !== 0 && 8 > c ? c : 8;
        var f = D.T,
            p = {};
        D.T = p, co(e, !1, t, n);
        try {
            var b = o(),
                A = D.S;
            if (A !== null && A(p, b), b !== null && typeof b == "object" && typeof b.then == "function") {
                var C = Pg(b, i);
                zi(e, t, C, _t(e))
            } else zi(e, t, i, _t(e))
        } catch (z) {
            zi(e, t, {
                then: function() {},
                status: "rejected",
                reason: z
            }, _t())
        } finally {
            G.p = c, f !== null && p.types !== null && (f.types = p.types), D.T = f
        }
    }

    function ap() {}

    function oo(e, t, n, i) {
        if (e.tag !== 5) throw Error(r(476));
        var o = Mh(e).queue;
        zh(e, o, t, ee, n === null ? ap : function() {
            return Bh(e), n(i)
        })
    }

    function Mh(e) {
        var t = e.memoizedState;
        if (t !== null) return t;
        t = {
            memoizedState: ee,
            baseState: ee,
            baseQueue: null,
            queue: {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: en,
                lastRenderedState: ee
            },
            next: null
        };
        var n = {};
        return t.next = {
            memoizedState: n,
            baseState: n,
            baseQueue: null,
            queue: {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: en,
                lastRenderedState: n
            },
            next: null
        }, e.memoizedState = t, e = e.alternate, e !== null && (e.memoizedState = t), t
    }

    function Bh(e) {
        var t = Mh(e);
        t.next === null && (t = e.alternate.memoizedState), zi(e, t.next.queue, {}, _t())
    }

    function uo() {
        return Ze(Wi)
    }

    function qh() {
        return ze().memoizedState
    }

    function Lh() {
        return ze().memoizedState
    }

    function ip(e) {
        for (var t = e.return; t !== null;) {
            switch (t.tag) {
                case 24:
                case 3:
                    var n = _t();
                    e = jn(n);
                    var i = Sn(t, e, n);
                    i !== null && (ct(i, t, n), Ri(i, t, n)), t = {
                        cache: qr()
                    }, e.payload = t;
                    return
            }
            t = t.return
        }
    }

    function sp(e, t, n) {
        var i = _t();
        n = {
            lane: i,
            revertLane: 0,
            gesture: null,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        }, el(e) ? Gh(t, n) : (n = Ar(e, t, n, i), n !== null && (ct(n, e, i), Kh(n, t, i)))
    }

    function Hh(e, t, n) {
        var i = _t();
        zi(e, t, n, i)
    }

    function zi(e, t, n, i) {
        var o = {
            lane: i,
            revertLane: 0,
            gesture: null,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        };
        if (el(e)) Gh(t, o);
        else {
            var c = e.alternate;
            if (e.lanes === 0 && (c === null || c.lanes === 0) && (c = t.lastRenderedReducer, c !== null)) try {
                var f = t.lastRenderedState,
                    p = c(f, n);
                if (o.hasEagerState = !0, o.eagerState = p, mt(p, f)) return ks(e, t, o, 0), xe === null && Us(), !1
            } catch {}
            if (n = Ar(e, t, o, i), n !== null) return ct(n, e, i), Kh(n, t, i), !0
        }
        return !1
    }

    function co(e, t, n, i) {
        if (i = {
                lane: 2,
                revertLane: $o(),
                gesture: null,
                action: i,
                hasEagerState: !1,
                eagerState: null,
                next: null
            }, el(e)) {
            if (t) throw Error(r(479))
        } else t = Ar(e, n, i, 2), t !== null && ct(t, e, 2)
    }

    function el(e) {
        var t = e.alternate;
        return e === ae || t !== null && t === ae
    }

    function Gh(e, t) {
        Ma = Qs = !0;
        var n = e.pending;
        n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
    }

    function Kh(e, t, n) {
        if ((n & 4194048) !== 0) {
            var i = t.lanes;
            i &= e.pendingLanes, n |= i, t.lanes = n, Qu(e, n)
        }
    }
    var Mi = {
        readContext: Ze,
        use: Is,
        useCallback: Re,
        useContext: Re,
        useEffect: Re,
        useImperativeHandle: Re,
        useLayoutEffect: Re,
        useInsertionEffect: Re,
        useMemo: Re,
        useReducer: Re,
        useRef: Re,
        useState: Re,
        useDebugValue: Re,
        useDeferredValue: Re,
        useTransition: Re,
        useSyncExternalStore: Re,
        useId: Re,
        useHostTransitionStatus: Re,
        useFormState: Re,
        useActionState: Re,
        useOptimistic: Re,
        useMemoCache: Re,
        useCacheRefresh: Re
    };
    Mi.useEffectEvent = Re;
    var $h = {
            readContext: Ze,
            use: Is,
            useCallback: function(e, t) {
                return nt().memoizedState = [e, t === void 0 ? null : t], e
            },
            useContext: Ze,
            useEffect: Th,
            useImperativeHandle: function(e, t, n) {
                n = n != null ? n.concat([e]) : null, Ws(4194308, 4, Rh.bind(null, t, e), n)
            },
            useLayoutEffect: function(e, t) {
                return Ws(4194308, 4, e, t)
            },
            useInsertionEffect: function(e, t) {
                Ws(4, 2, e, t)
            },
            useMemo: function(e, t) {
                var n = nt();
                t = t === void 0 ? null : t;
                var i = e();
                if (na) {
                    fn(!0);
                    try {
                        e()
                    } finally {
                        fn(!1)
                    }
                }
                return n.memoizedState = [i, t], i
            },
            useReducer: function(e, t, n) {
                var i = nt();
                if (n !== void 0) {
                    var o = n(t);
                    if (na) {
                        fn(!0);
                        try {
                            n(t)
                        } finally {
                            fn(!1)
                        }
                    }
                } else o = t;
                return i.memoizedState = i.baseState = o, e = {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: e,
                    lastRenderedState: o
                }, i.queue = e, e = e.dispatch = sp.bind(null, ae, e), [i.memoizedState, e]
            },
            useRef: function(e) {
                var t = nt();
                return e = {
                    current: e
                }, t.memoizedState = e
            },
            useState: function(e) {
                e = ao(e);
                var t = e.queue,
                    n = Hh.bind(null, ae, t);
                return t.dispatch = n, [e.memoizedState, n]
            },
            useDebugValue: lo,
            useDeferredValue: function(e, t) {
                var n = nt();
                return ro(n, e, t)
            },
            useTransition: function() {
                var e = ao(!1);
                return e = zh.bind(null, ae, e.queue, !0, !1), nt().memoizedState = e, [!1, e]
            },
            useSyncExternalStore: function(e, t, n) {
                var i = ae,
                    o = nt();
                if (he) {
                    if (n === void 0) throw Error(r(407));
                    n = n()
                } else {
                    if (n = t(), xe === null) throw Error(r(349));
                    (ue & 127) !== 0 || ch(i, t, n)
                }
                o.memoizedState = n;
                var c = {
                    value: n,
                    getSnapshot: t
                };
                return o.queue = c, Th(dh.bind(null, i, c, e), [e]), i.flags |= 2048, qa(9, {
                    destroy: void 0
                }, hh.bind(null, i, c, n, t), null), n
            },
            useId: function() {
                var e = nt(),
                    t = xe.identifierPrefix;
                if (he) {
                    var n = Kt,
                        i = Gt;
                    n = (i & ~(1 << 32 - ft(i) - 1)).toString(32) + n, t = "_" + t + "R_" + n, n = Js++, 0 < n && (t += "H" + n.toString(32)), t += "_"
                } else n = Wg++, t = "_" + t + "r_" + n.toString(32) + "_";
                return e.memoizedState = t
            },
            useHostTransitionStatus: uo,
            useFormState: jh,
            useActionState: jh,
            useOptimistic: function(e) {
                var t = nt();
                t.memoizedState = t.baseState = e;
                var n = {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: null,
                    lastRenderedState: null
                };
                return t.queue = n, t = co.bind(null, ae, !0, n), n.dispatch = t, [e, t]
            },
            useMemoCache: eo,
            useCacheRefresh: function() {
                return nt().memoizedState = ip.bind(null, ae)
            },
            useEffectEvent: function(e) {
                var t = nt(),
                    n = {
                        impl: e
                    };
                return t.memoizedState = n,
                    function() {
                        if ((me & 2) !== 0) throw Error(r(440));
                        return n.impl.apply(void 0, arguments)
                    }
            }
        },
        ho = {
            readContext: Ze,
            use: Is,
            useCallback: Dh,
            useContext: Ze,
            useEffect: so,
            useImperativeHandle: Ch,
            useInsertionEffect: Oh,
            useLayoutEffect: Nh,
            useMemo: Uh,
            useReducer: Ps,
            useRef: Eh,
            useState: function() {
                return Ps(en)
            },
            useDebugValue: lo,
            useDeferredValue: function(e, t) {
                var n = ze();
                return kh(n, _e.memoizedState, e, t)
            },
            useTransition: function() {
                var e = Ps(en)[0],
                    t = ze().memoizedState;
                return [typeof e == "boolean" ? e : ki(e), t]
            },
            useSyncExternalStore: uh,
            useId: qh,
            useHostTransitionStatus: uo,
            useFormState: Sh,
            useActionState: Sh,
            useOptimistic: function(e, t) {
                var n = ze();
                return gh(n, _e, e, t)
            },
            useMemoCache: eo,
            useCacheRefresh: Lh
        };
    ho.useEffectEvent = Ah;
    var Yh = {
        readContext: Ze,
        use: Is,
        useCallback: Dh,
        useContext: Ze,
        useEffect: so,
        useImperativeHandle: Ch,
        useInsertionEffect: Oh,
        useLayoutEffect: Nh,
        useMemo: Uh,
        useReducer: no,
        useRef: Eh,
        useState: function() {
            return no(en)
        },
        useDebugValue: lo,
        useDeferredValue: function(e, t) {
            var n = ze();
            return _e === null ? ro(n, e, t) : kh(n, _e.memoizedState, e, t)
        },
        useTransition: function() {
            var e = no(en)[0],
                t = ze().memoizedState;
            return [typeof e == "boolean" ? e : ki(e), t]
        },
        useSyncExternalStore: uh,
        useId: qh,
        useHostTransitionStatus: uo,
        useFormState: xh,
        useActionState: xh,
        useOptimistic: function(e, t) {
            var n = ze();
            return _e !== null ? gh(n, _e, e, t) : (n.baseState = e, [e, n.queue.dispatch])
        },
        useMemoCache: eo,
        useCacheRefresh: Lh
    };
    Yh.useEffectEvent = Ah;

    function fo(e, t, n, i) {
        t = e.memoizedState, n = n(i, t), n = n == null ? t : w({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
    }
    var mo = {
        enqueueSetState: function(e, t, n) {
            e = e._reactInternals;
            var i = _t(),
                o = jn(i);
            o.payload = t, n != null && (o.callback = n), t = Sn(e, o, i), t !== null && (ct(t, e, i), Ri(t, e, i))
        },
        enqueueReplaceState: function(e, t, n) {
            e = e._reactInternals;
            var i = _t(),
                o = jn(i);
            o.tag = 1, o.payload = t, n != null && (o.callback = n), t = Sn(e, o, i), t !== null && (ct(t, e, i), Ri(t, e, i))
        },
        enqueueForceUpdate: function(e, t) {
            e = e._reactInternals;
            var n = _t(),
                i = jn(n);
            i.tag = 2, t != null && (i.callback = t), t = Sn(e, i, n), t !== null && (ct(t, e, n), Ri(t, e, n))
        }
    };

    function Vh(e, t, n, i, o, c, f) {
        return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(i, c, f) : t.prototype && t.prototype.isPureReactComponent ? !Si(n, i) || !Si(o, c) : !0
    }

    function Xh(e, t, n, i) {
        e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, i), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, i), t.state !== e && mo.enqueueReplaceState(t, t.state, null)
    }

    function aa(e, t) {
        var n = t;
        if ("ref" in t) {
            n = {};
            for (var i in t) i !== "ref" && (n[i] = t[i])
        }
        if (e = e.defaultProps) {
            n === t && (n = w({}, n));
            for (var o in e) n[o] === void 0 && (n[o] = e[o])
        }
        return n
    }

    function Qh(e) {
        Ds(e)
    }

    function Jh(e) {
        console.error(e)
    }

    function Zh(e) {
        Ds(e)
    }

    function tl(e, t) {
        try {
            var n = e.onUncaughtError;
            n(t.value, {
                componentStack: t.stack
            })
        } catch (i) {
            setTimeout(function() {
                throw i
            })
        }
    }

    function Ih(e, t, n) {
        try {
            var i = e.onCaughtError;
            i(n.value, {
                componentStack: n.stack,
                errorBoundary: t.tag === 1 ? t.stateNode : null
            })
        } catch (o) {
            setTimeout(function() {
                throw o
            })
        }
    }

    function go(e, t, n) {
        return n = jn(n), n.tag = 3, n.payload = {
            element: null
        }, n.callback = function() {
            tl(e, t)
        }, n
    }

    function Ph(e) {
        return e = jn(e), e.tag = 3, e
    }

    function Wh(e, t, n, i) {
        var o = n.type.getDerivedStateFromError;
        if (typeof o == "function") {
            var c = i.value;
            e.payload = function() {
                return o(c)
            }, e.callback = function() {
                Ih(t, n, i)
            }
        }
        var f = n.stateNode;
        f !== null && typeof f.componentDidCatch == "function" && (e.callback = function() {
            Ih(t, n, i), typeof o != "function" && (On === null ? On = new Set([this]) : On.add(this));
            var p = i.stack;
            this.componentDidCatch(i.value, {
                componentStack: p !== null ? p : ""
            })
        })
    }

    function lp(e, t, n, i, o) {
        if (n.flags |= 32768, i !== null && typeof i == "object" && typeof i.then == "function") {
            if (t = n.alternate, t !== null && Ra(t, n, o, !0), n = pt.current, n !== null) {
                switch (n.tag) {
                    case 31:
                    case 13:
                        return Rt === null ? fl() : n.alternate === null && Ce === 0 && (Ce = 3), n.flags &= -257, n.flags |= 65536, n.lanes = o, i === Ks ? n.flags |= 16384 : (t = n.updateQueue, t === null ? n.updateQueue = new Set([i]) : t.add(i), Ho(e, i, o)), !1;
                    case 22:
                        return n.flags |= 65536, i === Ks ? n.flags |= 16384 : (t = n.updateQueue, t === null ? (t = {
                            transitions: null,
                            markerInstances: null,
                            retryQueue: new Set([i])
                        }, n.updateQueue = t) : (n = t.retryQueue, n === null ? t.retryQueue = new Set([i]) : n.add(i)), Ho(e, i, o)), !1
                }
                throw Error(r(435, n.tag))
            }
            return Ho(e, i, o), fl(), !1
        }
        if (he) return t = pt.current, t !== null ? ((t.flags & 65536) === 0 && (t.flags |= 256), t.flags |= 65536, t.lanes = o, i !== Ur && (e = Error(r(422), {
            cause: i
        }), Ei(Tt(e, n)))) : (i !== Ur && (t = Error(r(423), {
            cause: i
        }), Ei(Tt(t, n))), e = e.current.alternate, e.flags |= 65536, o &= -o, e.lanes |= o, i = Tt(i, n), o = go(e.stateNode, i, o), Yr(e, o), Ce !== 4 && (Ce = 2)), !1;
        var c = Error(r(520), {
            cause: i
        });
        if (c = Tt(c, n), Yi === null ? Yi = [c] : Yi.push(c), Ce !== 4 && (Ce = 2), t === null) return !0;
        i = Tt(i, n), n = t;
        do {
            switch (n.tag) {
                case 3:
                    return n.flags |= 65536, e = o & -o, n.lanes |= e, e = go(n.stateNode, i, e), Yr(n, e), !1;
                case 1:
                    if (t = n.type, c = n.stateNode, (n.flags & 128) === 0 && (typeof t.getDerivedStateFromError == "function" || c !== null && typeof c.componentDidCatch == "function" && (On === null || !On.has(c)))) return n.flags |= 65536, o &= -o, n.lanes |= o, o = Ph(o), Wh(o, e, n, i), Yr(n, o), !1
            }
            n = n.return
        } while (n !== null);
        return !1
    }
    var po = Error(r(461)),
        Le = !1;

    function Ie(e, t, n, i) {
        t.child = e === null ? nh(t, null, n, i) : ta(t, e.child, n, i)
    }

    function Fh(e, t, n, i, o) {
        n = n.render;
        var c = t.ref;
        if ("ref" in i) {
            var f = {};
            for (var p in i) p !== "ref" && (f[p] = i[p])
        } else f = i;
        return Pn(t), i = Ir(e, t, n, f, c, o), p = Pr(), e !== null && !Le ? (Wr(e, t, o), tn(e, t, o)) : (he && p && Cr(t), t.flags |= 1, Ie(e, t, i, o), t.child)
    }

    function ed(e, t, n, i, o) {
        if (e === null) {
            var c = n.type;
            return typeof c == "function" && !Or(c) && c.defaultProps === void 0 && n.compare === null ? (t.tag = 15, t.type = c, td(e, t, c, i, o)) : (e = Ms(n.type, null, i, t, t.mode, o), e.ref = t.ref, e.return = t, t.child = e)
        }
        if (c = e.child, !xo(e, o)) {
            var f = c.memoizedProps;
            if (n = n.compare, n = n !== null ? n : Si, n(f, i) && e.ref === t.ref) return tn(e, t, o)
        }
        return t.flags |= 1, e = Zt(c, i), e.ref = t.ref, e.return = t, t.child = e
    }

    function td(e, t, n, i, o) {
        if (e !== null) {
            var c = e.memoizedProps;
            if (Si(c, i) && e.ref === t.ref)
                if (Le = !1, t.pendingProps = i = c, xo(e, o))(e.flags & 131072) !== 0 && (Le = !0);
                else return t.lanes = e.lanes, tn(e, t, o)
        }
        return vo(e, t, n, i, o)
    }

    function nd(e, t, n, i) {
        var o = i.children,
            c = e !== null ? e.memoizedState : null;
        if (e === null && t.stateNode === null && (t.stateNode = {
                _visibility: 1,
                _pendingMarkers: null,
                _retryCache: null,
                _transitions: null
            }), i.mode === "hidden") {
            if ((t.flags & 128) !== 0) {
                if (c = c !== null ? c.baseLanes | n : n, e !== null) {
                    for (i = t.child = e.child, o = 0; i !== null;) o = o | i.lanes | i.childLanes, i = i.sibling;
                    i = o & ~c
                } else i = 0, t.child = null;
                return ad(e, t, c, n, i)
            }
            if ((n & 536870912) !== 0) t.memoizedState = {
                baseLanes: 0,
                cachePool: null
            }, e !== null && Hs(t, c !== null ? c.cachePool : null), c !== null ? sh(t, c) : Xr(), lh(t);
            else return i = t.lanes = 536870912, ad(e, t, c !== null ? c.baseLanes | n : n, n, i)
        } else c !== null ? (Hs(t, c.cachePool), sh(t, c), xn(), t.memoizedState = null) : (e !== null && Hs(t, null), Xr(), xn());
        return Ie(e, t, o, n), t.child
    }

    function Bi(e, t) {
        return e !== null && e.tag === 22 || t.stateNode !== null || (t.stateNode = {
            _visibility: 1,
            _pendingMarkers: null,
            _retryCache: null,
            _transitions: null
        }), t.sibling
    }

    function ad(e, t, n, i, o) {
        var c = Hr();
        return c = c === null ? null : {
            parent: Be._currentValue,
            pool: c
        }, t.memoizedState = {
            baseLanes: n,
            cachePool: c
        }, e !== null && Hs(t, null), Xr(), lh(t), e !== null && Ra(e, t, i, !0), t.childLanes = o, null
    }

    function nl(e, t) {
        return t = il({
            mode: t.mode,
            children: t.children
        }, e.mode), t.ref = e.ref, e.child = t, t.return = e, t
    }

    function id(e, t, n) {
        return ta(t, e.child, null, n), e = nl(t, t.pendingProps), e.flags |= 2, vt(t), t.memoizedState = null, e
    }

    function rp(e, t, n) {
        var i = t.pendingProps,
            o = (t.flags & 128) !== 0;
        if (t.flags &= -129, e === null) {
            if (he) {
                if (i.mode === "hidden") return e = nl(t, i), t.lanes = 536870912, Bi(null, e);
                if (Jr(t), (e = Te) ? (e = vf(e, Nt), e = e !== null && e.data === "&" ? e : null, e !== null && (t.memoizedState = {
                        dehydrated: e,
                        treeContext: pn !== null ? {
                            id: Gt,
                            overflow: Kt
                        } : null,
                        retryLane: 536870912,
                        hydrationErrors: null
                    }, n = Gc(e), n.return = t, t.child = n, Je = t, Te = null)) : e = null, e === null) throw yn(t);
                return t.lanes = 536870912, null
            }
            return nl(t, i)
        }
        var c = e.memoizedState;
        if (c !== null) {
            var f = c.dehydrated;
            if (Jr(t), o)
                if (t.flags & 256) t.flags &= -257, t = id(e, t, n);
                else if (t.memoizedState !== null) t.child = e.child, t.flags |= 128, t = null;
            else throw Error(r(558));
            else if (Le || Ra(e, t, n, !1), o = (n & e.childLanes) !== 0, Le || o) {
                if (i = xe, i !== null && (f = Ju(i, n), f !== 0 && f !== c.retryLane)) throw c.retryLane = f, Qn(e, f), ct(i, e, f), po;
                fl(), t = id(e, t, n)
            } else e = c.treeContext, Te = Ct(f.nextSibling), Je = t, he = !0, vn = null, Nt = !1, e !== null && Yc(t, e), t = nl(t, i), t.flags |= 4096;
            return t
        }
        return e = Zt(e.child, {
            mode: i.mode,
            children: i.children
        }), e.ref = t.ref, t.child = e, e.return = t, e
    }

    function al(e, t) {
        var n = t.ref;
        if (n === null) e !== null && e.ref !== null && (t.flags |= 4194816);
        else {
            if (typeof n != "function" && typeof n != "object") throw Error(r(284));
            (e === null || e.ref !== n) && (t.flags |= 4194816)
        }
    }

    function vo(e, t, n, i, o) {
        return Pn(t), n = Ir(e, t, n, i, void 0, o), i = Pr(), e !== null && !Le ? (Wr(e, t, o), tn(e, t, o)) : (he && i && Cr(t), t.flags |= 1, Ie(e, t, n, o), t.child)
    }

    function sd(e, t, n, i, o, c) {
        return Pn(t), t.updateQueue = null, n = oh(t, i, n, o), rh(e), i = Pr(), e !== null && !Le ? (Wr(e, t, c), tn(e, t, c)) : (he && i && Cr(t), t.flags |= 1, Ie(e, t, n, c), t.child)
    }

    function ld(e, t, n, i, o) {
        if (Pn(t), t.stateNode === null) {
            var c = Ta,
                f = n.contextType;
            typeof f == "object" && f !== null && (c = Ze(f)), c = new n(i, c), t.memoizedState = c.state !== null && c.state !== void 0 ? c.state : null, c.updater = mo, t.stateNode = c, c._reactInternals = t, c = t.stateNode, c.props = i, c.state = t.memoizedState, c.refs = {}, Kr(t), f = n.contextType, c.context = typeof f == "object" && f !== null ? Ze(f) : Ta, c.state = t.memoizedState, f = n.getDerivedStateFromProps, typeof f == "function" && (fo(t, n, f, i), c.state = t.memoizedState), typeof n.getDerivedStateFromProps == "function" || typeof c.getSnapshotBeforeUpdate == "function" || typeof c.UNSAFE_componentWillMount != "function" && typeof c.componentWillMount != "function" || (f = c.state, typeof c.componentWillMount == "function" && c.componentWillMount(), typeof c.UNSAFE_componentWillMount == "function" && c.UNSAFE_componentWillMount(), f !== c.state && mo.enqueueReplaceState(c, c.state, null), Di(t, i, c, o), Ci(), c.state = t.memoizedState), typeof c.componentDidMount == "function" && (t.flags |= 4194308), i = !0
        } else if (e === null) {
            c = t.stateNode;
            var p = t.memoizedProps,
                b = aa(n, p);
            c.props = b;
            var A = c.context,
                C = n.contextType;
            f = Ta, typeof C == "object" && C !== null && (f = Ze(C));
            var z = n.getDerivedStateFromProps;
            C = typeof z == "function" || typeof c.getSnapshotBeforeUpdate == "function", p = t.pendingProps !== p, C || typeof c.UNSAFE_componentWillReceiveProps != "function" && typeof c.componentWillReceiveProps != "function" || (p || A !== f) && Xh(t, c, i, f), _n = !1;
            var N = t.memoizedState;
            c.state = N, Di(t, i, c, o), Ci(), A = t.memoizedState, p || N !== A || _n ? (typeof z == "function" && (fo(t, n, z, i), A = t.memoizedState), (b = _n || Vh(t, n, b, i, N, A, f)) ? (C || typeof c.UNSAFE_componentWillMount != "function" && typeof c.componentWillMount != "function" || (typeof c.componentWillMount == "function" && c.componentWillMount(), typeof c.UNSAFE_componentWillMount == "function" && c.UNSAFE_componentWillMount()), typeof c.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof c.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = i, t.memoizedState = A), c.props = i, c.state = A, c.context = f, i = b) : (typeof c.componentDidMount == "function" && (t.flags |= 4194308), i = !1)
        } else {
            c = t.stateNode, $r(e, t), f = t.memoizedProps, C = aa(n, f), c.props = C, z = t.pendingProps, N = c.context, A = n.contextType, b = Ta, typeof A == "object" && A !== null && (b = Ze(A)), p = n.getDerivedStateFromProps, (A = typeof p == "function" || typeof c.getSnapshotBeforeUpdate == "function") || typeof c.UNSAFE_componentWillReceiveProps != "function" && typeof c.componentWillReceiveProps != "function" || (f !== z || N !== b) && Xh(t, c, i, b), _n = !1, N = t.memoizedState, c.state = N, Di(t, i, c, o), Ci();
            var R = t.memoizedState;
            f !== z || N !== R || _n || e !== null && e.dependencies !== null && qs(e.dependencies) ? (typeof p == "function" && (fo(t, n, p, i), R = t.memoizedState), (C = _n || Vh(t, n, C, i, N, R, b) || e !== null && e.dependencies !== null && qs(e.dependencies)) ? (A || typeof c.UNSAFE_componentWillUpdate != "function" && typeof c.componentWillUpdate != "function" || (typeof c.componentWillUpdate == "function" && c.componentWillUpdate(i, R, b), typeof c.UNSAFE_componentWillUpdate == "function" && c.UNSAFE_componentWillUpdate(i, R, b)), typeof c.componentDidUpdate == "function" && (t.flags |= 4), typeof c.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof c.componentDidUpdate != "function" || f === e.memoizedProps && N === e.memoizedState || (t.flags |= 4), typeof c.getSnapshotBeforeUpdate != "function" || f === e.memoizedProps && N === e.memoizedState || (t.flags |= 1024), t.memoizedProps = i, t.memoizedState = R), c.props = i, c.state = R, c.context = b, i = C) : (typeof c.componentDidUpdate != "function" || f === e.memoizedProps && N === e.memoizedState || (t.flags |= 4), typeof c.getSnapshotBeforeUpdate != "function" || f === e.memoizedProps && N === e.memoizedState || (t.flags |= 1024), i = !1)
        }
        return c = i, al(e, t), i = (t.flags & 128) !== 0, c || i ? (c = t.stateNode, n = i && typeof n.getDerivedStateFromError != "function" ? null : c.render(), t.flags |= 1, e !== null && i ? (t.child = ta(t, e.child, null, o), t.child = ta(t, null, n, o)) : Ie(e, t, n, o), t.memoizedState = c.state, e = t.child) : e = tn(e, t, o), e
    }

    function rd(e, t, n, i) {
        return Zn(), t.flags |= 256, Ie(e, t, n, i), t.child
    }
    var yo = {
        dehydrated: null,
        treeContext: null,
        retryLane: 0,
        hydrationErrors: null
    };

    function bo(e) {
        return {
            baseLanes: e,
            cachePool: Ic()
        }
    }

    function _o(e, t, n) {
        return e = e !== null ? e.childLanes & ~n : 0, t && (e |= bt), e
    }

    function od(e, t, n) {
        var i = t.pendingProps,
            o = !1,
            c = (t.flags & 128) !== 0,
            f;
        if ((f = c) || (f = e !== null && e.memoizedState === null ? !1 : (ke.current & 2) !== 0), f && (o = !0, t.flags &= -129), f = (t.flags & 32) !== 0, t.flags &= -33, e === null) {
            if (he) {
                if (o ? wn(t) : xn(), (e = Te) ? (e = vf(e, Nt), e = e !== null && e.data !== "&" ? e : null, e !== null && (t.memoizedState = {
                        dehydrated: e,
                        treeContext: pn !== null ? {
                            id: Gt,
                            overflow: Kt
                        } : null,
                        retryLane: 536870912,
                        hydrationErrors: null
                    }, n = Gc(e), n.return = t, t.child = n, Je = t, Te = null)) : e = null, e === null) throw yn(t);
                return nu(e) ? t.lanes = 32 : t.lanes = 536870912, null
            }
            var p = i.children;
            return i = i.fallback, o ? (xn(), o = t.mode, p = il({
                mode: "hidden",
                children: p
            }, o), i = Jn(i, o, n, null), p.return = t, i.return = t, p.sibling = i, t.child = p, i = t.child, i.memoizedState = bo(n), i.childLanes = _o(e, f, n), t.memoizedState = yo, Bi(null, i)) : (wn(t), jo(t, p))
        }
        var b = e.memoizedState;
        if (b !== null && (p = b.dehydrated, p !== null)) {
            if (c) t.flags & 256 ? (wn(t), t.flags &= -257, t = So(e, t, n)) : t.memoizedState !== null ? (xn(), t.child = e.child, t.flags |= 128, t = null) : (xn(), p = i.fallback, o = t.mode, i = il({
                mode: "visible",
                children: i.children
            }, o), p = Jn(p, o, n, null), p.flags |= 2, i.return = t, p.return = t, i.sibling = p, t.child = i, ta(t, e.child, null, n), i = t.child, i.memoizedState = bo(n), i.childLanes = _o(e, f, n), t.memoizedState = yo, t = Bi(null, i));
            else if (wn(t), nu(p)) {
                if (f = p.nextSibling && p.nextSibling.dataset, f) var A = f.dgst;
                f = A, i = Error(r(419)), i.stack = "", i.digest = f, Ei({
                    value: i,
                    source: null,
                    stack: null
                }), t = So(e, t, n)
            } else if (Le || Ra(e, t, n, !1), f = (n & e.childLanes) !== 0, Le || f) {
                if (f = xe, f !== null && (i = Ju(f, n), i !== 0 && i !== b.retryLane)) throw b.retryLane = i, Qn(e, i), ct(f, e, i), po;
                tu(p) || fl(), t = So(e, t, n)
            } else tu(p) ? (t.flags |= 192, t.child = e.child, t = null) : (e = b.treeContext, Te = Ct(p.nextSibling), Je = t, he = !0, vn = null, Nt = !1, e !== null && Yc(t, e), t = jo(t, i.children), t.flags |= 4096);
            return t
        }
        return o ? (xn(), p = i.fallback, o = t.mode, b = e.child, A = b.sibling, i = Zt(b, {
            mode: "hidden",
            children: i.children
        }), i.subtreeFlags = b.subtreeFlags & 65011712, A !== null ? p = Zt(A, p) : (p = Jn(p, o, n, null), p.flags |= 2), p.return = t, i.return = t, i.sibling = p, t.child = i, Bi(null, i), i = t.child, p = e.child.memoizedState, p === null ? p = bo(n) : (o = p.cachePool, o !== null ? (b = Be._currentValue, o = o.parent !== b ? {
            parent: b,
            pool: b
        } : o) : o = Ic(), p = {
            baseLanes: p.baseLanes | n,
            cachePool: o
        }), i.memoizedState = p, i.childLanes = _o(e, f, n), t.memoizedState = yo, Bi(e.child, i)) : (wn(t), n = e.child, e = n.sibling, n = Zt(n, {
            mode: "visible",
            children: i.children
        }), n.return = t, n.sibling = null, e !== null && (f = t.deletions, f === null ? (t.deletions = [e], t.flags |= 16) : f.push(e)), t.child = n, t.memoizedState = null, n)
    }

    function jo(e, t) {
        return t = il({
            mode: "visible",
            children: t
        }, e.mode), t.return = e, e.child = t
    }

    function il(e, t) {
        return e = gt(22, e, null, t), e.lanes = 0, e
    }

    function So(e, t, n) {
        return ta(t, e.child, null, n), e = jo(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
    }

    function ud(e, t, n) {
        e.lanes |= t;
        var i = e.alternate;
        i !== null && (i.lanes |= t), Mr(e.return, t, n)
    }

    function wo(e, t, n, i, o, c) {
        var f = e.memoizedState;
        f === null ? e.memoizedState = {
            isBackwards: t,
            rendering: null,
            renderingStartTime: 0,
            last: i,
            tail: n,
            tailMode: o,
            treeForkCount: c
        } : (f.isBackwards = t, f.rendering = null, f.renderingStartTime = 0, f.last = i, f.tail = n, f.tailMode = o, f.treeForkCount = c)
    }

    function cd(e, t, n) {
        var i = t.pendingProps,
            o = i.revealOrder,
            c = i.tail;
        i = i.children;
        var f = ke.current,
            p = (f & 2) !== 0;
        if (p ? (f = f & 1 | 2, t.flags |= 128) : f &= 1, K(ke, f), Ie(e, t, i, n), i = he ? xi : 0, !p && e !== null && (e.flags & 128) !== 0) e: for (e = t.child; e !== null;) {
            if (e.tag === 13) e.memoizedState !== null && ud(e, n, t);
            else if (e.tag === 19) ud(e, n, t);
            else if (e.child !== null) {
                e.child.return = e, e = e.child;
                continue
            }
            if (e === t) break e;
            for (; e.sibling === null;) {
                if (e.return === null || e.return === t) break e;
                e = e.return
            }
            e.sibling.return = e.return, e = e.sibling
        }
        switch (o) {
            case "forwards":
                for (n = t.child, o = null; n !== null;) e = n.alternate, e !== null && Xs(e) === null && (o = n), n = n.sibling;
                n = o, n === null ? (o = t.child, t.child = null) : (o = n.sibling, n.sibling = null), wo(t, !1, o, n, c, i);
                break;
            case "backwards":
            case "unstable_legacy-backwards":
                for (n = null, o = t.child, t.child = null; o !== null;) {
                    if (e = o.alternate, e !== null && Xs(e) === null) {
                        t.child = o;
                        break
                    }
                    e = o.sibling, o.sibling = n, n = o, o = e
                }
                wo(t, !0, n, null, c, i);
                break;
            case "together":
                wo(t, !1, null, null, void 0, i);
                break;
            default:
                t.memoizedState = null
        }
        return t.child
    }

    function tn(e, t, n) {
        if (e !== null && (t.dependencies = e.dependencies), An |= t.lanes, (n & t.childLanes) === 0)
            if (e !== null) {
                if (Ra(e, t, n, !1), (n & t.childLanes) === 0) return null
            } else return null;
        if (e !== null && t.child !== e.child) throw Error(r(153));
        if (t.child !== null) {
            for (e = t.child, n = Zt(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = Zt(e, e.pendingProps), n.return = t;
            n.sibling = null
        }
        return t.child
    }

    function xo(e, t) {
        return (e.lanes & t) !== 0 ? !0 : (e = e.dependencies, !!(e !== null && qs(e)))
    }

    function op(e, t, n) {
        switch (t.tag) {
            case 3:
                tt(t, t.stateNode.containerInfo), bn(t, Be, e.memoizedState.cache), Zn();
                break;
            case 27:
            case 5:
                ui(t);
                break;
            case 4:
                tt(t, t.stateNode.containerInfo);
                break;
            case 10:
                bn(t, t.type, t.memoizedProps.value);
                break;
            case 31:
                if (t.memoizedState !== null) return t.flags |= 128, Jr(t), null;
                break;
            case 13:
                var i = t.memoizedState;
                if (i !== null) return i.dehydrated !== null ? (wn(t), t.flags |= 128, null) : (n & t.child.childLanes) !== 0 ? od(e, t, n) : (wn(t), e = tn(e, t, n), e !== null ? e.sibling : null);
                wn(t);
                break;
            case 19:
                var o = (e.flags & 128) !== 0;
                if (i = (n & t.childLanes) !== 0, i || (Ra(e, t, n, !1), i = (n & t.childLanes) !== 0), o) {
                    if (i) return cd(e, t, n);
                    t.flags |= 128
                }
                if (o = t.memoizedState, o !== null && (o.rendering = null, o.tail = null, o.lastEffect = null), K(ke, ke.current), i) break;
                return null;
            case 22:
                return t.lanes = 0, nd(e, t, n, t.pendingProps);
            case 24:
                bn(t, Be, e.memoizedState.cache)
        }
        return tn(e, t, n)
    }

    function hd(e, t, n) {
        if (e !== null)
            if (e.memoizedProps !== t.pendingProps) Le = !0;
            else {
                if (!xo(e, n) && (t.flags & 128) === 0) return Le = !1, op(e, t, n);
                Le = (e.flags & 131072) !== 0
            }
        else Le = !1, he && (t.flags & 1048576) !== 0 && $c(t, xi, t.index);
        switch (t.lanes = 0, t.tag) {
            case 16:
                e: {
                    var i = t.pendingProps;
                    if (e = Fn(t.elementType), t.type = e, typeof e == "function") Or(e) ? (i = aa(e, i), t.tag = 1, t = ld(null, t, e, i, n)) : (t.tag = 0, t = vo(null, t, e, i, n));
                    else {
                        if (e != null) {
                            var o = e.$$typeof;
                            if (o === I) {
                                t.tag = 11, t = Fh(null, t, e, i, n);
                                break e
                            } else if (o === J) {
                                t.tag = 14, t = ed(null, t, e, i, n);
                                break e
                            }
                        }
                        throw t = Vt(e) || e, Error(r(306, t, ""))
                    }
                }
                return t;
            case 0:
                return vo(e, t, t.type, t.pendingProps, n);
            case 1:
                return i = t.type, o = aa(i, t.pendingProps), ld(e, t, i, o, n);
            case 3:
                e: {
                    if (tt(t, t.stateNode.containerInfo), e === null) throw Error(r(387));i = t.pendingProps;
                    var c = t.memoizedState;o = c.element,
                    $r(e, t),
                    Di(t, i, null, n);
                    var f = t.memoizedState;
                    if (i = f.cache, bn(t, Be, i), i !== c.cache && Br(t, [Be], n, !0), Ci(), i = f.element, c.isDehydrated)
                        if (c = {
                                element: i,
                                isDehydrated: !1,
                                cache: f.cache
                            }, t.updateQueue.baseState = c, t.memoizedState = c, t.flags & 256) {
                            t = rd(e, t, i, n);
                            break e
                        } else if (i !== o) {
                        o = Tt(Error(r(424)), t), Ei(o), t = rd(e, t, i, n);
                        break e
                    } else
                        for (e = t.stateNode.containerInfo, e.nodeType === 9 ? e = e.body : e = e.nodeName === "HTML" ? e.ownerDocument.body : e, Te = Ct(e.firstChild), Je = t, he = !0, vn = null, Nt = !0, n = nh(t, null, i, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling;
                    else {
                        if (Zn(), i === o) {
                            t = tn(e, t, n);
                            break e
                        }
                        Ie(e, t, i, n)
                    }
                    t = t.child
                }
                return t;
            case 26:
                return al(e, t), e === null ? (n = wf(t.type, null, t.pendingProps, null)) ? t.memoizedState = n : he || (n = t.type, e = t.pendingProps, i = _l(le.current).createElement(n), i[Qe] = t, i[it] = e, Pe(i, n, e), Ye(i), t.stateNode = i) : t.memoizedState = wf(t.type, e.memoizedProps, t.pendingProps, e.memoizedState), null;
            case 27:
                return ui(t), e === null && he && (i = t.stateNode = _f(t.type, t.pendingProps, le.current), Je = t, Nt = !0, o = Te, Dn(t.type) ? (au = o, Te = Ct(i.firstChild)) : Te = o), Ie(e, t, t.pendingProps.children, n), al(e, t), e === null && (t.flags |= 4194304), t.child;
            case 5:
                return e === null && he && ((o = i = Te) && (i = qp(i, t.type, t.pendingProps, Nt), i !== null ? (t.stateNode = i, Je = t, Te = Ct(i.firstChild), Nt = !1, o = !0) : o = !1), o || yn(t)), ui(t), o = t.type, c = t.pendingProps, f = e !== null ? e.memoizedProps : null, i = c.children, Wo(o, c) ? i = null : f !== null && Wo(o, f) && (t.flags |= 32), t.memoizedState !== null && (o = Ir(e, t, Fg, null, null, n), Wi._currentValue = o), al(e, t), Ie(e, t, i, n), t.child;
            case 6:
                return e === null && he && ((e = n = Te) && (n = Lp(n, t.pendingProps, Nt), n !== null ? (t.stateNode = n, Je = t, Te = null, e = !0) : e = !1), e || yn(t)), null;
            case 13:
                return od(e, t, n);
            case 4:
                return tt(t, t.stateNode.containerInfo), i = t.pendingProps, e === null ? t.child = ta(t, null, i, n) : Ie(e, t, i, n), t.child;
            case 11:
                return Fh(e, t, t.type, t.pendingProps, n);
            case 7:
                return Ie(e, t, t.pendingProps, n), t.child;
            case 8:
                return Ie(e, t, t.pendingProps.children, n), t.child;
            case 12:
                return Ie(e, t, t.pendingProps.children, n), t.child;
            case 10:
                return i = t.pendingProps, bn(t, t.type, i.value), Ie(e, t, i.children, n), t.child;
            case 9:
                return o = t.type._context, i = t.pendingProps.children, Pn(t), o = Ze(o), i = i(o), t.flags |= 1, Ie(e, t, i, n), t.child;
            case 14:
                return ed(e, t, t.type, t.pendingProps, n);
            case 15:
                return td(e, t, t.type, t.pendingProps, n);
            case 19:
                return cd(e, t, n);
            case 31:
                return rp(e, t, n);
            case 22:
                return nd(e, t, n, t.pendingProps);
            case 24:
                return Pn(t), i = Ze(Be), e === null ? (o = Hr(), o === null && (o = xe, c = qr(), o.pooledCache = c, c.refCount++, c !== null && (o.pooledCacheLanes |= n), o = c), t.memoizedState = {
                    parent: i,
                    cache: o
                }, Kr(t), bn(t, Be, o)) : ((e.lanes & n) !== 0 && ($r(e, t), Di(t, null, null, n), Ci()), o = e.memoizedState, c = t.memoizedState, o.parent !== i ? (o = {
                    parent: i,
                    cache: i
                }, t.memoizedState = o, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = o), bn(t, Be, i)) : (i = c.cache, bn(t, Be, i), i !== o.cache && Br(t, [Be], n, !0))), Ie(e, t, t.pendingProps.children, n), t.child;
            case 29:
                throw t.pendingProps
        }
        throw Error(r(156, t.tag))
    }

    function nn(e) {
        e.flags |= 4
    }

    function Eo(e, t, n, i, o) {
        if ((t = (e.mode & 32) !== 0) && (t = !1), t) {
            if (e.flags |= 16777216, (o & 335544128) === o)
                if (e.stateNode.complete) e.flags |= 8192;
                else if (qd()) e.flags |= 8192;
            else throw ea = Ks, Gr
        } else e.flags &= -16777217
    }

    function dd(e, t) {
        if (t.type !== "stylesheet" || (t.state.loading & 4) !== 0) e.flags &= -16777217;
        else if (e.flags |= 16777216, !Of(t))
            if (qd()) e.flags |= 8192;
            else throw ea = Ks, Gr
    }

    function sl(e, t) {
        t !== null && (e.flags |= 4), e.flags & 16384 && (t = e.tag !== 22 ? Vu() : 536870912, e.lanes |= t, Ka |= t)
    }

    function qi(e, t) {
        if (!he) switch (e.tailMode) {
            case "hidden":
                t = e.tail;
                for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
                n === null ? e.tail = null : n.sibling = null;
                break;
            case "collapsed":
                n = e.tail;
                for (var i = null; n !== null;) n.alternate !== null && (i = n), n = n.sibling;
                i === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : i.sibling = null
        }
    }

    function Ae(e) {
        var t = e.alternate !== null && e.alternate.child === e.child,
            n = 0,
            i = 0;
        if (t)
            for (var o = e.child; o !== null;) n |= o.lanes | o.childLanes, i |= o.subtreeFlags & 65011712, i |= o.flags & 65011712, o.return = e, o = o.sibling;
        else
            for (o = e.child; o !== null;) n |= o.lanes | o.childLanes, i |= o.subtreeFlags, i |= o.flags, o.return = e, o = o.sibling;
        return e.subtreeFlags |= i, e.childLanes = n, t
    }

    function up(e, t, n) {
        var i = t.pendingProps;
        switch (Dr(t), t.tag) {
            case 16:
            case 15:
            case 0:
            case 11:
            case 7:
            case 8:
            case 12:
            case 9:
            case 14:
                return Ae(t), null;
            case 1:
                return Ae(t), null;
            case 3:
                return n = t.stateNode, i = null, e !== null && (i = e.memoizedState.cache), t.memoizedState.cache !== i && (t.flags |= 2048), Wt(Be), Ue(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (e === null || e.child === null) && (Na(t) ? nn(t) : e === null || e.memoizedState.isDehydrated && (t.flags & 256) === 0 || (t.flags |= 1024, kr())), Ae(t), null;
            case 26:
                var o = t.type,
                    c = t.memoizedState;
                return e === null ? (nn(t), c !== null ? (Ae(t), dd(t, c)) : (Ae(t), Eo(t, o, null, i, n))) : c ? c !== e.memoizedState ? (nn(t), Ae(t), dd(t, c)) : (Ae(t), t.flags &= -16777217) : (e = e.memoizedProps, e !== i && nn(t), Ae(t), Eo(t, o, e, i, n)), null;
            case 27:
                if (ps(t), n = le.current, o = t.type, e !== null && t.stateNode != null) e.memoizedProps !== i && nn(t);
                else {
                    if (!i) {
                        if (t.stateNode === null) throw Error(r(166));
                        return Ae(t), null
                    }
                    e = V.current, Na(t) ? Vc(t) : (e = _f(o, i, n), t.stateNode = e, nn(t))
                }
                return Ae(t), null;
            case 5:
                if (ps(t), o = t.type, e !== null && t.stateNode != null) e.memoizedProps !== i && nn(t);
                else {
                    if (!i) {
                        if (t.stateNode === null) throw Error(r(166));
                        return Ae(t), null
                    }
                    if (c = V.current, Na(t)) Vc(t);
                    else {
                        var f = _l(le.current);
                        switch (c) {
                            case 1:
                                c = f.createElementNS("http://www.w3.org/2000/svg", o);
                                break;
                            case 2:
                                c = f.createElementNS("http://www.w3.org/1998/Math/MathML", o);
                                break;
                            default:
                                switch (o) {
                                    case "svg":
                                        c = f.createElementNS("http://www.w3.org/2000/svg", o);
                                        break;
                                    case "math":
                                        c = f.createElementNS("http://www.w3.org/1998/Math/MathML", o);
                                        break;
                                    case "script":
                                        c = f.createElement("div"), c.innerHTML = "<script><\/script>", c = c.removeChild(c.firstChild);
                                        break;
                                    case "select":
                                        c = typeof i.is == "string" ? f.createElement("select", {
                                            is: i.is
                                        }) : f.createElement("select"), i.multiple ? c.multiple = !0 : i.size && (c.size = i.size);
                                        break;
                                    default:
                                        c = typeof i.is == "string" ? f.createElement(o, {
                                            is: i.is
                                        }) : f.createElement(o)
                                }
                        }
                        c[Qe] = t, c[it] = i;
                        e: for (f = t.child; f !== null;) {
                            if (f.tag === 5 || f.tag === 6) c.appendChild(f.stateNode);
                            else if (f.tag !== 4 && f.tag !== 27 && f.child !== null) {
                                f.child.return = f, f = f.child;
                                continue
                            }
                            if (f === t) break e;
                            for (; f.sibling === null;) {
                                if (f.return === null || f.return === t) break e;
                                f = f.return
                            }
                            f.sibling.return = f.return, f = f.sibling
                        }
                        t.stateNode = c;
                        e: switch (Pe(c, o, i), o) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                i = !!i.autoFocus;
                                break e;
                            case "img":
                                i = !0;
                                break e;
                            default:
                                i = !1
                        }
                        i && nn(t)
                    }
                }
                return Ae(t), Eo(t, t.type, e === null ? null : e.memoizedProps, t.pendingProps, n), null;
            case 6:
                if (e && t.stateNode != null) e.memoizedProps !== i && nn(t);
                else {
                    if (typeof i != "string" && t.stateNode === null) throw Error(r(166));
                    if (e = le.current, Na(t)) {
                        if (e = t.stateNode, n = t.memoizedProps, i = null, o = Je, o !== null) switch (o.tag) {
                            case 27:
                            case 5:
                                i = o.memoizedProps
                        }
                        e[Qe] = t, e = !!(e.nodeValue === n || i !== null && i.suppressHydrationWarning === !0 || uf(e.nodeValue, n)), e || yn(t, !0)
                    } else e = _l(e).createTextNode(i), e[Qe] = t, t.stateNode = e
                }
                return Ae(t), null;
            case 31:
                if (n = t.memoizedState, e === null || e.memoizedState !== null) {
                    if (i = Na(t), n !== null) {
                        if (e === null) {
                            if (!i) throw Error(r(318));
                            if (e = t.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(r(557));
                            e[Qe] = t
                        } else Zn(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
                        Ae(t), e = !1
                    } else n = kr(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = n), e = !0;
                    if (!e) return t.flags & 256 ? (vt(t), t) : (vt(t), null);
                    if ((t.flags & 128) !== 0) throw Error(r(558))
                }
                return Ae(t), null;
            case 13:
                if (i = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
                    if (o = Na(t), i !== null && i.dehydrated !== null) {
                        if (e === null) {
                            if (!o) throw Error(r(318));
                            if (o = t.memoizedState, o = o !== null ? o.dehydrated : null, !o) throw Error(r(317));
                            o[Qe] = t
                        } else Zn(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
                        Ae(t), o = !1
                    } else o = kr(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = o), o = !0;
                    if (!o) return t.flags & 256 ? (vt(t), t) : (vt(t), null)
                }
                return vt(t), (t.flags & 128) !== 0 ? (t.lanes = n, t) : (n = i !== null, e = e !== null && e.memoizedState !== null, n && (i = t.child, o = null, i.alternate !== null && i.alternate.memoizedState !== null && i.alternate.memoizedState.cachePool !== null && (o = i.alternate.memoizedState.cachePool.pool), c = null, i.memoizedState !== null && i.memoizedState.cachePool !== null && (c = i.memoizedState.cachePool.pool), c !== o && (i.flags |= 2048)), n !== e && n && (t.child.flags |= 8192), sl(t, t.updateQueue), Ae(t), null);
            case 4:
                return Ue(), e === null && Qo(t.stateNode.containerInfo), Ae(t), null;
            case 10:
                return Wt(t.type), Ae(t), null;
            case 19:
                if (M(ke), i = t.memoizedState, i === null) return Ae(t), null;
                if (o = (t.flags & 128) !== 0, c = i.rendering, c === null)
                    if (o) qi(i, !1);
                    else {
                        if (Ce !== 0 || e !== null && (e.flags & 128) !== 0)
                            for (e = t.child; e !== null;) {
                                if (c = Xs(e), c !== null) {
                                    for (t.flags |= 128, qi(i, !1), e = c.updateQueue, t.updateQueue = e, sl(t, e), t.subtreeFlags = 0, e = n, n = t.child; n !== null;) Hc(n, e), n = n.sibling;
                                    return K(ke, ke.current & 1 | 2), he && It(t, i.treeForkCount), t.child
                                }
                                e = e.sibling
                            }
                        i.tail !== null && ht() > cl && (t.flags |= 128, o = !0, qi(i, !1), t.lanes = 4194304)
                    }
                else {
                    if (!o)
                        if (e = Xs(c), e !== null) {
                            if (t.flags |= 128, o = !0, e = e.updateQueue, t.updateQueue = e, sl(t, e), qi(i, !0), i.tail === null && i.tailMode === "hidden" && !c.alternate && !he) return Ae(t), null
                        } else 2 * ht() - i.renderingStartTime > cl && n !== 536870912 && (t.flags |= 128, o = !0, qi(i, !1), t.lanes = 4194304);
                    i.isBackwards ? (c.sibling = t.child, t.child = c) : (e = i.last, e !== null ? e.sibling = c : t.child = c, i.last = c)
                }
                return i.tail !== null ? (e = i.tail, i.rendering = e, i.tail = e.sibling, i.renderingStartTime = ht(), e.sibling = null, n = ke.current, K(ke, o ? n & 1 | 2 : n & 1), he && It(t, i.treeForkCount), e) : (Ae(t), null);
            case 22:
            case 23:
                return vt(t), Qr(), i = t.memoizedState !== null, e !== null ? e.memoizedState !== null !== i && (t.flags |= 8192) : i && (t.flags |= 8192), i ? (n & 536870912) !== 0 && (t.flags & 128) === 0 && (Ae(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Ae(t), n = t.updateQueue, n !== null && sl(t, n.retryQueue), n = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), i = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (i = t.memoizedState.cachePool.pool), i !== n && (t.flags |= 2048), e !== null && M(Wn), null;
            case 24:
                return n = null, e !== null && (n = e.memoizedState.cache), t.memoizedState.cache !== n && (t.flags |= 2048), Wt(Be), Ae(t), null;
            case 25:
                return null;
            case 30:
                return null
        }
        throw Error(r(156, t.tag))
    }

    function cp(e, t) {
        switch (Dr(t), t.tag) {
            case 1:
                return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
            case 3:
                return Wt(Be), Ue(), e = t.flags, (e & 65536) !== 0 && (e & 128) === 0 ? (t.flags = e & -65537 | 128, t) : null;
            case 26:
            case 27:
            case 5:
                return ps(t), null;
            case 31:
                if (t.memoizedState !== null) {
                    if (vt(t), t.alternate === null) throw Error(r(340));
                    Zn()
                }
                return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
            case 13:
                if (vt(t), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                    if (t.alternate === null) throw Error(r(340));
                    Zn()
                }
                return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
            case 19:
                return M(ke), null;
            case 4:
                return Ue(), null;
            case 10:
                return Wt(t.type), null;
            case 22:
            case 23:
                return vt(t), Qr(), e !== null && M(Wn), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
            case 24:
                return Wt(Be), null;
            case 25:
                return null;
            default:
                return null
        }
    }

    function fd(e, t) {
        switch (Dr(t), t.tag) {
            case 3:
                Wt(Be), Ue();
                break;
            case 26:
            case 27:
            case 5:
                ps(t);
                break;
            case 4:
                Ue();
                break;
            case 31:
                t.memoizedState !== null && vt(t);
                break;
            case 13:
                vt(t);
                break;
            case 19:
                M(ke);
                break;
            case 10:
                Wt(t.type);
                break;
            case 22:
            case 23:
                vt(t), Qr(), e !== null && M(Wn);
                break;
            case 24:
                Wt(Be)
        }
    }

    function Li(e, t) {
        try {
            var n = t.updateQueue,
                i = n !== null ? n.lastEffect : null;
            if (i !== null) {
                var o = i.next;
                n = o;
                do {
                    if ((n.tag & e) === e) {
                        i = void 0;
                        var c = n.create,
                            f = n.inst;
                        i = c(), f.destroy = i
                    }
                    n = n.next
                } while (n !== o)
            }
        } catch (p) {
            ve(t, t.return, p)
        }
    }

    function En(e, t, n) {
        try {
            var i = t.updateQueue,
                o = i !== null ? i.lastEffect : null;
            if (o !== null) {
                var c = o.next;
                i = c;
                do {
                    if ((i.tag & e) === e) {
                        var f = i.inst,
                            p = f.destroy;
                        if (p !== void 0) {
                            f.destroy = void 0, o = t;
                            var b = n,
                                A = p;
                            try {
                                A()
                            } catch (C) {
                                ve(o, b, C)
                            }
                        }
                    }
                    i = i.next
                } while (i !== c)
            }
        } catch (C) {
            ve(t, t.return, C)
        }
    }

    function md(e) {
        var t = e.updateQueue;
        if (t !== null) {
            var n = e.stateNode;
            try {
                ih(t, n)
            } catch (i) {
                ve(e, e.return, i)
            }
        }
    }

    function gd(e, t, n) {
        n.props = aa(e.type, e.memoizedProps), n.state = e.memoizedState;
        try {
            n.componentWillUnmount()
        } catch (i) {
            ve(e, t, i)
        }
    }

    function Hi(e, t) {
        try {
            var n = e.ref;
            if (n !== null) {
                switch (e.tag) {
                    case 26:
                    case 27:
                    case 5:
                        var i = e.stateNode;
                        break;
                    case 30:
                        i = e.stateNode;
                        break;
                    default:
                        i = e.stateNode
                }
                typeof n == "function" ? e.refCleanup = n(i) : n.current = i
            }
        } catch (o) {
            ve(e, t, o)
        }
    }

    function $t(e, t) {
        var n = e.ref,
            i = e.refCleanup;
        if (n !== null)
            if (typeof i == "function") try {
                i()
            } catch (o) {
                ve(e, t, o)
            } finally {
                e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null)
            } else if (typeof n == "function") try {
                n(null)
            } catch (o) {
                ve(e, t, o)
            } else n.current = null
    }

    function pd(e) {
        var t = e.type,
            n = e.memoizedProps,
            i = e.stateNode;
        try {
            e: switch (t) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                    n.autoFocus && i.focus();
                    break e;
                case "img":
                    n.src ? i.src = n.src : n.srcSet && (i.srcset = n.srcSet)
            }
        }
        catch (o) {
            ve(e, e.return, o)
        }
    }

    function To(e, t, n) {
        try {
            var i = e.stateNode;
            Dp(i, e.type, n, t), i[it] = t
        } catch (o) {
            ve(e, e.return, o)
        }
    }

    function vd(e) {
        return e.tag === 5 || e.tag === 3 || e.tag === 26 || e.tag === 27 && Dn(e.type) || e.tag === 4
    }

    function Ao(e) {
        e: for (;;) {
            for (; e.sibling === null;) {
                if (e.return === null || vd(e.return)) return null;
                e = e.return
            }
            for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
                if (e.tag === 27 && Dn(e.type) || e.flags & 2 || e.child === null || e.tag === 4) continue e;
                e.child.return = e, e = e.child
            }
            if (!(e.flags & 2)) return e.stateNode
        }
    }

    function Oo(e, t, n) {
        var i = e.tag;
        if (i === 5 || i === 6) e = e.stateNode, t ? (n.nodeType === 9 ? n.body : n.nodeName === "HTML" ? n.ownerDocument.body : n).insertBefore(e, t) : (t = n.nodeType === 9 ? n.body : n.nodeName === "HTML" ? n.ownerDocument.body : n, t.appendChild(e), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = Qt));
        else if (i !== 4 && (i === 27 && Dn(e.type) && (n = e.stateNode, t = null), e = e.child, e !== null))
            for (Oo(e, t, n), e = e.sibling; e !== null;) Oo(e, t, n), e = e.sibling
    }

    function ll(e, t, n) {
        var i = e.tag;
        if (i === 5 || i === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
        else if (i !== 4 && (i === 27 && Dn(e.type) && (n = e.stateNode), e = e.child, e !== null))
            for (ll(e, t, n), e = e.sibling; e !== null;) ll(e, t, n), e = e.sibling
    }

    function yd(e) {
        var t = e.stateNode,
            n = e.memoizedProps;
        try {
            for (var i = e.type, o = t.attributes; o.length;) t.removeAttributeNode(o[0]);
            Pe(t, i, n), t[Qe] = e, t[it] = n
        } catch (c) {
            ve(e, e.return, c)
        }
    }
    var an = !1,
        He = !1,
        No = !1,
        bd = typeof WeakSet == "function" ? WeakSet : Set,
        Ve = null;

    function hp(e, t) {
        if (e = e.containerInfo, Io = Al, e = Cc(e), jr(e)) {
            if ("selectionStart" in e) var n = {
                start: e.selectionStart,
                end: e.selectionEnd
            };
            else e: {
                n = (n = e.ownerDocument) && n.defaultView || window;
                var i = n.getSelection && n.getSelection();
                if (i && i.rangeCount !== 0) {
                    n = i.anchorNode;
                    var o = i.anchorOffset,
                        c = i.focusNode;
                    i = i.focusOffset;
                    try {
                        n.nodeType, c.nodeType
                    } catch {
                        n = null;
                        break e
                    }
                    var f = 0,
                        p = -1,
                        b = -1,
                        A = 0,
                        C = 0,
                        z = e,
                        N = null;
                    t: for (;;) {
                        for (var R; z !== n || o !== 0 && z.nodeType !== 3 || (p = f + o), z !== c || i !== 0 && z.nodeType !== 3 || (b = f + i), z.nodeType === 3 && (f += z.nodeValue.length), (R = z.firstChild) !== null;) N = z, z = R;
                        for (;;) {
                            if (z === e) break t;
                            if (N === n && ++A === o && (p = f), N === c && ++C === i && (b = f), (R = z.nextSibling) !== null) break;
                            z = N, N = z.parentNode
                        }
                        z = R
                    }
                    n = p === -1 || b === -1 ? null : {
                        start: p,
                        end: b
                    }
                } else n = null
            }
            n = n || {
                start: 0,
                end: 0
            }
        } else n = null;
        for (Po = {
                focusedElem: e,
                selectionRange: n
            }, Al = !1, Ve = t; Ve !== null;)
            if (t = Ve, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, Ve = e;
            else
                for (; Ve !== null;) {
                    switch (t = Ve, c = t.alternate, e = t.flags, t.tag) {
                        case 0:
                            if ((e & 4) !== 0 && (e = t.updateQueue, e = e !== null ? e.events : null, e !== null))
                                for (n = 0; n < e.length; n++) o = e[n], o.ref.impl = o.nextImpl;
                            break;
                        case 11:
                        case 15:
                            break;
                        case 1:
                            if ((e & 1024) !== 0 && c !== null) {
                                e = void 0, n = t, o = c.memoizedProps, c = c.memoizedState, i = n.stateNode;
                                try {
                                    var Y = aa(n.type, o);
                                    e = i.getSnapshotBeforeUpdate(Y, c), i.__reactInternalSnapshotBeforeUpdate = e
                                } catch (P) {
                                    ve(n, n.return, P)
                                }
                            }
                            break;
                        case 3:
                            if ((e & 1024) !== 0) {
                                if (e = t.stateNode.containerInfo, n = e.nodeType, n === 9) eu(e);
                                else if (n === 1) switch (e.nodeName) {
                                    case "HEAD":
                                    case "HTML":
                                    case "BODY":
                                        eu(e);
                                        break;
                                    default:
                                        e.textContent = ""
                                }
                            }
                            break;
                        case 5:
                        case 26:
                        case 27:
                        case 6:
                        case 4:
                        case 17:
                            break;
                        default:
                            if ((e & 1024) !== 0) throw Error(r(163))
                    }
                    if (e = t.sibling, e !== null) {
                        e.return = t.return, Ve = e;
                        break
                    }
                    Ve = t.return
                }
    }

    function _d(e, t, n) {
        var i = n.flags;
        switch (n.tag) {
            case 0:
            case 11:
            case 15:
                ln(e, n), i & 4 && Li(5, n);
                break;
            case 1:
                if (ln(e, n), i & 4)
                    if (e = n.stateNode, t === null) try {
                        e.componentDidMount()
                    } catch (f) {
                        ve(n, n.return, f)
                    } else {
                        var o = aa(n.type, t.memoizedProps);
                        t = t.memoizedState;
                        try {
                            e.componentDidUpdate(o, t, e.__reactInternalSnapshotBeforeUpdate)
                        } catch (f) {
                            ve(n, n.return, f)
                        }
                    }
                i & 64 && md(n), i & 512 && Hi(n, n.return);
                break;
            case 3:
                if (ln(e, n), i & 64 && (e = n.updateQueue, e !== null)) {
                    if (t = null, n.child !== null) switch (n.child.tag) {
                        case 27:
                        case 5:
                            t = n.child.stateNode;
                            break;
                        case 1:
                            t = n.child.stateNode
                    }
                    try {
                        ih(e, t)
                    } catch (f) {
                        ve(n, n.return, f)
                    }
                }
                break;
            case 27:
                t === null && i & 4 && yd(n);
            case 26:
            case 5:
                ln(e, n), t === null && i & 4 && pd(n), i & 512 && Hi(n, n.return);
                break;
            case 12:
                ln(e, n);
                break;
            case 31:
                ln(e, n), i & 4 && wd(e, n);
                break;
            case 13:
                ln(e, n), i & 4 && xd(e, n), i & 64 && (e = n.memoizedState, e !== null && (e = e.dehydrated, e !== null && (n = _p.bind(null, n), Hp(e, n))));
                break;
            case 22:
                if (i = n.memoizedState !== null || an, !i) {
                    t = t !== null && t.memoizedState !== null || He, o = an;
                    var c = He;
                    an = i, (He = t) && !c ? rn(e, n, (n.subtreeFlags & 8772) !== 0) : ln(e, n), an = o, He = c
                }
                break;
            case 30:
                break;
            default:
                ln(e, n)
        }
    }

    function jd(e) {
        var t = e.alternate;
        t !== null && (e.alternate = null, jd(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && ir(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
    }
    var Oe = null,
        lt = !1;

    function sn(e, t, n) {
        for (n = n.child; n !== null;) Sd(e, t, n), n = n.sibling
    }

    function Sd(e, t, n) {
        if (dt && typeof dt.onCommitFiberUnmount == "function") try {
            dt.onCommitFiberUnmount(ci, n)
        } catch {}
        switch (n.tag) {
            case 26:
                He || $t(n, t), sn(e, t, n), n.memoizedState ? n.memoizedState.count-- : n.stateNode && (n = n.stateNode, n.parentNode.removeChild(n));
                break;
            case 27:
                He || $t(n, t);
                var i = Oe,
                    o = lt;
                Dn(n.type) && (Oe = n.stateNode, lt = !1), sn(e, t, n), Zi(n.stateNode), Oe = i, lt = o;
                break;
            case 5:
                He || $t(n, t);
            case 6:
                if (i = Oe, o = lt, Oe = null, sn(e, t, n), Oe = i, lt = o, Oe !== null)
                    if (lt) try {
                        (Oe.nodeType === 9 ? Oe.body : Oe.nodeName === "HTML" ? Oe.ownerDocument.body : Oe).removeChild(n.stateNode)
                    } catch (c) {
                        ve(n, t, c)
                    } else try {
                        Oe.removeChild(n.stateNode)
                    } catch (c) {
                        ve(n, t, c)
                    }
                break;
            case 18:
                Oe !== null && (lt ? (e = Oe, gf(e.nodeType === 9 ? e.body : e.nodeName === "HTML" ? e.ownerDocument.body : e, n.stateNode), Ia(e)) : gf(Oe, n.stateNode));
                break;
            case 4:
                i = Oe, o = lt, Oe = n.stateNode.containerInfo, lt = !0, sn(e, t, n), Oe = i, lt = o;
                break;
            case 0:
            case 11:
            case 14:
            case 15:
                En(2, n, t), He || En(4, n, t), sn(e, t, n);
                break;
            case 1:
                He || ($t(n, t), i = n.stateNode, typeof i.componentWillUnmount == "function" && gd(n, t, i)), sn(e, t, n);
                break;
            case 21:
                sn(e, t, n);
                break;
            case 22:
                He = (i = He) || n.memoizedState !== null, sn(e, t, n), He = i;
                break;
            default:
                sn(e, t, n)
        }
    }

    function wd(e, t) {
        if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null))) {
            e = e.dehydrated;
            try {
                Ia(e)
            } catch (n) {
                ve(t, t.return, n)
            }
        }
    }

    function xd(e, t) {
        if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null)))) try {
            Ia(e)
        } catch (n) {
            ve(t, t.return, n)
        }
    }

    function dp(e) {
        switch (e.tag) {
            case 31:
            case 13:
            case 19:
                var t = e.stateNode;
                return t === null && (t = e.stateNode = new bd), t;
            case 22:
                return e = e.stateNode, t = e._retryCache, t === null && (t = e._retryCache = new bd), t;
            default:
                throw Error(r(435, e.tag))
        }
    }

    function rl(e, t) {
        var n = dp(e);
        t.forEach(function(i) {
            if (!n.has(i)) {
                n.add(i);
                var o = jp.bind(null, e, i);
                i.then(o, o)
            }
        })
    }

    function rt(e, t) {
        var n = t.deletions;
        if (n !== null)
            for (var i = 0; i < n.length; i++) {
                var o = n[i],
                    c = e,
                    f = t,
                    p = f;
                e: for (; p !== null;) {
                    switch (p.tag) {
                        case 27:
                            if (Dn(p.type)) {
                                Oe = p.stateNode, lt = !1;
                                break e
                            }
                            break;
                        case 5:
                            Oe = p.stateNode, lt = !1;
                            break e;
                        case 3:
                        case 4:
                            Oe = p.stateNode.containerInfo, lt = !0;
                            break e
                    }
                    p = p.return
                }
                if (Oe === null) throw Error(r(160));
                Sd(c, f, o), Oe = null, lt = !1, c = o.alternate, c !== null && (c.return = null), o.return = null
            }
        if (t.subtreeFlags & 13886)
            for (t = t.child; t !== null;) Ed(t, e), t = t.sibling
    }
    var zt = null;

    function Ed(e, t) {
        var n = e.alternate,
            i = e.flags;
        switch (e.tag) {
            case 0:
            case 11:
            case 14:
            case 15:
                rt(t, e), ot(e), i & 4 && (En(3, e, e.return), Li(3, e), En(5, e, e.return));
                break;
            case 1:
                rt(t, e), ot(e), i & 512 && (He || n === null || $t(n, n.return)), i & 64 && an && (e = e.updateQueue, e !== null && (i = e.callbacks, i !== null && (n = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = n === null ? i : n.concat(i))));
                break;
            case 26:
                var o = zt;
                if (rt(t, e), ot(e), i & 512 && (He || n === null || $t(n, n.return)), i & 4) {
                    var c = n !== null ? n.memoizedState : null;
                    if (i = e.memoizedState, n === null)
                        if (i === null)
                            if (e.stateNode === null) {
                                e: {
                                    i = e.type,
                                    n = e.memoizedProps,
                                    o = o.ownerDocument || o;t: switch (i) {
                                        case "title":
                                            c = o.getElementsByTagName("title")[0], (!c || c[fi] || c[Qe] || c.namespaceURI === "http://www.w3.org/2000/svg" || c.hasAttribute("itemprop")) && (c = o.createElement(i), o.head.insertBefore(c, o.querySelector("head > title"))), Pe(c, i, n), c[Qe] = e, Ye(c), i = c;
                                            break e;
                                        case "link":
                                            var f = Tf("link", "href", o).get(i + (n.href || ""));
                                            if (f) {
                                                for (var p = 0; p < f.length; p++)
                                                    if (c = f[p], c.getAttribute("href") === (n.href == null || n.href === "" ? null : n.href) && c.getAttribute("rel") === (n.rel == null ? null : n.rel) && c.getAttribute("title") === (n.title == null ? null : n.title) && c.getAttribute("crossorigin") === (n.crossOrigin == null ? null : n.crossOrigin)) {
                                                        f.splice(p, 1);
                                                        break t
                                                    }
                                            }
                                            c = o.createElement(i), Pe(c, i, n), o.head.appendChild(c);
                                            break;
                                        case "meta":
                                            if (f = Tf("meta", "content", o).get(i + (n.content || ""))) {
                                                for (p = 0; p < f.length; p++)
                                                    if (c = f[p], c.getAttribute("content") === (n.content == null ? null : "" + n.content) && c.getAttribute("name") === (n.name == null ? null : n.name) && c.getAttribute("property") === (n.property == null ? null : n.property) && c.getAttribute("http-equiv") === (n.httpEquiv == null ? null : n.httpEquiv) && c.getAttribute("charset") === (n.charSet == null ? null : n.charSet)) {
                                                        f.splice(p, 1);
                                                        break t
                                                    }
                                            }
                                            c = o.createElement(i), Pe(c, i, n), o.head.appendChild(c);
                                            break;
                                        default:
                                            throw Error(r(468, i))
                                    }
                                    c[Qe] = e,
                                    Ye(c),
                                    i = c
                                }
                                e.stateNode = i
                            }
                    else Af(o, e.type, e.stateNode);
                    else e.stateNode = Ef(o, i, e.memoizedProps);
                    else c !== i ? (c === null ? n.stateNode !== null && (n = n.stateNode, n.parentNode.removeChild(n)) : c.count--, i === null ? Af(o, e.type, e.stateNode) : Ef(o, i, e.memoizedProps)) : i === null && e.stateNode !== null && To(e, e.memoizedProps, n.memoizedProps)
                }
                break;
            case 27:
                rt(t, e), ot(e), i & 512 && (He || n === null || $t(n, n.return)), n !== null && i & 4 && To(e, e.memoizedProps, n.memoizedProps);
                break;
            case 5:
                if (rt(t, e), ot(e), i & 512 && (He || n === null || $t(n, n.return)), e.flags & 32) {
                    o = e.stateNode;
                    try {
                        ba(o, "")
                    } catch (Y) {
                        ve(e, e.return, Y)
                    }
                }
                i & 4 && e.stateNode != null && (o = e.memoizedProps, To(e, o, n !== null ? n.memoizedProps : o)), i & 1024 && (No = !0);
                break;
            case 6:
                if (rt(t, e), ot(e), i & 4) {
                    if (e.stateNode === null) throw Error(r(162));
                    i = e.memoizedProps, n = e.stateNode;
                    try {
                        n.nodeValue = i
                    } catch (Y) {
                        ve(e, e.return, Y)
                    }
                }
                break;
            case 3:
                if (wl = null, o = zt, zt = jl(t.containerInfo), rt(t, e), zt = o, ot(e), i & 4 && n !== null && n.memoizedState.isDehydrated) try {
                    Ia(t.containerInfo)
                } catch (Y) {
                    ve(e, e.return, Y)
                }
                No && (No = !1, Td(e));
                break;
            case 4:
                i = zt, zt = jl(e.stateNode.containerInfo), rt(t, e), ot(e), zt = i;
                break;
            case 12:
                rt(t, e), ot(e);
                break;
            case 31:
                rt(t, e), ot(e), i & 4 && (i = e.updateQueue, i !== null && (e.updateQueue = null, rl(e, i)));
                break;
            case 13:
                rt(t, e), ot(e), e.child.flags & 8192 && e.memoizedState !== null != (n !== null && n.memoizedState !== null) && (ul = ht()), i & 4 && (i = e.updateQueue, i !== null && (e.updateQueue = null, rl(e, i)));
                break;
            case 22:
                o = e.memoizedState !== null;
                var b = n !== null && n.memoizedState !== null,
                    A = an,
                    C = He;
                if (an = A || o, He = C || b, rt(t, e), He = C, an = A, ot(e), i & 8192) e: for (t = e.stateNode, t._visibility = o ? t._visibility & -2 : t._visibility | 1, o && (n === null || b || an || He || ia(e)), n = null, t = e;;) {
                    if (t.tag === 5 || t.tag === 26) {
                        if (n === null) {
                            b = n = t;
                            try {
                                if (c = b.stateNode, o) f = c.style, typeof f.setProperty == "function" ? f.setProperty("display", "none", "important") : f.display = "none";
                                else {
                                    p = b.stateNode;
                                    var z = b.memoizedProps.style,
                                        N = z != null && z.hasOwnProperty("display") ? z.display : null;
                                    p.style.display = N == null || typeof N == "boolean" ? "" : ("" + N).trim()
                                }
                            } catch (Y) {
                                ve(b, b.return, Y)
                            }
                        }
                    } else if (t.tag === 6) {
                        if (n === null) {
                            b = t;
                            try {
                                b.stateNode.nodeValue = o ? "" : b.memoizedProps
                            } catch (Y) {
                                ve(b, b.return, Y)
                            }
                        }
                    } else if (t.tag === 18) {
                        if (n === null) {
                            b = t;
                            try {
                                var R = b.stateNode;
                                o ? pf(R, !0) : pf(b.stateNode, !1)
                            } catch (Y) {
                                ve(b, b.return, Y)
                            }
                        }
                    } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === e) && t.child !== null) {
                        t.child.return = t, t = t.child;
                        continue
                    }
                    if (t === e) break e;
                    for (; t.sibling === null;) {
                        if (t.return === null || t.return === e) break e;
                        n === t && (n = null), t = t.return
                    }
                    n === t && (n = null), t.sibling.return = t.return, t = t.sibling
                }
                i & 4 && (i = e.updateQueue, i !== null && (n = i.retryQueue, n !== null && (i.retryQueue = null, rl(e, n))));
                break;
            case 19:
                rt(t, e), ot(e), i & 4 && (i = e.updateQueue, i !== null && (e.updateQueue = null, rl(e, i)));
                break;
            case 30:
                break;
            case 21:
                break;
            default:
                rt(t, e), ot(e)
        }
    }

    function ot(e) {
        var t = e.flags;
        if (t & 2) {
            try {
                for (var n, i = e.return; i !== null;) {
                    if (vd(i)) {
                        n = i;
                        break
                    }
                    i = i.return
                }
                if (n == null) throw Error(r(160));
                switch (n.tag) {
                    case 27:
                        var o = n.stateNode,
                            c = Ao(e);
                        ll(e, c, o);
                        break;
                    case 5:
                        var f = n.stateNode;
                        n.flags & 32 && (ba(f, ""), n.flags &= -33);
                        var p = Ao(e);
                        ll(e, p, f);
                        break;
                    case 3:
                    case 4:
                        var b = n.stateNode.containerInfo,
                            A = Ao(e);
                        Oo(e, A, b);
                        break;
                    default:
                        throw Error(r(161))
                }
            } catch (C) {
                ve(e, e.return, C)
            }
            e.flags &= -3
        }
        t & 4096 && (e.flags &= -4097)
    }

    function Td(e) {
        if (e.subtreeFlags & 1024)
            for (e = e.child; e !== null;) {
                var t = e;
                Td(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), e = e.sibling
            }
    }

    function ln(e, t) {
        if (t.subtreeFlags & 8772)
            for (t = t.child; t !== null;) _d(e, t.alternate, t), t = t.sibling
    }

    function ia(e) {
        for (e = e.child; e !== null;) {
            var t = e;
            switch (t.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                    En(4, t, t.return), ia(t);
                    break;
                case 1:
                    $t(t, t.return);
                    var n = t.stateNode;
                    typeof n.componentWillUnmount == "function" && gd(t, t.return, n), ia(t);
                    break;
                case 27:
                    Zi(t.stateNode);
                case 26:
                case 5:
                    $t(t, t.return), ia(t);
                    break;
                case 22:
                    t.memoizedState === null && ia(t);
                    break;
                case 30:
                    ia(t);
                    break;
                default:
                    ia(t)
            }
            e = e.sibling
        }
    }

    function rn(e, t, n) {
        for (n = n && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null;) {
            var i = t.alternate,
                o = e,
                c = t,
                f = c.flags;
            switch (c.tag) {
                case 0:
                case 11:
                case 15:
                    rn(o, c, n), Li(4, c);
                    break;
                case 1:
                    if (rn(o, c, n), i = c, o = i.stateNode, typeof o.componentDidMount == "function") try {
                        o.componentDidMount()
                    } catch (A) {
                        ve(i, i.return, A)
                    }
                    if (i = c, o = i.updateQueue, o !== null) {
                        var p = i.stateNode;
                        try {
                            var b = o.shared.hiddenCallbacks;
                            if (b !== null)
                                for (o.shared.hiddenCallbacks = null, o = 0; o < b.length; o++) ah(b[o], p)
                        } catch (A) {
                            ve(i, i.return, A)
                        }
                    }
                    n && f & 64 && md(c), Hi(c, c.return);
                    break;
                case 27:
                    yd(c);
                case 26:
                case 5:
                    rn(o, c, n), n && i === null && f & 4 && pd(c), Hi(c, c.return);
                    break;
                case 12:
                    rn(o, c, n);
                    break;
                case 31:
                    rn(o, c, n), n && f & 4 && wd(o, c);
                    break;
                case 13:
                    rn(o, c, n), n && f & 4 && xd(o, c);
                    break;
                case 22:
                    c.memoizedState === null && rn(o, c, n), Hi(c, c.return);
                    break;
                case 30:
                    break;
                default:
                    rn(o, c, n)
            }
            t = t.sibling
        }
    }

    function Ro(e, t) {
        var n = null;
        e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== n && (e != null && e.refCount++, n != null && Ti(n))
    }

    function Co(e, t) {
        e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && Ti(e))
    }

    function Mt(e, t, n, i) {
        if (t.subtreeFlags & 10256)
            for (t = t.child; t !== null;) Ad(e, t, n, i), t = t.sibling
    }

    function Ad(e, t, n, i) {
        var o = t.flags;
        switch (t.tag) {
            case 0:
            case 11:
            case 15:
                Mt(e, t, n, i), o & 2048 && Li(9, t);
                break;
            case 1:
                Mt(e, t, n, i);
                break;
            case 3:
                Mt(e, t, n, i), o & 2048 && (e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && Ti(e)));
                break;
            case 12:
                if (o & 2048) {
                    Mt(e, t, n, i), e = t.stateNode;
                    try {
                        var c = t.memoizedProps,
                            f = c.id,
                            p = c.onPostCommit;
                        typeof p == "function" && p(f, t.alternate === null ? "mount" : "update", e.passiveEffectDuration, -0)
                    } catch (b) {
                        ve(t, t.return, b)
                    }
                } else Mt(e, t, n, i);
                break;
            case 31:
                Mt(e, t, n, i);
                break;
            case 13:
                Mt(e, t, n, i);
                break;
            case 23:
                break;
            case 22:
                c = t.stateNode, f = t.alternate, t.memoizedState !== null ? c._visibility & 2 ? Mt(e, t, n, i) : Gi(e, t) : c._visibility & 2 ? Mt(e, t, n, i) : (c._visibility |= 2, La(e, t, n, i, (t.subtreeFlags & 10256) !== 0 || !1)), o & 2048 && Ro(f, t);
                break;
            case 24:
                Mt(e, t, n, i), o & 2048 && Co(t.alternate, t);
                break;
            default:
                Mt(e, t, n, i)
        }
    }

    function La(e, t, n, i, o) {
        for (o = o && ((t.subtreeFlags & 10256) !== 0 || !1), t = t.child; t !== null;) {
            var c = e,
                f = t,
                p = n,
                b = i,
                A = f.flags;
            switch (f.tag) {
                case 0:
                case 11:
                case 15:
                    La(c, f, p, b, o), Li(8, f);
                    break;
                case 23:
                    break;
                case 22:
                    var C = f.stateNode;
                    f.memoizedState !== null ? C._visibility & 2 ? La(c, f, p, b, o) : Gi(c, f) : (C._visibility |= 2, La(c, f, p, b, o)), o && A & 2048 && Ro(f.alternate, f);
                    break;
                case 24:
                    La(c, f, p, b, o), o && A & 2048 && Co(f.alternate, f);
                    break;
                default:
                    La(c, f, p, b, o)
            }
            t = t.sibling
        }
    }

    function Gi(e, t) {
        if (t.subtreeFlags & 10256)
            for (t = t.child; t !== null;) {
                var n = e,
                    i = t,
                    o = i.flags;
                switch (i.tag) {
                    case 22:
                        Gi(n, i), o & 2048 && Ro(i.alternate, i);
                        break;
                    case 24:
                        Gi(n, i), o & 2048 && Co(i.alternate, i);
                        break;
                    default:
                        Gi(n, i)
                }
                t = t.sibling
            }
    }
    var Ki = 8192;

    function Ha(e, t, n) {
        if (e.subtreeFlags & Ki)
            for (e = e.child; e !== null;) Od(e, t, n), e = e.sibling
    }

    function Od(e, t, n) {
        switch (e.tag) {
            case 26:
                Ha(e, t, n), e.flags & Ki && e.memoizedState !== null && Wp(n, zt, e.memoizedState, e.memoizedProps);
                break;
            case 5:
                Ha(e, t, n);
                break;
            case 3:
            case 4:
                var i = zt;
                zt = jl(e.stateNode.containerInfo), Ha(e, t, n), zt = i;
                break;
            case 22:
                e.memoizedState === null && (i = e.alternate, i !== null && i.memoizedState !== null ? (i = Ki, Ki = 16777216, Ha(e, t, n), Ki = i) : Ha(e, t, n));
                break;
            default:
                Ha(e, t, n)
        }
    }

    function Nd(e) {
        var t = e.alternate;
        if (t !== null && (e = t.child, e !== null)) {
            t.child = null;
            do t = e.sibling, e.sibling = null, e = t; while (e !== null)
        }
    }

    function $i(e) {
        var t = e.deletions;
        if ((e.flags & 16) !== 0) {
            if (t !== null)
                for (var n = 0; n < t.length; n++) {
                    var i = t[n];
                    Ve = i, Cd(i, e)
                }
            Nd(e)
        }
        if (e.subtreeFlags & 10256)
            for (e = e.child; e !== null;) Rd(e), e = e.sibling
    }

    function Rd(e) {
        switch (e.tag) {
            case 0:
            case 11:
            case 15:
                $i(e), e.flags & 2048 && En(9, e, e.return);
                break;
            case 3:
                $i(e);
                break;
            case 12:
                $i(e);
                break;
            case 22:
                var t = e.stateNode;
                e.memoizedState !== null && t._visibility & 2 && (e.return === null || e.return.tag !== 13) ? (t._visibility &= -3, ol(e)) : $i(e);
                break;
            default:
                $i(e)
        }
    }

    function ol(e) {
        var t = e.deletions;
        if ((e.flags & 16) !== 0) {
            if (t !== null)
                for (var n = 0; n < t.length; n++) {
                    var i = t[n];
                    Ve = i, Cd(i, e)
                }
            Nd(e)
        }
        for (e = e.child; e !== null;) {
            switch (t = e, t.tag) {
                case 0:
                case 11:
                case 15:
                    En(8, t, t.return), ol(t);
                    break;
                case 22:
                    n = t.stateNode, n._visibility & 2 && (n._visibility &= -3, ol(t));
                    break;
                default:
                    ol(t)
            }
            e = e.sibling
        }
    }

    function Cd(e, t) {
        for (; Ve !== null;) {
            var n = Ve;
            switch (n.tag) {
                case 0:
                case 11:
                case 15:
                    En(8, n, t);
                    break;
                case 23:
                case 22:
                    if (n.memoizedState !== null && n.memoizedState.cachePool !== null) {
                        var i = n.memoizedState.cachePool.pool;
                        i != null && i.refCount++
                    }
                    break;
                case 24:
                    Ti(n.memoizedState.cache)
            }
            if (i = n.child, i !== null) i.return = n, Ve = i;
            else e: for (n = e; Ve !== null;) {
                i = Ve;
                var o = i.sibling,
                    c = i.return;
                if (jd(i), i === n) {
                    Ve = null;
                    break e
                }
                if (o !== null) {
                    o.return = c, Ve = o;
                    break e
                }
                Ve = c
            }
        }
    }
    var fp = {
            getCacheForType: function(e) {
                var t = Ze(Be),
                    n = t.data.get(e);
                return n === void 0 && (n = e(), t.data.set(e, n)), n
            },
            cacheSignal: function() {
                return Ze(Be).controller.signal
            }
        },
        mp = typeof WeakMap == "function" ? WeakMap : Map,
        me = 0,
        xe = null,
        re = null,
        ue = 0,
        pe = 0,
        yt = null,
        Tn = !1,
        Ga = !1,
        Do = !1,
        on = 0,
        Ce = 0,
        An = 0,
        sa = 0,
        Uo = 0,
        bt = 0,
        Ka = 0,
        Yi = null,
        ut = null,
        ko = !1,
        ul = 0,
        Dd = 0,
        cl = 1 / 0,
        hl = null,
        On = null,
        Ke = 0,
        Nn = null,
        $a = null,
        un = 0,
        zo = 0,
        Mo = null,
        Ud = null,
        Vi = 0,
        Bo = null;

    function _t() {
        return (me & 2) !== 0 && ue !== 0 ? ue & -ue : D.T !== null ? $o() : Zu()
    }

    function kd() {
        if (bt === 0)
            if ((ue & 536870912) === 0 || he) {
                var e = bs;
                bs <<= 1, (bs & 3932160) === 0 && (bs = 262144), bt = e
            } else bt = 536870912;
        return e = pt.current, e !== null && (e.flags |= 32), bt
    }

    function ct(e, t, n) {
        (e === xe && (pe === 2 || pe === 9) || e.cancelPendingCommit !== null) && (Ya(e, 0), Rn(e, ue, bt, !1)), di(e, n), ((me & 2) === 0 || e !== xe) && (e === xe && ((me & 2) === 0 && (sa |= n), Ce === 4 && Rn(e, ue, bt, !1)), Yt(e))
    }

    function zd(e, t, n) {
        if ((me & 6) !== 0) throw Error(r(327));
        var i = !n && (t & 127) === 0 && (t & e.expiredLanes) === 0 || hi(e, t),
            o = i ? vp(e, t) : Lo(e, t, !0),
            c = i;
        do {
            if (o === 0) {
                Ga && !i && Rn(e, t, 0, !1);
                break
            } else {
                if (n = e.current.alternate, c && !gp(n)) {
                    o = Lo(e, t, !1), c = !1;
                    continue
                }
                if (o === 2) {
                    if (c = t, e.errorRecoveryDisabledLanes & c) var f = 0;
                    else f = e.pendingLanes & -536870913, f = f !== 0 ? f : f & 536870912 ? 536870912 : 0;
                    if (f !== 0) {
                        t = f;
                        e: {
                            var p = e;o = Yi;
                            var b = p.current.memoizedState.isDehydrated;
                            if (b && (Ya(p, f).flags |= 256), f = Lo(p, f, !1), f !== 2) {
                                if (Do && !b) {
                                    p.errorRecoveryDisabledLanes |= c, sa |= c, o = 4;
                                    break e
                                }
                                c = ut, ut = o, c !== null && (ut === null ? ut = c : ut.push.apply(ut, c))
                            }
                            o = f
                        }
                        if (c = !1, o !== 2) continue
                    }
                }
                if (o === 1) {
                    Ya(e, 0), Rn(e, t, 0, !0);
                    break
                }
                e: {
                    switch (i = e, c = o, c) {
                        case 0:
                        case 1:
                            throw Error(r(345));
                        case 4:
                            if ((t & 4194048) !== t) break;
                        case 6:
                            Rn(i, t, bt, !Tn);
                            break e;
                        case 2:
                            ut = null;
                            break;
                        case 3:
                        case 5:
                            break;
                        default:
                            throw Error(r(329))
                    }
                    if ((t & 62914560) === t && (o = ul + 300 - ht(), 10 < o)) {
                        if (Rn(i, t, bt, !Tn), js(i, 0, !0) !== 0) break e;
                        un = t, i.timeoutHandle = ff(Md.bind(null, i, n, ut, hl, ko, t, bt, sa, Ka, Tn, c, "Throttled", -0, 0), o);
                        break e
                    }
                    Md(i, n, ut, hl, ko, t, bt, sa, Ka, Tn, c, null, -0, 0)
                }
            }
            break
        } while (!0);
        Yt(e)
    }

    function Md(e, t, n, i, o, c, f, p, b, A, C, z, N, R) {
        if (e.timeoutHandle = -1, z = t.subtreeFlags, z & 8192 || (z & 16785408) === 16785408) {
            z = {
                stylesheets: null,
                count: 0,
                imgCount: 0,
                imgBytes: 0,
                suspenseyImages: [],
                waitingForImages: !0,
                waitingForViewTransition: !1,
                unsuspend: Qt
            }, Od(t, c, z);
            var Y = (c & 62914560) === c ? ul - ht() : (c & 4194048) === c ? Dd - ht() : 0;
            if (Y = Fp(z, Y), Y !== null) {
                un = c, e.cancelPendingCommit = Y(Yd.bind(null, e, t, c, n, i, o, f, p, b, C, z, null, N, R)), Rn(e, c, f, !A);
                return
            }
        }
        Yd(e, t, c, n, i, o, f, p, b)
    }

    function gp(e) {
        for (var t = e;;) {
            var n = t.tag;
            if ((n === 0 || n === 11 || n === 15) && t.flags & 16384 && (n = t.updateQueue, n !== null && (n = n.stores, n !== null)))
                for (var i = 0; i < n.length; i++) {
                    var o = n[i],
                        c = o.getSnapshot;
                    o = o.value;
                    try {
                        if (!mt(c(), o)) return !1
                    } catch {
                        return !1
                    }
                }
            if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
            else {
                if (t === e) break;
                for (; t.sibling === null;) {
                    if (t.return === null || t.return === e) return !0;
                    t = t.return
                }
                t.sibling.return = t.return, t = t.sibling
            }
        }
        return !0
    }

    function Rn(e, t, n, i) {
        t &= ~Uo, t &= ~sa, e.suspendedLanes |= t, e.pingedLanes &= ~t, i && (e.warmLanes |= t), i = e.expirationTimes;
        for (var o = t; 0 < o;) {
            var c = 31 - ft(o),
                f = 1 << c;
            i[c] = -1, o &= ~f
        }
        n !== 0 && Xu(e, n, t)
    }

    function dl() {
        return (me & 6) === 0 ? (Xi(0), !1) : !0
    }

    function qo() {
        if (re !== null) {
            if (pe === 0) var e = re.return;
            else e = re, Pt = In = null, Fr(e), ka = null, Oi = 0, e = re;
            for (; e !== null;) fd(e.alternate, e), e = e.return;
            re = null
        }
    }

    function Ya(e, t) {
        var n = e.timeoutHandle;
        n !== -1 && (e.timeoutHandle = -1, zp(n)), n = e.cancelPendingCommit, n !== null && (e.cancelPendingCommit = null, n()), un = 0, qo(), xe = e, re = n = Zt(e.current, null), ue = t, pe = 0, yt = null, Tn = !1, Ga = hi(e, t), Do = !1, Ka = bt = Uo = sa = An = Ce = 0, ut = Yi = null, ko = !1, (t & 8) !== 0 && (t |= t & 32);
        var i = e.entangledLanes;
        if (i !== 0)
            for (e = e.entanglements, i &= t; 0 < i;) {
                var o = 31 - ft(i),
                    c = 1 << o;
                t |= e[o], i &= ~c
            }
        return on = t, Us(), n
    }

    function Bd(e, t) {
        ae = null, D.H = Mi, t === Ua || t === Gs ? (t = Fc(), pe = 3) : t === Gr ? (t = Fc(), pe = 4) : pe = t === po ? 8 : t !== null && typeof t == "object" && typeof t.then == "function" ? 6 : 1, yt = t, re === null && (Ce = 1, tl(e, Tt(t, e.current)))
    }

    function qd() {
        var e = pt.current;
        return e === null ? !0 : (ue & 4194048) === ue ? Rt === null : (ue & 62914560) === ue || (ue & 536870912) !== 0 ? e === Rt : !1
    }

    function Ld() {
        var e = D.H;
        return D.H = Mi, e === null ? Mi : e
    }

    function Hd() {
        var e = D.A;
        return D.A = fp, e
    }

    function fl() {
        Ce = 4, Tn || (ue & 4194048) !== ue && pt.current !== null || (Ga = !0), (An & 134217727) === 0 && (sa & 134217727) === 0 || xe === null || Rn(xe, ue, bt, !1)
    }

    function Lo(e, t, n) {
        var i = me;
        me |= 2;
        var o = Ld(),
            c = Hd();
        (xe !== e || ue !== t) && (hl = null, Ya(e, t)), t = !1;
        var f = Ce;
        e: do try {
                if (pe !== 0 && re !== null) {
                    var p = re,
                        b = yt;
                    switch (pe) {
                        case 8:
                            qo(), f = 6;
                            break e;
                        case 3:
                        case 2:
                        case 9:
                        case 6:
                            pt.current === null && (t = !0);
                            var A = pe;
                            if (pe = 0, yt = null, Va(e, p, b, A), n && Ga) {
                                f = 0;
                                break e
                            }
                            break;
                        default:
                            A = pe, pe = 0, yt = null, Va(e, p, b, A)
                    }
                }
                pp(), f = Ce;
                break
            } catch (C) {
                Bd(e, C)
            }
            while (!0);
            return t && e.shellSuspendCounter++, Pt = In = null, me = i, D.H = o, D.A = c, re === null && (xe = null, ue = 0, Us()), f
    }

    function pp() {
        for (; re !== null;) Gd(re)
    }

    function vp(e, t) {
        var n = me;
        me |= 2;
        var i = Ld(),
            o = Hd();
        xe !== e || ue !== t ? (hl = null, cl = ht() + 500, Ya(e, t)) : Ga = hi(e, t);
        e: do try {
                if (pe !== 0 && re !== null) {
                    t = re;
                    var c = yt;
                    t: switch (pe) {
                        case 1:
                            pe = 0, yt = null, Va(e, t, c, 1);
                            break;
                        case 2:
                        case 9:
                            if (Pc(c)) {
                                pe = 0, yt = null, Kd(t);
                                break
                            }
                            t = function() {
                                pe !== 2 && pe !== 9 || xe !== e || (pe = 7), Yt(e)
                            }, c.then(t, t);
                            break e;
                        case 3:
                            pe = 7;
                            break e;
                        case 4:
                            pe = 5;
                            break e;
                        case 7:
                            Pc(c) ? (pe = 0, yt = null, Kd(t)) : (pe = 0, yt = null, Va(e, t, c, 7));
                            break;
                        case 5:
                            var f = null;
                            switch (re.tag) {
                                case 26:
                                    f = re.memoizedState;
                                case 5:
                                case 27:
                                    var p = re;
                                    if (f ? Of(f) : p.stateNode.complete) {
                                        pe = 0, yt = null;
                                        var b = p.sibling;
                                        if (b !== null) re = b;
                                        else {
                                            var A = p.return;
                                            A !== null ? (re = A, ml(A)) : re = null
                                        }
                                        break t
                                    }
                            }
                            pe = 0, yt = null, Va(e, t, c, 5);
                            break;
                        case 6:
                            pe = 0, yt = null, Va(e, t, c, 6);
                            break;
                        case 8:
                            qo(), Ce = 6;
                            break e;
                        default:
                            throw Error(r(462))
                    }
                }
                yp();
                break
            } catch (C) {
                Bd(e, C)
            }
            while (!0);
            return Pt = In = null, D.H = i, D.A = o, me = n, re !== null ? 0 : (xe = null, ue = 0, Us(), Ce)
    }

    function yp() {
        for (; re !== null && !Gm();) Gd(re)
    }

    function Gd(e) {
        var t = hd(e.alternate, e, on);
        e.memoizedProps = e.pendingProps, t === null ? ml(e) : re = t
    }

    function Kd(e) {
        var t = e,
            n = t.alternate;
        switch (t.tag) {
            case 15:
            case 0:
                t = sd(n, t, t.pendingProps, t.type, void 0, ue);
                break;
            case 11:
                t = sd(n, t, t.pendingProps, t.type.render, t.ref, ue);
                break;
            case 5:
                Fr(t);
            default:
                fd(n, t), t = re = Hc(t, on), t = hd(n, t, on)
        }
        e.memoizedProps = e.pendingProps, t === null ? ml(e) : re = t
    }

    function Va(e, t, n, i) {
        Pt = In = null, Fr(t), ka = null, Oi = 0;
        var o = t.return;
        try {
            if (lp(e, o, t, n, ue)) {
                Ce = 1, tl(e, Tt(n, e.current)), re = null;
                return
            }
        } catch (c) {
            if (o !== null) throw re = o, c;
            Ce = 1, tl(e, Tt(n, e.current)), re = null;
            return
        }
        t.flags & 32768 ? (he || i === 1 ? e = !0 : Ga || (ue & 536870912) !== 0 ? e = !1 : (Tn = e = !0, (i === 2 || i === 9 || i === 3 || i === 6) && (i = pt.current, i !== null && i.tag === 13 && (i.flags |= 16384))), $d(t, e)) : ml(t)
    }

    function ml(e) {
        var t = e;
        do {
            if ((t.flags & 32768) !== 0) {
                $d(t, Tn);
                return
            }
            e = t.return;
            var n = up(t.alternate, t, on);
            if (n !== null) {
                re = n;
                return
            }
            if (t = t.sibling, t !== null) {
                re = t;
                return
            }
            re = t = e
        } while (t !== null);
        Ce === 0 && (Ce = 5)
    }

    function $d(e, t) {
        do {
            var n = cp(e.alternate, e);
            if (n !== null) {
                n.flags &= 32767, re = n;
                return
            }
            if (n = e.return, n !== null && (n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null), !t && (e = e.sibling, e !== null)) {
                re = e;
                return
            }
            re = e = n
        } while (e !== null);
        Ce = 6, re = null
    }

    function Yd(e, t, n, i, o, c, f, p, b) {
        e.cancelPendingCommit = null;
        do gl(); while (Ke !== 0);
        if ((me & 6) !== 0) throw Error(r(327));
        if (t !== null) {
            if (t === e.current) throw Error(r(177));
            if (c = t.lanes | t.childLanes, c |= Tr, Pm(e, n, c, f, p, b), e === xe && (re = xe = null, ue = 0), $a = t, Nn = e, un = n, zo = c, Mo = o, Ud = i, (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? (e.callbackNode = null, e.callbackPriority = 0, Sp(vs, function() {
                    return Zd(), null
                })) : (e.callbackNode = null, e.callbackPriority = 0), i = (t.flags & 13878) !== 0, (t.subtreeFlags & 13878) !== 0 || i) {
                i = D.T, D.T = null, o = G.p, G.p = 2, f = me, me |= 4;
                try {
                    hp(e, t, n)
                } finally {
                    me = f, G.p = o, D.T = i
                }
            }
            Ke = 1, Vd(), Xd(), Qd()
        }
    }

    function Vd() {
        if (Ke === 1) {
            Ke = 0;
            var e = Nn,
                t = $a,
                n = (t.flags & 13878) !== 0;
            if ((t.subtreeFlags & 13878) !== 0 || n) {
                n = D.T, D.T = null;
                var i = G.p;
                G.p = 2;
                var o = me;
                me |= 4;
                try {
                    Ed(t, e);
                    var c = Po,
                        f = Cc(e.containerInfo),
                        p = c.focusedElem,
                        b = c.selectionRange;
                    if (f !== p && p && p.ownerDocument && Rc(p.ownerDocument.documentElement, p)) {
                        if (b !== null && jr(p)) {
                            var A = b.start,
                                C = b.end;
                            if (C === void 0 && (C = A), "selectionStart" in p) p.selectionStart = A, p.selectionEnd = Math.min(C, p.value.length);
                            else {
                                var z = p.ownerDocument || document,
                                    N = z && z.defaultView || window;
                                if (N.getSelection) {
                                    var R = N.getSelection(),
                                        Y = p.textContent.length,
                                        P = Math.min(b.start, Y),
                                        Se = b.end === void 0 ? P : Math.min(b.end, Y);
                                    !R.extend && P > Se && (f = Se, Se = P, P = f);
                                    var x = Nc(p, P),
                                        j = Nc(p, Se);
                                    if (x && j && (R.rangeCount !== 1 || R.anchorNode !== x.node || R.anchorOffset !== x.offset || R.focusNode !== j.node || R.focusOffset !== j.offset)) {
                                        var T = z.createRange();
                                        T.setStart(x.node, x.offset), R.removeAllRanges(), P > Se ? (R.addRange(T), R.extend(j.node, j.offset)) : (T.setEnd(j.node, j.offset), R.addRange(T))
                                    }
                                }
                            }
                        }
                        for (z = [], R = p; R = R.parentNode;) R.nodeType === 1 && z.push({
                            element: R,
                            left: R.scrollLeft,
                            top: R.scrollTop
                        });
                        for (typeof p.focus == "function" && p.focus(), p = 0; p < z.length; p++) {
                            var U = z[p];
                            U.element.scrollLeft = U.left, U.element.scrollTop = U.top
                        }
                    }
                    Al = !!Io, Po = Io = null
                } finally {
                    me = o, G.p = i, D.T = n
                }
            }
            e.current = t, Ke = 2
        }
    }

    function Xd() {
        if (Ke === 2) {
            Ke = 0;
            var e = Nn,
                t = $a,
                n = (t.flags & 8772) !== 0;
            if ((t.subtreeFlags & 8772) !== 0 || n) {
                n = D.T, D.T = null;
                var i = G.p;
                G.p = 2;
                var o = me;
                me |= 4;
                try {
                    _d(e, t.alternate, t)
                } finally {
                    me = o, G.p = i, D.T = n
                }
            }
            Ke = 3
        }
    }

    function Qd() {
        if (Ke === 4 || Ke === 3) {
            Ke = 0, Km();
            var e = Nn,
                t = $a,
                n = un,
                i = Ud;
            (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? Ke = 5 : (Ke = 0, $a = Nn = null, Jd(e, e.pendingLanes));
            var o = e.pendingLanes;
            if (o === 0 && (On = null), nr(n), t = t.stateNode, dt && typeof dt.onCommitFiberRoot == "function") try {
                dt.onCommitFiberRoot(ci, t, void 0, (t.current.flags & 128) === 128)
            } catch {}
            if (i !== null) {
                t = D.T, o = G.p, G.p = 2, D.T = null;
                try {
                    for (var c = e.onRecoverableError, f = 0; f < i.length; f++) {
                        var p = i[f];
                        c(p.value, {
                            componentStack: p.stack
                        })
                    }
                } finally {
                    D.T = t, G.p = o
                }
            }(un & 3) !== 0 && gl(), Yt(e), o = e.pendingLanes, (n & 261930) !== 0 && (o & 42) !== 0 ? e === Bo ? Vi++ : (Vi = 0, Bo = e) : Vi = 0, Xi(0)
        }
    }

    function Jd(e, t) {
        (e.pooledCacheLanes &= t) === 0 && (t = e.pooledCache, t != null && (e.pooledCache = null, Ti(t)))
    }

    function gl() {
        return Vd(), Xd(), Qd(), Zd()
    }

    function Zd() {
        if (Ke !== 5) return !1;
        var e = Nn,
            t = zo;
        zo = 0;
        var n = nr(un),
            i = D.T,
            o = G.p;
        try {
            G.p = 32 > n ? 32 : n, D.T = null, n = Mo, Mo = null;
            var c = Nn,
                f = un;
            if (Ke = 0, $a = Nn = null, un = 0, (me & 6) !== 0) throw Error(r(331));
            var p = me;
            if (me |= 4, Rd(c.current), Ad(c, c.current, f, n), me = p, Xi(0, !1), dt && typeof dt.onPostCommitFiberRoot == "function") try {
                dt.onPostCommitFiberRoot(ci, c)
            } catch {}
            return !0
        } finally {
            G.p = o, D.T = i, Jd(e, t)
        }
    }

    function Id(e, t, n) {
        t = Tt(n, t), t = go(e.stateNode, t, 2), e = Sn(e, t, 2), e !== null && (di(e, 2), Yt(e))
    }

    function ve(e, t, n) {
        if (e.tag === 3) Id(e, e, n);
        else
            for (; t !== null;) {
                if (t.tag === 3) {
                    Id(t, e, n);
                    break
                } else if (t.tag === 1) {
                    var i = t.stateNode;
                    if (typeof t.type.getDerivedStateFromError == "function" || typeof i.componentDidCatch == "function" && (On === null || !On.has(i))) {
                        e = Tt(n, e), n = Ph(2), i = Sn(t, n, 2), i !== null && (Wh(n, i, t, e), di(i, 2), Yt(i));
                        break
                    }
                }
                t = t.return
            }
    }

    function Ho(e, t, n) {
        var i = e.pingCache;
        if (i === null) {
            i = e.pingCache = new mp;
            var o = new Set;
            i.set(t, o)
        } else o = i.get(t), o === void 0 && (o = new Set, i.set(t, o));
        o.has(n) || (Do = !0, o.add(n), e = bp.bind(null, e, t, n), t.then(e, e))
    }

    function bp(e, t, n) {
        var i = e.pingCache;
        i !== null && i.delete(t), e.pingedLanes |= e.suspendedLanes & n, e.warmLanes &= ~n, xe === e && (ue & n) === n && (Ce === 4 || Ce === 3 && (ue & 62914560) === ue && 300 > ht() - ul ? (me & 2) === 0 && Ya(e, 0) : Uo |= n, Ka === ue && (Ka = 0)), Yt(e)
    }

    function Pd(e, t) {
        t === 0 && (t = Vu()), e = Qn(e, t), e !== null && (di(e, t), Yt(e))
    }

    function _p(e) {
        var t = e.memoizedState,
            n = 0;
        t !== null && (n = t.retryLane), Pd(e, n)
    }

    function jp(e, t) {
        var n = 0;
        switch (e.tag) {
            case 31:
            case 13:
                var i = e.stateNode,
                    o = e.memoizedState;
                o !== null && (n = o.retryLane);
                break;
            case 19:
                i = e.stateNode;
                break;
            case 22:
                i = e.stateNode._retryCache;
                break;
            default:
                throw Error(r(314))
        }
        i !== null && i.delete(t), Pd(e, n)
    }

    function Sp(e, t) {
        return Wl(e, t)
    }
    var pl = null,
        Xa = null,
        Go = !1,
        vl = !1,
        Ko = !1,
        Cn = 0;

    function Yt(e) {
        e !== Xa && e.next === null && (Xa === null ? pl = Xa = e : Xa = Xa.next = e), vl = !0, Go || (Go = !0, xp())
    }

    function Xi(e, t) {
        if (!Ko && vl) {
            Ko = !0;
            do
                for (var n = !1, i = pl; i !== null;) {
                    if (e !== 0) {
                        var o = i.pendingLanes;
                        if (o === 0) var c = 0;
                        else {
                            var f = i.suspendedLanes,
                                p = i.pingedLanes;
                            c = (1 << 31 - ft(42 | e) + 1) - 1, c &= o & ~(f & ~p), c = c & 201326741 ? c & 201326741 | 1 : c ? c | 2 : 0
                        }
                        c !== 0 && (n = !0, tf(i, c))
                    } else c = ue, c = js(i, i === xe ? c : 0, i.cancelPendingCommit !== null || i.timeoutHandle !== -1), (c & 3) === 0 || hi(i, c) || (n = !0, tf(i, c));
                    i = i.next
                }
            while (n);
            Ko = !1
        }
    }

    function wp() {
        Wd()
    }

    function Wd() {
        vl = Go = !1;
        var e = 0;
        Cn !== 0 && kp() && (e = Cn);
        for (var t = ht(), n = null, i = pl; i !== null;) {
            var o = i.next,
                c = Fd(i, t);
            c === 0 ? (i.next = null, n === null ? pl = o : n.next = o, o === null && (Xa = n)) : (n = i, (e !== 0 || (c & 3) !== 0) && (vl = !0)), i = o
        }
        Ke !== 0 && Ke !== 5 || Xi(e), Cn !== 0 && (Cn = 0)
    }

    function Fd(e, t) {
        for (var n = e.suspendedLanes, i = e.pingedLanes, o = e.expirationTimes, c = e.pendingLanes & -62914561; 0 < c;) {
            var f = 31 - ft(c),
                p = 1 << f,
                b = o[f];
            b === -1 ? ((p & n) === 0 || (p & i) !== 0) && (o[f] = Im(p, t)) : b <= t && (e.expiredLanes |= p), c &= ~p
        }
        if (t = xe, n = ue, n = js(e, e === t ? n : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), i = e.callbackNode, n === 0 || e === t && (pe === 2 || pe === 9) || e.cancelPendingCommit !== null) return i !== null && i !== null && Fl(i), e.callbackNode = null, e.callbackPriority = 0;
        if ((n & 3) === 0 || hi(e, n)) {
            if (t = n & -n, t === e.callbackPriority) return t;
            switch (i !== null && Fl(i), nr(n)) {
                case 2:
                case 8:
                    n = $u;
                    break;
                case 32:
                    n = vs;
                    break;
                case 268435456:
                    n = Yu;
                    break;
                default:
                    n = vs
            }
            return i = ef.bind(null, e), n = Wl(n, i), e.callbackPriority = t, e.callbackNode = n, t
        }
        return i !== null && i !== null && Fl(i), e.callbackPriority = 2, e.callbackNode = null, 2
    }

    function ef(e, t) {
        if (Ke !== 0 && Ke !== 5) return e.callbackNode = null, e.callbackPriority = 0, null;
        var n = e.callbackNode;
        if (gl() && e.callbackNode !== n) return null;
        var i = ue;
        return i = js(e, e === xe ? i : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), i === 0 ? null : (zd(e, i, t), Fd(e, ht()), e.callbackNode != null && e.callbackNode === n ? ef.bind(null, e) : null)
    }

    function tf(e, t) {
        if (gl()) return null;
        zd(e, t, !0)
    }

    function xp() {
        Mp(function() {
            (me & 6) !== 0 ? Wl(Ku, wp) : Wd()
        })
    }

    function $o() {
        if (Cn === 0) {
            var e = Ca;
            e === 0 && (e = ys, ys <<= 1, (ys & 261888) === 0 && (ys = 256)), Cn = e
        }
        return Cn
    }

    function nf(e) {
        return e == null || typeof e == "symbol" || typeof e == "boolean" ? null : typeof e == "function" ? e : Es("" + e)
    }

    function af(e, t) {
        var n = t.ownerDocument.createElement("input");
        return n.name = t.name, n.value = t.value, e.id && n.setAttribute("form", e.id), t.parentNode.insertBefore(n, t), e = new FormData(e), n.parentNode.removeChild(n), e
    }

    function Ep(e, t, n, i, o) {
        if (t === "submit" && n && n.stateNode === o) {
            var c = nf((o[it] || null).action),
                f = i.submitter;
            f && (t = (t = f[it] || null) ? nf(t.formAction) : f.getAttribute("formAction"), t !== null && (c = t, f = null));
            var p = new Ns("action", "action", null, i, o);
            e.push({
                event: p,
                listeners: [{
                    instance: null,
                    listener: function() {
                        if (i.defaultPrevented) {
                            if (Cn !== 0) {
                                var b = f ? af(o, f) : new FormData(o);
                                oo(n, {
                                    pending: !0,
                                    data: b,
                                    method: o.method,
                                    action: c
                                }, null, b)
                            }
                        } else typeof c == "function" && (p.preventDefault(), b = f ? af(o, f) : new FormData(o), oo(n, {
                            pending: !0,
                            data: b,
                            method: o.method,
                            action: c
                        }, c, b))
                    },
                    currentTarget: o
                }]
            })
        }
    }
    for (var Yo = 0; Yo < Er.length; Yo++) {
        var Vo = Er[Yo],
            Tp = Vo.toLowerCase(),
            Ap = Vo[0].toUpperCase() + Vo.slice(1);
        kt(Tp, "on" + Ap)
    }
    kt(kc, "onAnimationEnd"), kt(zc, "onAnimationIteration"), kt(Mc, "onAnimationStart"), kt("dblclick", "onDoubleClick"), kt("focusin", "onFocus"), kt("focusout", "onBlur"), kt($g, "onTransitionRun"), kt(Yg, "onTransitionStart"), kt(Vg, "onTransitionCancel"), kt(Bc, "onTransitionEnd"), va("onMouseEnter", ["mouseout", "mouseover"]), va("onMouseLeave", ["mouseout", "mouseover"]), va("onPointerEnter", ["pointerout", "pointerover"]), va("onPointerLeave", ["pointerout", "pointerover"]), $n("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), $n("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), $n("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), $n("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), $n("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), $n("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var Qi = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
        Op = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Qi));

    function sf(e, t) {
        t = (t & 4) !== 0;
        for (var n = 0; n < e.length; n++) {
            var i = e[n],
                o = i.event;
            i = i.listeners;
            e: {
                var c = void 0;
                if (t)
                    for (var f = i.length - 1; 0 <= f; f--) {
                        var p = i[f],
                            b = p.instance,
                            A = p.currentTarget;
                        if (p = p.listener, b !== c && o.isPropagationStopped()) break e;
                        c = p, o.currentTarget = A;
                        try {
                            c(o)
                        } catch (C) {
                            Ds(C)
                        }
                        o.currentTarget = null, c = b
                    } else
                        for (f = 0; f < i.length; f++) {
                            if (p = i[f], b = p.instance, A = p.currentTarget, p = p.listener, b !== c && o.isPropagationStopped()) break e;
                            c = p, o.currentTarget = A;
                            try {
                                c(o)
                            } catch (C) {
                                Ds(C)
                            }
                            o.currentTarget = null, c = b
                        }
            }
        }
    }

    function oe(e, t) {
        var n = t[ar];
        n === void 0 && (n = t[ar] = new Set);
        var i = e + "__bubble";
        n.has(i) || (lf(t, e, 2, !1), n.add(i))
    }

    function Xo(e, t, n) {
        var i = 0;
        t && (i |= 4), lf(n, e, i, t)
    }
    var yl = "_reactListening" + Math.random().toString(36).slice(2);

    function Qo(e) {
        if (!e[yl]) {
            e[yl] = !0, Wu.forEach(function(n) {
                n !== "selectionchange" && (Op.has(n) || Xo(n, !1, e), Xo(n, !0, e))
            });
            var t = e.nodeType === 9 ? e : e.ownerDocument;
            t === null || t[yl] || (t[yl] = !0, Xo("selectionchange", !1, t))
        }
    }

    function lf(e, t, n, i) {
        switch (zf(t)) {
            case 2:
                var o = nv;
                break;
            case 8:
                o = av;
                break;
            default:
                o = ou
        }
        n = o.bind(null, t, n, e), o = void 0, !dr || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (o = !0), i ? o !== void 0 ? e.addEventListener(t, n, {
            capture: !0,
            passive: o
        }) : e.addEventListener(t, n, !0) : o !== void 0 ? e.addEventListener(t, n, {
            passive: o
        }) : e.addEventListener(t, n, !1)
    }

    function Jo(e, t, n, i, o) {
        var c = i;
        if ((t & 1) === 0 && (t & 2) === 0 && i !== null) e: for (;;) {
            if (i === null) return;
            var f = i.tag;
            if (f === 3 || f === 4) {
                var p = i.stateNode.containerInfo;
                if (p === o) break;
                if (f === 4)
                    for (f = i.return; f !== null;) {
                        var b = f.tag;
                        if ((b === 3 || b === 4) && f.stateNode.containerInfo === o) return;
                        f = f.return
                    }
                for (; p !== null;) {
                    if (f = ma(p), f === null) return;
                    if (b = f.tag, b === 5 || b === 6 || b === 26 || b === 27) {
                        i = c = f;
                        continue e
                    }
                    p = p.parentNode
                }
            }
            i = i.return
        }
        cc(function() {
            var A = c,
                C = cr(n),
                z = [];
            e: {
                var N = qc.get(e);
                if (N !== void 0) {
                    var R = Ns,
                        Y = e;
                    switch (e) {
                        case "keypress":
                            if (As(n) === 0) break e;
                        case "keydown":
                        case "keyup":
                            R = jg;
                            break;
                        case "focusin":
                            Y = "focus", R = pr;
                            break;
                        case "focusout":
                            Y = "blur", R = pr;
                            break;
                        case "beforeblur":
                        case "afterblur":
                            R = pr;
                            break;
                        case "click":
                            if (n.button === 2) break e;
                        case "auxclick":
                        case "dblclick":
                        case "mousedown":
                        case "mousemove":
                        case "mouseup":
                        case "mouseout":
                        case "mouseover":
                        case "contextmenu":
                            R = fc;
                            break;
                        case "drag":
                        case "dragend":
                        case "dragenter":
                        case "dragexit":
                        case "dragleave":
                        case "dragover":
                        case "dragstart":
                        case "drop":
                            R = ug;
                            break;
                        case "touchcancel":
                        case "touchend":
                        case "touchmove":
                        case "touchstart":
                            R = xg;
                            break;
                        case kc:
                        case zc:
                        case Mc:
                            R = dg;
                            break;
                        case Bc:
                            R = Tg;
                            break;
                        case "scroll":
                        case "scrollend":
                            R = rg;
                            break;
                        case "wheel":
                            R = Og;
                            break;
                        case "copy":
                        case "cut":
                        case "paste":
                            R = mg;
                            break;
                        case "gotpointercapture":
                        case "lostpointercapture":
                        case "pointercancel":
                        case "pointerdown":
                        case "pointermove":
                        case "pointerout":
                        case "pointerover":
                        case "pointerup":
                            R = gc;
                            break;
                        case "toggle":
                        case "beforetoggle":
                            R = Rg
                    }
                    var P = (t & 4) !== 0,
                        Se = !P && (e === "scroll" || e === "scrollend"),
                        x = P ? N !== null ? N + "Capture" : null : N;
                    P = [];
                    for (var j = A, T; j !== null;) {
                        var U = j;
                        if (T = U.stateNode, U = U.tag, U !== 5 && U !== 26 && U !== 27 || T === null || x === null || (U = gi(j, x), U != null && P.push(Ji(j, U, T))), Se) break;
                        j = j.return
                    }
                    0 < P.length && (N = new R(N, Y, null, n, C), z.push({
                        event: N,
                        listeners: P
                    }))
                }
            }
            if ((t & 7) === 0) {
                e: {
                    if (N = e === "mouseover" || e === "pointerover", R = e === "mouseout" || e === "pointerout", N && n !== ur && (Y = n.relatedTarget || n.fromElement) && (ma(Y) || Y[fa])) break e;
                    if ((R || N) && (N = C.window === C ? C : (N = C.ownerDocument) ? N.defaultView || N.parentWindow : window, R ? (Y = n.relatedTarget || n.toElement, R = A, Y = Y ? ma(Y) : null, Y !== null && (Se = d(Y), P = Y.tag, Y !== Se || P !== 5 && P !== 27 && P !== 6) && (Y = null)) : (R = null, Y = A), R !== Y)) {
                        if (P = fc, U = "onMouseLeave", x = "onMouseEnter", j = "mouse", (e === "pointerout" || e === "pointerover") && (P = gc, U = "onPointerLeave", x = "onPointerEnter", j = "pointer"), Se = R == null ? N : mi(R), T = Y == null ? N : mi(Y), N = new P(U, j + "leave", R, n, C), N.target = Se, N.relatedTarget = T, U = null, ma(C) === A && (P = new P(x, j + "enter", Y, n, C), P.target = T, P.relatedTarget = Se, U = P), Se = U, R && Y) t: {
                            for (P = Np, x = R, j = Y, T = 0, U = x; U; U = P(U)) T++;U = 0;
                            for (var Z = j; Z; Z = P(Z)) U++;
                            for (; 0 < T - U;) x = P(x),
                            T--;
                            for (; 0 < U - T;) j = P(j),
                            U--;
                            for (; T--;) {
                                if (x === j || j !== null && x === j.alternate) {
                                    P = x;
                                    break t
                                }
                                x = P(x), j = P(j)
                            }
                            P = null
                        }
                        else P = null;
                        R !== null && rf(z, N, R, P, !1), Y !== null && Se !== null && rf(z, Se, Y, P, !0)
                    }
                }
                e: {
                    if (N = A ? mi(A) : window, R = N.nodeName && N.nodeName.toLowerCase(), R === "select" || R === "input" && N.type === "file") var de = wc;
                    else if (jc(N))
                        if (xc) de = Hg;
                        else {
                            de = qg;
                            var X = Bg
                        }
                    else R = N.nodeName,
                    !R || R.toLowerCase() !== "input" || N.type !== "checkbox" && N.type !== "radio" ? A && or(A.elementType) && (de = wc) : de = Lg;
                    if (de && (de = de(e, A))) {
                        Sc(z, de, n, C);
                        break e
                    }
                    X && X(e, N, A),
                    e === "focusout" && A && N.type === "number" && A.memoizedProps.value != null && rr(N, "number", N.value)
                }
                switch (X = A ? mi(A) : window, e) {
                    case "focusin":
                        (jc(X) || X.contentEditable === "true") && (wa = X, Sr = A, wi = null);
                        break;
                    case "focusout":
                        wi = Sr = wa = null;
                        break;
                    case "mousedown":
                        wr = !0;
                        break;
                    case "contextmenu":
                    case "mouseup":
                    case "dragend":
                        wr = !1, Dc(z, n, C);
                        break;
                    case "selectionchange":
                        if (Kg) break;
                    case "keydown":
                    case "keyup":
                        Dc(z, n, C)
                }
                var se;
                if (yr) e: {
                    switch (e) {
                        case "compositionstart":
                            var ce = "onCompositionStart";
                            break e;
                        case "compositionend":
                            ce = "onCompositionEnd";
                            break e;
                        case "compositionupdate":
                            ce = "onCompositionUpdate";
                            break e
                    }
                    ce = void 0
                }
                else Sa ? bc(e, n) && (ce = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (ce = "onCompositionStart");ce && (pc && n.locale !== "ko" && (Sa || ce !== "onCompositionStart" ? ce === "onCompositionEnd" && Sa && (se = hc()) : (gn = C, fr = "value" in gn ? gn.value : gn.textContent, Sa = !0)), X = bl(A, ce), 0 < X.length && (ce = new mc(ce, e, null, n, C), z.push({
                    event: ce,
                    listeners: X
                }), se ? ce.data = se : (se = _c(n), se !== null && (ce.data = se)))),
                (se = Dg ? Ug(e, n) : kg(e, n)) && (ce = bl(A, "onBeforeInput"), 0 < ce.length && (X = new mc("onBeforeInput", "beforeinput", null, n, C), z.push({
                    event: X,
                    listeners: ce
                }), X.data = se)),
                Ep(z, e, A, n, C)
            }
            sf(z, t)
        })
    }

    function Ji(e, t, n) {
        return {
            instance: e,
            listener: t,
            currentTarget: n
        }
    }

    function bl(e, t) {
        for (var n = t + "Capture", i = []; e !== null;) {
            var o = e,
                c = o.stateNode;
            if (o = o.tag, o !== 5 && o !== 26 && o !== 27 || c === null || (o = gi(e, n), o != null && i.unshift(Ji(e, o, c)), o = gi(e, t), o != null && i.push(Ji(e, o, c))), e.tag === 3) return i;
            e = e.return
        }
        return []
    }

    function Np(e) {
        if (e === null) return null;
        do e = e.return; while (e && e.tag !== 5 && e.tag !== 27);
        return e || null
    }

    function rf(e, t, n, i, o) {
        for (var c = t._reactName, f = []; n !== null && n !== i;) {
            var p = n,
                b = p.alternate,
                A = p.stateNode;
            if (p = p.tag, b !== null && b === i) break;
            p !== 5 && p !== 26 && p !== 27 || A === null || (b = A, o ? (A = gi(n, c), A != null && f.unshift(Ji(n, A, b))) : o || (A = gi(n, c), A != null && f.push(Ji(n, A, b)))), n = n.return
        }
        f.length !== 0 && e.push({
            event: t,
            listeners: f
        })
    }
    var Rp = /\r\n?/g,
        Cp = /\u0000|\uFFFD/g;

    function of (e) {
        return (typeof e == "string" ? e : "" + e).replace(Rp, `
`).replace(Cp, "")
    }

    function uf(e, t) {
        return t = of (t), of (e) === t
    }

    function je(e, t, n, i, o, c) {
        switch (n) {
            case "children":
                typeof i == "string" ? t === "body" || t === "textarea" && i === "" || ba(e, i) : (typeof i == "number" || typeof i == "bigint") && t !== "body" && ba(e, "" + i);
                break;
            case "className":
                ws(e, "class", i);
                break;
            case "tabIndex":
                ws(e, "tabindex", i);
                break;
            case "dir":
            case "role":
            case "viewBox":
            case "width":
            case "height":
                ws(e, n, i);
                break;
            case "style":
                oc(e, i, c);
                break;
            case "data":
                if (t !== "object") {
                    ws(e, "data", i);
                    break
                }
            case "src":
            case "href":
                if (i === "" && (t !== "a" || n !== "href")) {
                    e.removeAttribute(n);
                    break
                }
                if (i == null || typeof i == "function" || typeof i == "symbol" || typeof i == "boolean") {
                    e.removeAttribute(n);
                    break
                }
                i = Es("" + i), e.setAttribute(n, i);
                break;
            case "action":
            case "formAction":
                if (typeof i == "function") {
                    e.setAttribute(n, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
                    break
                } else typeof c == "function" && (n === "formAction" ? (t !== "input" && je(e, t, "name", o.name, o, null), je(e, t, "formEncType", o.formEncType, o, null), je(e, t, "formMethod", o.formMethod, o, null), je(e, t, "formTarget", o.formTarget, o, null)) : (je(e, t, "encType", o.encType, o, null), je(e, t, "method", o.method, o, null), je(e, t, "target", o.target, o, null)));
                if (i == null || typeof i == "symbol" || typeof i == "boolean") {
                    e.removeAttribute(n);
                    break
                }
                i = Es("" + i), e.setAttribute(n, i);
                break;
            case "onClick":
                i != null && (e.onclick = Qt);
                break;
            case "onScroll":
                i != null && oe("scroll", e);
                break;
            case "onScrollEnd":
                i != null && oe("scrollend", e);
                break;
            case "dangerouslySetInnerHTML":
                if (i != null) {
                    if (typeof i != "object" || !("__html" in i)) throw Error(r(61));
                    if (n = i.__html, n != null) {
                        if (o.children != null) throw Error(r(60));
                        e.innerHTML = n
                    }
                }
                break;
            case "multiple":
                e.multiple = i && typeof i != "function" && typeof i != "symbol";
                break;
            case "muted":
                e.muted = i && typeof i != "function" && typeof i != "symbol";
                break;
            case "suppressContentEditableWarning":
            case "suppressHydrationWarning":
            case "defaultValue":
            case "defaultChecked":
            case "innerHTML":
            case "ref":
                break;
            case "autoFocus":
                break;
            case "xlinkHref":
                if (i == null || typeof i == "function" || typeof i == "boolean" || typeof i == "symbol") {
                    e.removeAttribute("xlink:href");
                    break
                }
                n = Es("" + i), e.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", n);
                break;
            case "contentEditable":
            case "spellCheck":
            case "draggable":
            case "value":
            case "autoReverse":
            case "externalResourcesRequired":
            case "focusable":
            case "preserveAlpha":
                i != null && typeof i != "function" && typeof i != "symbol" ? e.setAttribute(n, "" + i) : e.removeAttribute(n);
                break;
            case "inert":
            case "allowFullScreen":
            case "async":
            case "autoPlay":
            case "controls":
            case "default":
            case "defer":
            case "disabled":
            case "disablePictureInPicture":
            case "disableRemotePlayback":
            case "formNoValidate":
            case "hidden":
            case "loop":
            case "noModule":
            case "noValidate":
            case "open":
            case "playsInline":
            case "readOnly":
            case "required":
            case "reversed":
            case "scoped":
            case "seamless":
            case "itemScope":
                i && typeof i != "function" && typeof i != "symbol" ? e.setAttribute(n, "") : e.removeAttribute(n);
                break;
            case "capture":
            case "download":
                i === !0 ? e.setAttribute(n, "") : i !== !1 && i != null && typeof i != "function" && typeof i != "symbol" ? e.setAttribute(n, i) : e.removeAttribute(n);
                break;
            case "cols":
            case "rows":
            case "size":
            case "span":
                i != null && typeof i != "function" && typeof i != "symbol" && !isNaN(i) && 1 <= i ? e.setAttribute(n, i) : e.removeAttribute(n);
                break;
            case "rowSpan":
            case "start":
                i == null || typeof i == "function" || typeof i == "symbol" || isNaN(i) ? e.removeAttribute(n) : e.setAttribute(n, i);
                break;
            case "popover":
                oe("beforetoggle", e), oe("toggle", e), Ss(e, "popover", i);
                break;
            case "xlinkActuate":
                Xt(e, "http://www.w3.org/1999/xlink", "xlink:actuate", i);
                break;
            case "xlinkArcrole":
                Xt(e, "http://www.w3.org/1999/xlink", "xlink:arcrole", i);
                break;
            case "xlinkRole":
                Xt(e, "http://www.w3.org/1999/xlink", "xlink:role", i);
                break;
            case "xlinkShow":
                Xt(e, "http://www.w3.org/1999/xlink", "xlink:show", i);
                break;
            case "xlinkTitle":
                Xt(e, "http://www.w3.org/1999/xlink", "xlink:title", i);
                break;
            case "xlinkType":
                Xt(e, "http://www.w3.org/1999/xlink", "xlink:type", i);
                break;
            case "xmlBase":
                Xt(e, "http://www.w3.org/XML/1998/namespace", "xml:base", i);
                break;
            case "xmlLang":
                Xt(e, "http://www.w3.org/XML/1998/namespace", "xml:lang", i);
                break;
            case "xmlSpace":
                Xt(e, "http://www.w3.org/XML/1998/namespace", "xml:space", i);
                break;
            case "is":
                Ss(e, "is", i);
                break;
            case "innerText":
            case "textContent":
                break;
            default:
                (!(2 < n.length) || n[0] !== "o" && n[0] !== "O" || n[1] !== "n" && n[1] !== "N") && (n = sg.get(n) || n, Ss(e, n, i))
        }
    }

    function Zo(e, t, n, i, o, c) {
        switch (n) {
            case "style":
                oc(e, i, c);
                break;
            case "dangerouslySetInnerHTML":
                if (i != null) {
                    if (typeof i != "object" || !("__html" in i)) throw Error(r(61));
                    if (n = i.__html, n != null) {
                        if (o.children != null) throw Error(r(60));
                        e.innerHTML = n
                    }
                }
                break;
            case "children":
                typeof i == "string" ? ba(e, i) : (typeof i == "number" || typeof i == "bigint") && ba(e, "" + i);
                break;
            case "onScroll":
                i != null && oe("scroll", e);
                break;
            case "onScrollEnd":
                i != null && oe("scrollend", e);
                break;
            case "onClick":
                i != null && (e.onclick = Qt);
                break;
            case "suppressContentEditableWarning":
            case "suppressHydrationWarning":
            case "innerHTML":
            case "ref":
                break;
            case "innerText":
            case "textContent":
                break;
            default:
                if (!Fu.hasOwnProperty(n)) e: {
                    if (n[0] === "o" && n[1] === "n" && (o = n.endsWith("Capture"), t = n.slice(2, o ? n.length - 7 : void 0), c = e[it] || null, c = c != null ? c[n] : null, typeof c == "function" && e.removeEventListener(t, c, o), typeof i == "function")) {
                        typeof c != "function" && c !== null && (n in e ? e[n] = null : e.hasAttribute(n) && e.removeAttribute(n)), e.addEventListener(t, i, o);
                        break e
                    }
                    n in e ? e[n] = i : i === !0 ? e.setAttribute(n, "") : Ss(e, n, i)
                }
        }
    }

    function Pe(e, t, n) {
        switch (t) {
            case "div":
            case "span":
            case "svg":
            case "path":
            case "a":
            case "g":
            case "p":
            case "li":
                break;
            case "img":
                oe("error", e), oe("load", e);
                var i = !1,
                    o = !1,
                    c;
                for (c in n)
                    if (n.hasOwnProperty(c)) {
                        var f = n[c];
                        if (f != null) switch (c) {
                            case "src":
                                i = !0;
                                break;
                            case "srcSet":
                                o = !0;
                                break;
                            case "children":
                            case "dangerouslySetInnerHTML":
                                throw Error(r(137, t));
                            default:
                                je(e, t, c, f, n, null)
                        }
                    }
                o && je(e, t, "srcSet", n.srcSet, n, null), i && je(e, t, "src", n.src, n, null);
                return;
            case "input":
                oe("invalid", e);
                var p = c = f = o = null,
                    b = null,
                    A = null;
                for (i in n)
                    if (n.hasOwnProperty(i)) {
                        var C = n[i];
                        if (C != null) switch (i) {
                            case "name":
                                o = C;
                                break;
                            case "type":
                                f = C;
                                break;
                            case "checked":
                                b = C;
                                break;
                            case "defaultChecked":
                                A = C;
                                break;
                            case "value":
                                c = C;
                                break;
                            case "defaultValue":
                                p = C;
                                break;
                            case "children":
                            case "dangerouslySetInnerHTML":
                                if (C != null) throw Error(r(137, t));
                                break;
                            default:
                                je(e, t, i, C, n, null)
                        }
                    }
                ic(e, c, p, b, A, f, o, !1);
                return;
            case "select":
                oe("invalid", e), i = f = c = null;
                for (o in n)
                    if (n.hasOwnProperty(o) && (p = n[o], p != null)) switch (o) {
                        case "value":
                            c = p;
                            break;
                        case "defaultValue":
                            f = p;
                            break;
                        case "multiple":
                            i = p;
                        default:
                            je(e, t, o, p, n, null)
                    }
                t = c, n = f, e.multiple = !!i, t != null ? ya(e, !!i, t, !1) : n != null && ya(e, !!i, n, !0);
                return;
            case "textarea":
                oe("invalid", e), c = o = i = null;
                for (f in n)
                    if (n.hasOwnProperty(f) && (p = n[f], p != null)) switch (f) {
                        case "value":
                            i = p;
                            break;
                        case "defaultValue":
                            o = p;
                            break;
                        case "children":
                            c = p;
                            break;
                        case "dangerouslySetInnerHTML":
                            if (p != null) throw Error(r(91));
                            break;
                        default:
                            je(e, t, f, p, n, null)
                    }
                lc(e, i, o, c);
                return;
            case "option":
                for (b in n) n.hasOwnProperty(b) && (i = n[b], i != null) && (b === "selected" ? e.selected = i && typeof i != "function" && typeof i != "symbol" : je(e, t, b, i, n, null));
                return;
            case "dialog":
                oe("beforetoggle", e), oe("toggle", e), oe("cancel", e), oe("close", e);
                break;
            case "iframe":
            case "object":
                oe("load", e);
                break;
            case "video":
            case "audio":
                for (i = 0; i < Qi.length; i++) oe(Qi[i], e);
                break;
            case "image":
                oe("error", e), oe("load", e);
                break;
            case "details":
                oe("toggle", e);
                break;
            case "embed":
            case "source":
            case "link":
                oe("error", e), oe("load", e);
            case "area":
            case "base":
            case "br":
            case "col":
            case "hr":
            case "keygen":
            case "meta":
            case "param":
            case "track":
            case "wbr":
            case "menuitem":
                for (A in n)
                    if (n.hasOwnProperty(A) && (i = n[A], i != null)) switch (A) {
                        case "children":
                        case "dangerouslySetInnerHTML":
                            throw Error(r(137, t));
                        default:
                            je(e, t, A, i, n, null)
                    }
                return;
            default:
                if (or(t)) {
                    for (C in n) n.hasOwnProperty(C) && (i = n[C], i !== void 0 && Zo(e, t, C, i, n, void 0));
                    return
                }
        }
        for (p in n) n.hasOwnProperty(p) && (i = n[p], i != null && je(e, t, p, i, n, null))
    }

    function Dp(e, t, n, i) {
        switch (t) {
            case "div":
            case "span":
            case "svg":
            case "path":
            case "a":
            case "g":
            case "p":
            case "li":
                break;
            case "input":
                var o = null,
                    c = null,
                    f = null,
                    p = null,
                    b = null,
                    A = null,
                    C = null;
                for (R in n) {
                    var z = n[R];
                    if (n.hasOwnProperty(R) && z != null) switch (R) {
                        case "checked":
                            break;
                        case "value":
                            break;
                        case "defaultValue":
                            b = z;
                        default:
                            i.hasOwnProperty(R) || je(e, t, R, null, i, z)
                    }
                }
                for (var N in i) {
                    var R = i[N];
                    if (z = n[N], i.hasOwnProperty(N) && (R != null || z != null)) switch (N) {
                        case "type":
                            c = R;
                            break;
                        case "name":
                            o = R;
                            break;
                        case "checked":
                            A = R;
                            break;
                        case "defaultChecked":
                            C = R;
                            break;
                        case "value":
                            f = R;
                            break;
                        case "defaultValue":
                            p = R;
                            break;
                        case "children":
                        case "dangerouslySetInnerHTML":
                            if (R != null) throw Error(r(137, t));
                            break;
                        default:
                            R !== z && je(e, t, N, R, i, z)
                    }
                }
                lr(e, f, p, b, A, C, c, o);
                return;
            case "select":
                R = f = p = N = null;
                for (c in n)
                    if (b = n[c], n.hasOwnProperty(c) && b != null) switch (c) {
                        case "value":
                            break;
                        case "multiple":
                            R = b;
                        default:
                            i.hasOwnProperty(c) || je(e, t, c, null, i, b)
                    }
                for (o in i)
                    if (c = i[o], b = n[o], i.hasOwnProperty(o) && (c != null || b != null)) switch (o) {
                        case "value":
                            N = c;
                            break;
                        case "defaultValue":
                            p = c;
                            break;
                        case "multiple":
                            f = c;
                        default:
                            c !== b && je(e, t, o, c, i, b)
                    }
                t = p, n = f, i = R, N != null ? ya(e, !!n, N, !1) : !!i != !!n && (t != null ? ya(e, !!n, t, !0) : ya(e, !!n, n ? [] : "", !1));
                return;
            case "textarea":
                R = N = null;
                for (p in n)
                    if (o = n[p], n.hasOwnProperty(p) && o != null && !i.hasOwnProperty(p)) switch (p) {
                        case "value":
                            break;
                        case "children":
                            break;
                        default:
                            je(e, t, p, null, i, o)
                    }
                for (f in i)
                    if (o = i[f], c = n[f], i.hasOwnProperty(f) && (o != null || c != null)) switch (f) {
                        case "value":
                            N = o;
                            break;
                        case "defaultValue":
                            R = o;
                            break;
                        case "children":
                            break;
                        case "dangerouslySetInnerHTML":
                            if (o != null) throw Error(r(91));
                            break;
                        default:
                            o !== c && je(e, t, f, o, i, c)
                    }
                sc(e, N, R);
                return;
            case "option":
                for (var Y in n) N = n[Y], n.hasOwnProperty(Y) && N != null && !i.hasOwnProperty(Y) && (Y === "selected" ? e.selected = !1 : je(e, t, Y, null, i, N));
                for (b in i) N = i[b], R = n[b], i.hasOwnProperty(b) && N !== R && (N != null || R != null) && (b === "selected" ? e.selected = N && typeof N != "function" && typeof N != "symbol" : je(e, t, b, N, i, R));
                return;
            case "img":
            case "link":
            case "area":
            case "base":
            case "br":
            case "col":
            case "embed":
            case "hr":
            case "keygen":
            case "meta":
            case "param":
            case "source":
            case "track":
            case "wbr":
            case "menuitem":
                for (var P in n) N = n[P], n.hasOwnProperty(P) && N != null && !i.hasOwnProperty(P) && je(e, t, P, null, i, N);
                for (A in i)
                    if (N = i[A], R = n[A], i.hasOwnProperty(A) && N !== R && (N != null || R != null)) switch (A) {
                        case "children":
                        case "dangerouslySetInnerHTML":
                            if (N != null) throw Error(r(137, t));
                            break;
                        default:
                            je(e, t, A, N, i, R)
                    }
                return;
            default:
                if (or(t)) {
                    for (var Se in n) N = n[Se], n.hasOwnProperty(Se) && N !== void 0 && !i.hasOwnProperty(Se) && Zo(e, t, Se, void 0, i, N);
                    for (C in i) N = i[C], R = n[C], !i.hasOwnProperty(C) || N === R || N === void 0 && R === void 0 || Zo(e, t, C, N, i, R);
                    return
                }
        }
        for (var x in n) N = n[x], n.hasOwnProperty(x) && N != null && !i.hasOwnProperty(x) && je(e, t, x, null, i, N);
        for (z in i) N = i[z], R = n[z], !i.hasOwnProperty(z) || N === R || N == null && R == null || je(e, t, z, N, i, R)
    }

    function cf(e) {
        switch (e) {
            case "css":
            case "script":
            case "font":
            case "img":
            case "image":
            case "input":
            case "link":
                return !0;
            default:
                return !1
        }
    }

    function Up() {
        if (typeof performance.getEntriesByType == "function") {
            for (var e = 0, t = 0, n = performance.getEntriesByType("resource"), i = 0; i < n.length; i++) {
                var o = n[i],
                    c = o.transferSize,
                    f = o.initiatorType,
                    p = o.duration;
                if (c && p && cf(f)) {
                    for (f = 0, p = o.responseEnd, i += 1; i < n.length; i++) {
                        var b = n[i],
                            A = b.startTime;
                        if (A > p) break;
                        var C = b.transferSize,
                            z = b.initiatorType;
                        C && cf(z) && (b = b.responseEnd, f += C * (b < p ? 1 : (p - A) / (b - A)))
                    }
                    if (--i, t += 8 * (c + f) / (o.duration / 1e3), e++, 10 < e) break
                }
            }
            if (0 < e) return t / e / 1e6
        }
        return navigator.connection && (e = navigator.connection.downlink, typeof e == "number") ? e : 5
    }
    var Io = null,
        Po = null;

    function _l(e) {
        return e.nodeType === 9 ? e : e.ownerDocument
    }

    function hf(e) {
        switch (e) {
            case "http://www.w3.org/2000/svg":
                return 1;
            case "http://www.w3.org/1998/Math/MathML":
                return 2;
            default:
                return 0
        }
    }

    function df(e, t) {
        if (e === 0) switch (t) {
            case "svg":
                return 1;
            case "math":
                return 2;
            default:
                return 0
        }
        return e === 1 && t === "foreignObject" ? 0 : e
    }

    function Wo(e, t) {
        return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.children == "bigint" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
    }
    var Fo = null;

    function kp() {
        var e = window.event;
        return e && e.type === "popstate" ? e === Fo ? !1 : (Fo = e, !0) : (Fo = null, !1)
    }
    var ff = typeof setTimeout == "function" ? setTimeout : void 0,
        zp = typeof clearTimeout == "function" ? clearTimeout : void 0,
        mf = typeof Promise == "function" ? Promise : void 0,
        Mp = typeof queueMicrotask == "function" ? queueMicrotask : typeof mf < "u" ? function(e) {
            return mf.resolve(null).then(e).catch(Bp)
        } : ff;

    function Bp(e) {
        setTimeout(function() {
            throw e
        })
    }

    function Dn(e) {
        return e === "head"
    }

    function gf(e, t) {
        var n = t,
            i = 0;
        do {
            var o = n.nextSibling;
            if (e.removeChild(n), o && o.nodeType === 8)
                if (n = o.data, n === "/$" || n === "/&") {
                    if (i === 0) {
                        e.removeChild(o), Ia(t);
                        return
                    }
                    i--
                } else if (n === "$" || n === "$?" || n === "$~" || n === "$!" || n === "&") i++;
            else if (n === "html") Zi(e.ownerDocument.documentElement);
            else if (n === "head") {
                n = e.ownerDocument.head, Zi(n);
                for (var c = n.firstChild; c;) {
                    var f = c.nextSibling,
                        p = c.nodeName;
                    c[fi] || p === "SCRIPT" || p === "STYLE" || p === "LINK" && c.rel.toLowerCase() === "stylesheet" || n.removeChild(c), c = f
                }
            } else n === "body" && Zi(e.ownerDocument.body);
            n = o
        } while (n);
        Ia(t)
    }

    function pf(e, t) {
        var n = e;
        e = 0;
        do {
            var i = n.nextSibling;
            if (n.nodeType === 1 ? t ? (n._stashedDisplay = n.style.display, n.style.display = "none") : (n.style.display = n._stashedDisplay || "", n.getAttribute("style") === "" && n.removeAttribute("style")) : n.nodeType === 3 && (t ? (n._stashedText = n.nodeValue, n.nodeValue = "") : n.nodeValue = n._stashedText || ""), i && i.nodeType === 8)
                if (n = i.data, n === "/$") {
                    if (e === 0) break;
                    e--
                } else n !== "$" && n !== "$?" && n !== "$~" && n !== "$!" || e++;
            n = i
        } while (n)
    }

    function eu(e) {
        var t = e.firstChild;
        for (t && t.nodeType === 10 && (t = t.nextSibling); t;) {
            var n = t;
            switch (t = t.nextSibling, n.nodeName) {
                case "HTML":
                case "HEAD":
                case "BODY":
                    eu(n), ir(n);
                    continue;
                case "SCRIPT":
                case "STYLE":
                    continue;
                case "LINK":
                    if (n.rel.toLowerCase() === "stylesheet") continue
            }
            e.removeChild(n)
        }
    }

    function qp(e, t, n, i) {
        for (; e.nodeType === 1;) {
            var o = n;
            if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
                if (!i && (e.nodeName !== "INPUT" || e.type !== "hidden")) break
            } else if (i) {
                if (!e[fi]) switch (t) {
                    case "meta":
                        if (!e.hasAttribute("itemprop")) break;
                        return e;
                    case "link":
                        if (c = e.getAttribute("rel"), c === "stylesheet" && e.hasAttribute("data-precedence")) break;
                        if (c !== o.rel || e.getAttribute("href") !== (o.href == null || o.href === "" ? null : o.href) || e.getAttribute("crossorigin") !== (o.crossOrigin == null ? null : o.crossOrigin) || e.getAttribute("title") !== (o.title == null ? null : o.title)) break;
                        return e;
                    case "style":
                        if (e.hasAttribute("data-precedence")) break;
                        return e;
                    case "script":
                        if (c = e.getAttribute("src"), (c !== (o.src == null ? null : o.src) || e.getAttribute("type") !== (o.type == null ? null : o.type) || e.getAttribute("crossorigin") !== (o.crossOrigin == null ? null : o.crossOrigin)) && c && e.hasAttribute("async") && !e.hasAttribute("itemprop")) break;
                        return e;
                    default:
                        return e
                }
            } else if (t === "input" && e.type === "hidden") {
                var c = o.name == null ? null : "" + o.name;
                if (o.type === "hidden" && e.getAttribute("name") === c) return e
            } else return e;
            if (e = Ct(e.nextSibling), e === null) break
        }
        return null
    }

    function Lp(e, t, n) {
        if (t === "") return null;
        for (; e.nodeType !== 3;)
            if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !n || (e = Ct(e.nextSibling), e === null)) return null;
        return e
    }

    function vf(e, t) {
        for (; e.nodeType !== 8;)
            if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !t || (e = Ct(e.nextSibling), e === null)) return null;
        return e
    }

    function tu(e) {
        return e.data === "$?" || e.data === "$~"
    }

    function nu(e) {
        return e.data === "$!" || e.data === "$?" && e.ownerDocument.readyState !== "loading"
    }

    function Hp(e, t) {
        var n = e.ownerDocument;
        if (e.data === "$~") e._reactRetry = t;
        else if (e.data !== "$?" || n.readyState !== "loading") t();
        else {
            var i = function() {
                t(), n.removeEventListener("DOMContentLoaded", i)
            };
            n.addEventListener("DOMContentLoaded", i), e._reactRetry = i
        }
    }

    function Ct(e) {
        for (; e != null; e = e.nextSibling) {
            var t = e.nodeType;
            if (t === 1 || t === 3) break;
            if (t === 8) {
                if (t = e.data, t === "$" || t === "$!" || t === "$?" || t === "$~" || t === "&" || t === "F!" || t === "F") break;
                if (t === "/$" || t === "/&") return null
            }
        }
        return e
    }
    var au = null;

    function yf(e) {
        e = e.nextSibling;
        for (var t = 0; e;) {
            if (e.nodeType === 8) {
                var n = e.data;
                if (n === "/$" || n === "/&") {
                    if (t === 0) return Ct(e.nextSibling);
                    t--
                } else n !== "$" && n !== "$!" && n !== "$?" && n !== "$~" && n !== "&" || t++
            }
            e = e.nextSibling
        }
        return null
    }

    function bf(e) {
        e = e.previousSibling;
        for (var t = 0; e;) {
            if (e.nodeType === 8) {
                var n = e.data;
                if (n === "$" || n === "$!" || n === "$?" || n === "$~" || n === "&") {
                    if (t === 0) return e;
                    t--
                } else n !== "/$" && n !== "/&" || t++
            }
            e = e.previousSibling
        }
        return null
    }

    function _f(e, t, n) {
        switch (t = _l(n), e) {
            case "html":
                if (e = t.documentElement, !e) throw Error(r(452));
                return e;
            case "head":
                if (e = t.head, !e) throw Error(r(453));
                return e;
            case "body":
                if (e = t.body, !e) throw Error(r(454));
                return e;
            default:
                throw Error(r(451))
        }
    }

    function Zi(e) {
        for (var t = e.attributes; t.length;) e.removeAttributeNode(t[0]);
        ir(e)
    }
    var Dt = new Map,
        jf = new Set;

    function jl(e) {
        return typeof e.getRootNode == "function" ? e.getRootNode() : e.nodeType === 9 ? e : e.ownerDocument
    }
    var cn = G.d;
    G.d = {
        f: Gp,
        r: Kp,
        D: $p,
        C: Yp,
        L: Vp,
        m: Xp,
        X: Jp,
        S: Qp,
        M: Zp
    };

    function Gp() {
        var e = cn.f(),
            t = dl();
        return e || t
    }

    function Kp(e) {
        var t = ga(e);
        t !== null && t.tag === 5 && t.type === "form" ? Bh(t) : cn.r(e)
    }
    var Qa = typeof document > "u" ? null : document;

    function Sf(e, t, n) {
        var i = Qa;
        if (i && typeof t == "string" && t) {
            var o = xt(t);
            o = 'link[rel="' + e + '"][href="' + o + '"]', typeof n == "string" && (o += '[crossorigin="' + n + '"]'), jf.has(o) || (jf.add(o), e = {
                rel: e,
                crossOrigin: n,
                href: t
            }, i.querySelector(o) === null && (t = i.createElement("link"), Pe(t, "link", e), Ye(t), i.head.appendChild(t)))
        }
    }

    function $p(e) {
        cn.D(e), Sf("dns-prefetch", e, null)
    }

    function Yp(e, t) {
        cn.C(e, t), Sf("preconnect", e, t)
    }

    function Vp(e, t, n) {
        cn.L(e, t, n);
        var i = Qa;
        if (i && e && t) {
            var o = 'link[rel="preload"][as="' + xt(t) + '"]';
            t === "image" && n && n.imageSrcSet ? (o += '[imagesrcset="' + xt(n.imageSrcSet) + '"]', typeof n.imageSizes == "string" && (o += '[imagesizes="' + xt(n.imageSizes) + '"]')) : o += '[href="' + xt(e) + '"]';
            var c = o;
            switch (t) {
                case "style":
                    c = Ja(e);
                    break;
                case "script":
                    c = Za(e)
            }
            Dt.has(c) || (e = w({
                rel: "preload",
                href: t === "image" && n && n.imageSrcSet ? void 0 : e,
                as: t
            }, n), Dt.set(c, e), i.querySelector(o) !== null || t === "style" && i.querySelector(Ii(c)) || t === "script" && i.querySelector(Pi(c)) || (t = i.createElement("link"), Pe(t, "link", e), Ye(t), i.head.appendChild(t)))
        }
    }

    function Xp(e, t) {
        cn.m(e, t);
        var n = Qa;
        if (n && e) {
            var i = t && typeof t.as == "string" ? t.as : "script",
                o = 'link[rel="modulepreload"][as="' + xt(i) + '"][href="' + xt(e) + '"]',
                c = o;
            switch (i) {
                case "audioworklet":
                case "paintworklet":
                case "serviceworker":
                case "sharedworker":
                case "worker":
                case "script":
                    c = Za(e)
            }
            if (!Dt.has(c) && (e = w({
                    rel: "modulepreload",
                    href: e
                }, t), Dt.set(c, e), n.querySelector(o) === null)) {
                switch (i) {
                    case "audioworklet":
                    case "paintworklet":
                    case "serviceworker":
                    case "sharedworker":
                    case "worker":
                    case "script":
                        if (n.querySelector(Pi(c))) return
                }
                i = n.createElement("link"), Pe(i, "link", e), Ye(i), n.head.appendChild(i)
            }
        }
    }

    function Qp(e, t, n) {
        cn.S(e, t, n);
        var i = Qa;
        if (i && e) {
            var o = pa(i).hoistableStyles,
                c = Ja(e);
            t = t || "default";
            var f = o.get(c);
            if (!f) {
                var p = {
                    loading: 0,
                    preload: null
                };
                if (f = i.querySelector(Ii(c))) p.loading = 5;
                else {
                    e = w({
                        rel: "stylesheet",
                        href: e,
                        "data-precedence": t
                    }, n), (n = Dt.get(c)) && iu(e, n);
                    var b = f = i.createElement("link");
                    Ye(b), Pe(b, "link", e), b._p = new Promise(function(A, C) {
                        b.onload = A, b.onerror = C
                    }), b.addEventListener("load", function() {
                        p.loading |= 1
                    }), b.addEventListener("error", function() {
                        p.loading |= 2
                    }), p.loading |= 4, Sl(f, t, i)
                }
                f = {
                    type: "stylesheet",
                    instance: f,
                    count: 1,
                    state: p
                }, o.set(c, f)
            }
        }
    }

    function Jp(e, t) {
        cn.X(e, t);
        var n = Qa;
        if (n && e) {
            var i = pa(n).hoistableScripts,
                o = Za(e),
                c = i.get(o);
            c || (c = n.querySelector(Pi(o)), c || (e = w({
                src: e,
                async: !0
            }, t), (t = Dt.get(o)) && su(e, t), c = n.createElement("script"), Ye(c), Pe(c, "link", e), n.head.appendChild(c)), c = {
                type: "script",
                instance: c,
                count: 1,
                state: null
            }, i.set(o, c))
        }
    }

    function Zp(e, t) {
        cn.M(e, t);
        var n = Qa;
        if (n && e) {
            var i = pa(n).hoistableScripts,
                o = Za(e),
                c = i.get(o);
            c || (c = n.querySelector(Pi(o)), c || (e = w({
                src: e,
                async: !0,
                type: "module"
            }, t), (t = Dt.get(o)) && su(e, t), c = n.createElement("script"), Ye(c), Pe(c, "link", e), n.head.appendChild(c)), c = {
                type: "script",
                instance: c,
                count: 1,
                state: null
            }, i.set(o, c))
        }
    }

    function wf(e, t, n, i) {
        var o = (o = le.current) ? jl(o) : null;
        if (!o) throw Error(r(446));
        switch (e) {
            case "meta":
            case "title":
                return null;
            case "style":
                return typeof n.precedence == "string" && typeof n.href == "string" ? (t = Ja(n.href), n = pa(o).hoistableStyles, i = n.get(t), i || (i = {
                    type: "style",
                    instance: null,
                    count: 0,
                    state: null
                }, n.set(t, i)), i) : {
                    type: "void",
                    instance: null,
                    count: 0,
                    state: null
                };
            case "link":
                if (n.rel === "stylesheet" && typeof n.href == "string" && typeof n.precedence == "string") {
                    e = Ja(n.href);
                    var c = pa(o).hoistableStyles,
                        f = c.get(e);
                    if (f || (o = o.ownerDocument || o, f = {
                            type: "stylesheet",
                            instance: null,
                            count: 0,
                            state: {
                                loading: 0,
                                preload: null
                            }
                        }, c.set(e, f), (c = o.querySelector(Ii(e))) && !c._p && (f.instance = c, f.state.loading = 5), Dt.has(e) || (n = {
                            rel: "preload",
                            as: "style",
                            href: n.href,
                            crossOrigin: n.crossOrigin,
                            integrity: n.integrity,
                            media: n.media,
                            hrefLang: n.hrefLang,
                            referrerPolicy: n.referrerPolicy
                        }, Dt.set(e, n), c || Ip(o, e, n, f.state))), t && i === null) throw Error(r(528, ""));
                    return f
                }
                if (t && i !== null) throw Error(r(529, ""));
                return null;
            case "script":
                return t = n.async, n = n.src, typeof n == "string" && t && typeof t != "function" && typeof t != "symbol" ? (t = Za(n), n = pa(o).hoistableScripts, i = n.get(t), i || (i = {
                    type: "script",
                    instance: null,
                    count: 0,
                    state: null
                }, n.set(t, i)), i) : {
                    type: "void",
                    instance: null,
                    count: 0,
                    state: null
                };
            default:
                throw Error(r(444, e))
        }
    }

    function Ja(e) {
        return 'href="' + xt(e) + '"'
    }

    function Ii(e) {
        return 'link[rel="stylesheet"][' + e + "]"
    }

    function xf(e) {
        return w({}, e, {
            "data-precedence": e.precedence,
            precedence: null
        })
    }

    function Ip(e, t, n, i) {
        e.querySelector('link[rel="preload"][as="style"][' + t + "]") ? i.loading = 1 : (t = e.createElement("link"), i.preload = t, t.addEventListener("load", function() {
            return i.loading |= 1
        }), t.addEventListener("error", function() {
            return i.loading |= 2
        }), Pe(t, "link", n), Ye(t), e.head.appendChild(t))
    }

    function Za(e) {
        return '[src="' + xt(e) + '"]'
    }

    function Pi(e) {
        return "script[async]" + e
    }

    function Ef(e, t, n) {
        if (t.count++, t.instance === null) switch (t.type) {
            case "style":
                var i = e.querySelector('style[data-href~="' + xt(n.href) + '"]');
                if (i) return t.instance = i, Ye(i), i;
                var o = w({}, n, {
                    "data-href": n.href,
                    "data-precedence": n.precedence,
                    href: null,
                    precedence: null
                });
                return i = (e.ownerDocument || e).createElement("style"), Ye(i), Pe(i, "style", o), Sl(i, n.precedence, e), t.instance = i;
            case "stylesheet":
                o = Ja(n.href);
                var c = e.querySelector(Ii(o));
                if (c) return t.state.loading |= 4, t.instance = c, Ye(c), c;
                i = xf(n), (o = Dt.get(o)) && iu(i, o), c = (e.ownerDocument || e).createElement("link"), Ye(c);
                var f = c;
                return f._p = new Promise(function(p, b) {
                    f.onload = p, f.onerror = b
                }), Pe(c, "link", i), t.state.loading |= 4, Sl(c, n.precedence, e), t.instance = c;
            case "script":
                return c = Za(n.src), (o = e.querySelector(Pi(c))) ? (t.instance = o, Ye(o), o) : (i = n, (o = Dt.get(c)) && (i = w({}, n), su(i, o)), e = e.ownerDocument || e, o = e.createElement("script"), Ye(o), Pe(o, "link", i), e.head.appendChild(o), t.instance = o);
            case "void":
                return null;
            default:
                throw Error(r(443, t.type))
        } else t.type === "stylesheet" && (t.state.loading & 4) === 0 && (i = t.instance, t.state.loading |= 4, Sl(i, n.precedence, e));
        return t.instance
    }

    function Sl(e, t, n) {
        for (var i = n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'), o = i.length ? i[i.length - 1] : null, c = o, f = 0; f < i.length; f++) {
            var p = i[f];
            if (p.dataset.precedence === t) c = p;
            else if (c !== o) break
        }
        c ? c.parentNode.insertBefore(e, c.nextSibling) : (t = n.nodeType === 9 ? n.head : n, t.insertBefore(e, t.firstChild))
    }

    function iu(e, t) {
        e.crossOrigin == null && (e.crossOrigin = t.crossOrigin), e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy), e.title == null && (e.title = t.title)
    }

    function su(e, t) {
        e.crossOrigin == null && (e.crossOrigin = t.crossOrigin), e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy), e.integrity == null && (e.integrity = t.integrity)
    }
    var wl = null;

    function Tf(e, t, n) {
        if (wl === null) {
            var i = new Map,
                o = wl = new Map;
            o.set(n, i)
        } else o = wl, i = o.get(n), i || (i = new Map, o.set(n, i));
        if (i.has(e)) return i;
        for (i.set(e, null), n = n.getElementsByTagName(e), o = 0; o < n.length; o++) {
            var c = n[o];
            if (!(c[fi] || c[Qe] || e === "link" && c.getAttribute("rel") === "stylesheet") && c.namespaceURI !== "http://www.w3.org/2000/svg") {
                var f = c.getAttribute(t) || "";
                f = e + f;
                var p = i.get(f);
                p ? p.push(c) : i.set(f, [c])
            }
        }
        return i
    }

    function Af(e, t, n) {
        e = e.ownerDocument || e, e.head.insertBefore(n, t === "title" ? e.querySelector("head > title") : null)
    }

    function Pp(e, t, n) {
        if (n === 1 || t.itemProp != null) return !1;
        switch (e) {
            case "meta":
            case "title":
                return !0;
            case "style":
                if (typeof t.precedence != "string" || typeof t.href != "string" || t.href === "") break;
                return !0;
            case "link":
                if (typeof t.rel != "string" || typeof t.href != "string" || t.href === "" || t.onLoad || t.onError) break;
                return t.rel === "stylesheet" ? (e = t.disabled, typeof t.precedence == "string" && e == null) : !0;
            case "script":
                if (t.async && typeof t.async != "function" && typeof t.async != "symbol" && !t.onLoad && !t.onError && t.src && typeof t.src == "string") return !0
        }
        return !1
    }

    function Of(e) {
        return !(e.type === "stylesheet" && (e.state.loading & 3) === 0)
    }

    function Wp(e, t, n, i) {
        if (n.type === "stylesheet" && (typeof i.media != "string" || matchMedia(i.media).matches !== !1) && (n.state.loading & 4) === 0) {
            if (n.instance === null) {
                var o = Ja(i.href),
                    c = t.querySelector(Ii(o));
                if (c) {
                    t = c._p, t !== null && typeof t == "object" && typeof t.then == "function" && (e.count++, e = xl.bind(e), t.then(e, e)), n.state.loading |= 4, n.instance = c, Ye(c);
                    return
                }
                c = t.ownerDocument || t, i = xf(i), (o = Dt.get(o)) && iu(i, o), c = c.createElement("link"), Ye(c);
                var f = c;
                f._p = new Promise(function(p, b) {
                    f.onload = p, f.onerror = b
                }), Pe(c, "link", i), n.instance = c
            }
            e.stylesheets === null && (e.stylesheets = new Map), e.stylesheets.set(n, t), (t = n.state.preload) && (n.state.loading & 3) === 0 && (e.count++, n = xl.bind(e), t.addEventListener("load", n), t.addEventListener("error", n))
        }
    }
    var lu = 0;

    function Fp(e, t) {
        return e.stylesheets && e.count === 0 && Tl(e, e.stylesheets), 0 < e.count || 0 < e.imgCount ? function(n) {
            var i = setTimeout(function() {
                if (e.stylesheets && Tl(e, e.stylesheets), e.unsuspend) {
                    var c = e.unsuspend;
                    e.unsuspend = null, c()
                }
            }, 6e4 + t);
            0 < e.imgBytes && lu === 0 && (lu = 62500 * Up());
            var o = setTimeout(function() {
                if (e.waitingForImages = !1, e.count === 0 && (e.stylesheets && Tl(e, e.stylesheets), e.unsuspend)) {
                    var c = e.unsuspend;
                    e.unsuspend = null, c()
                }
            }, (e.imgBytes > lu ? 50 : 800) + t);
            return e.unsuspend = n,
                function() {
                    e.unsuspend = null, clearTimeout(i), clearTimeout(o)
                }
        } : null
    }

    function xl() {
        if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
            if (this.stylesheets) Tl(this, this.stylesheets);
            else if (this.unsuspend) {
                var e = this.unsuspend;
                this.unsuspend = null, e()
            }
        }
    }
    var El = null;

    function Tl(e, t) {
        e.stylesheets = null, e.unsuspend !== null && (e.count++, El = new Map, t.forEach(ev, e), El = null, xl.call(e))
    }

    function ev(e, t) {
        if (!(t.state.loading & 4)) {
            var n = El.get(e);
            if (n) var i = n.get(null);
            else {
                n = new Map, El.set(e, n);
                for (var o = e.querySelectorAll("link[data-precedence],style[data-precedence]"), c = 0; c < o.length; c++) {
                    var f = o[c];
                    (f.nodeName === "LINK" || f.getAttribute("media") !== "not all") && (n.set(f.dataset.precedence, f), i = f)
                }
                i && n.set(null, i)
            }
            o = t.instance, f = o.getAttribute("data-precedence"), c = n.get(f) || i, c === i && n.set(null, o), n.set(f, o), this.count++, i = xl.bind(this), o.addEventListener("load", i), o.addEventListener("error", i), c ? c.parentNode.insertBefore(o, c.nextSibling) : (e = e.nodeType === 9 ? e.head : e, e.insertBefore(o, e.firstChild)), t.state.loading |= 4
        }
    }
    var Wi = {
        $$typeof: q,
        Provider: null,
        Consumer: null,
        _currentValue: ee,
        _currentValue2: ee,
        _threadCount: 0
    };

    function tv(e, t, n, i, o, c, f, p, b) {
        this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = er(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = er(0), this.hiddenUpdates = er(null), this.identifierPrefix = i, this.onUncaughtError = o, this.onCaughtError = c, this.onRecoverableError = f, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = b, this.incompleteTransitions = new Map
    }

    function Nf(e, t, n, i, o, c, f, p, b, A, C, z) {
        return e = new tv(e, t, n, f, b, A, C, z, p), t = 1, c === !0 && (t |= 24), c = gt(3, null, null, t), e.current = c, c.stateNode = e, t = qr(), t.refCount++, e.pooledCache = t, t.refCount++, c.memoizedState = {
            element: i,
            isDehydrated: n,
            cache: t
        }, Kr(c), e
    }

    function Rf(e) {
        return e ? (e = Ta, e) : Ta
    }

    function Cf(e, t, n, i, o, c) {
        o = Rf(o), i.context === null ? i.context = o : i.pendingContext = o, i = jn(t), i.payload = {
            element: n
        }, c = c === void 0 ? null : c, c !== null && (i.callback = c), n = Sn(e, i, t), n !== null && (ct(n, e, t), Ri(n, e, t))
    }

    function Df(e, t) {
        if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
            var n = e.retryLane;
            e.retryLane = n !== 0 && n < t ? n : t
        }
    }

    function ru(e, t) {
        Df(e, t), (e = e.alternate) && Df(e, t)
    }

    function Uf(e) {
        if (e.tag === 13 || e.tag === 31) {
            var t = Qn(e, 67108864);
            t !== null && ct(t, e, 67108864), ru(e, 67108864)
        }
    }

    function kf(e) {
        if (e.tag === 13 || e.tag === 31) {
            var t = _t();
            t = tr(t);
            var n = Qn(e, t);
            n !== null && ct(n, e, t), ru(e, t)
        }
    }
    var Al = !0;

    function nv(e, t, n, i) {
        var o = D.T;
        D.T = null;
        var c = G.p;
        try {
            G.p = 2, ou(e, t, n, i)
        } finally {
            G.p = c, D.T = o
        }
    }

    function av(e, t, n, i) {
        var o = D.T;
        D.T = null;
        var c = G.p;
        try {
            G.p = 8, ou(e, t, n, i)
        } finally {
            G.p = c, D.T = o
        }
    }

    function ou(e, t, n, i) {
        if (Al) {
            var o = uu(i);
            if (o === null) Jo(e, t, i, Ol, n), Mf(e, i);
            else if (sv(o, e, t, n, i)) i.stopPropagation();
            else if (Mf(e, i), t & 4 && -1 < iv.indexOf(e)) {
                for (; o !== null;) {
                    var c = ga(o);
                    if (c !== null) switch (c.tag) {
                        case 3:
                            if (c = c.stateNode, c.current.memoizedState.isDehydrated) {
                                var f = Kn(c.pendingLanes);
                                if (f !== 0) {
                                    var p = c;
                                    for (p.pendingLanes |= 2, p.entangledLanes |= 2; f;) {
                                        var b = 1 << 31 - ft(f);
                                        p.entanglements[1] |= b, f &= ~b
                                    }
                                    Yt(c), (me & 6) === 0 && (cl = ht() + 500, Xi(0))
                                }
                            }
                            break;
                        case 31:
                        case 13:
                            p = Qn(c, 2), p !== null && ct(p, c, 2), dl(), ru(c, 2)
                    }
                    if (c = uu(i), c === null && Jo(e, t, i, Ol, n), c === o) break;
                    o = c
                }
                o !== null && i.stopPropagation()
            } else Jo(e, t, i, null, n)
        }
    }

    function uu(e) {
        return e = cr(e), cu(e)
    }
    var Ol = null;

    function cu(e) {
        if (Ol = null, e = ma(e), e !== null) {
            var t = d(e);
            if (t === null) e = null;
            else {
                var n = t.tag;
                if (n === 13) {
                    if (e = m(t), e !== null) return e;
                    e = null
                } else if (n === 31) {
                    if (e = g(t), e !== null) return e;
                    e = null
                } else if (n === 3) {
                    if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
                    e = null
                } else t !== e && (e = null)
            }
        }
        return Ol = e, null
    }

    function zf(e) {
        switch (e) {
            case "beforetoggle":
            case "cancel":
            case "click":
            case "close":
            case "contextmenu":
            case "copy":
            case "cut":
            case "auxclick":
            case "dblclick":
            case "dragend":
            case "dragstart":
            case "drop":
            case "focusin":
            case "focusout":
            case "input":
            case "invalid":
            case "keydown":
            case "keypress":
            case "keyup":
            case "mousedown":
            case "mouseup":
            case "paste":
            case "pause":
            case "play":
            case "pointercancel":
            case "pointerdown":
            case "pointerup":
            case "ratechange":
            case "reset":
            case "resize":
            case "seeked":
            case "submit":
            case "toggle":
            case "touchcancel":
            case "touchend":
            case "touchstart":
            case "volumechange":
            case "change":
            case "selectionchange":
            case "textInput":
            case "compositionstart":
            case "compositionend":
            case "compositionupdate":
            case "beforeblur":
            case "afterblur":
            case "beforeinput":
            case "blur":
            case "fullscreenchange":
            case "focus":
            case "hashchange":
            case "popstate":
            case "select":
            case "selectstart":
                return 2;
            case "drag":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "mousemove":
            case "mouseout":
            case "mouseover":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "scroll":
            case "touchmove":
            case "wheel":
            case "mouseenter":
            case "mouseleave":
            case "pointerenter":
            case "pointerleave":
                return 8;
            case "message":
                switch ($m()) {
                    case Ku:
                        return 2;
                    case $u:
                        return 8;
                    case vs:
                    case Ym:
                        return 32;
                    case Yu:
                        return 268435456;
                    default:
                        return 32
                }
            default:
                return 32
        }
    }
    var hu = !1,
        Un = null,
        kn = null,
        zn = null,
        Fi = new Map,
        es = new Map,
        Mn = [],
        iv = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");

    function Mf(e, t) {
        switch (e) {
            case "focusin":
            case "focusout":
                Un = null;
                break;
            case "dragenter":
            case "dragleave":
                kn = null;
                break;
            case "mouseover":
            case "mouseout":
                zn = null;
                break;
            case "pointerover":
            case "pointerout":
                Fi.delete(t.pointerId);
                break;
            case "gotpointercapture":
            case "lostpointercapture":
                es.delete(t.pointerId)
        }
    }

    function ts(e, t, n, i, o, c) {
        return e === null || e.nativeEvent !== c ? (e = {
            blockedOn: t,
            domEventName: n,
            eventSystemFlags: i,
            nativeEvent: c,
            targetContainers: [o]
        }, t !== null && (t = ga(t), t !== null && Uf(t)), e) : (e.eventSystemFlags |= i, t = e.targetContainers, o !== null && t.indexOf(o) === -1 && t.push(o), e)
    }

    function sv(e, t, n, i, o) {
        switch (t) {
            case "focusin":
                return Un = ts(Un, e, t, n, i, o), !0;
            case "dragenter":
                return kn = ts(kn, e, t, n, i, o), !0;
            case "mouseover":
                return zn = ts(zn, e, t, n, i, o), !0;
            case "pointerover":
                var c = o.pointerId;
                return Fi.set(c, ts(Fi.get(c) || null, e, t, n, i, o)), !0;
            case "gotpointercapture":
                return c = o.pointerId, es.set(c, ts(es.get(c) || null, e, t, n, i, o)), !0
        }
        return !1
    }

    function Bf(e) {
        var t = ma(e.target);
        if (t !== null) {
            var n = d(t);
            if (n !== null) {
                if (t = n.tag, t === 13) {
                    if (t = m(n), t !== null) {
                        e.blockedOn = t, Iu(e.priority, function() {
                            kf(n)
                        });
                        return
                    }
                } else if (t === 31) {
                    if (t = g(n), t !== null) {
                        e.blockedOn = t, Iu(e.priority, function() {
                            kf(n)
                        });
                        return
                    }
                } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                    e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                    return
                }
            }
        }
        e.blockedOn = null
    }

    function Nl(e) {
        if (e.blockedOn !== null) return !1;
        for (var t = e.targetContainers; 0 < t.length;) {
            var n = uu(e.nativeEvent);
            if (n === null) {
                n = e.nativeEvent;
                var i = new n.constructor(n.type, n);
                ur = i, n.target.dispatchEvent(i), ur = null
            } else return t = ga(n), t !== null && Uf(t), e.blockedOn = n, !1;
            t.shift()
        }
        return !0
    }

    function qf(e, t, n) {
        Nl(e) && n.delete(t)
    }

    function lv() {
        hu = !1, Un !== null && Nl(Un) && (Un = null), kn !== null && Nl(kn) && (kn = null), zn !== null && Nl(zn) && (zn = null), Fi.forEach(qf), es.forEach(qf)
    }

    function Rl(e, t) {
        e.blockedOn === t && (e.blockedOn = null, hu || (hu = !0, s.unstable_scheduleCallback(s.unstable_NormalPriority, lv)))
    }
    var Cl = null;

    function Lf(e) {
        Cl !== e && (Cl = e, s.unstable_scheduleCallback(s.unstable_NormalPriority, function() {
            Cl === e && (Cl = null);
            for (var t = 0; t < e.length; t += 3) {
                var n = e[t],
                    i = e[t + 1],
                    o = e[t + 2];
                if (typeof i != "function") {
                    if (cu(i || n) === null) continue;
                    break
                }
                var c = ga(n);
                c !== null && (e.splice(t, 3), t -= 3, oo(c, {
                    pending: !0,
                    data: o,
                    method: n.method,
                    action: i
                }, i, o))
            }
        }))
    }

    function Ia(e) {
        function t(b) {
            return Rl(b, e)
        }
        Un !== null && Rl(Un, e), kn !== null && Rl(kn, e), zn !== null && Rl(zn, e), Fi.forEach(t), es.forEach(t);
        for (var n = 0; n < Mn.length; n++) {
            var i = Mn[n];
            i.blockedOn === e && (i.blockedOn = null)
        }
        for (; 0 < Mn.length && (n = Mn[0], n.blockedOn === null);) Bf(n), n.blockedOn === null && Mn.shift();
        if (n = (e.ownerDocument || e).$$reactFormReplay, n != null)
            for (i = 0; i < n.length; i += 3) {
                var o = n[i],
                    c = n[i + 1],
                    f = o[it] || null;
                if (typeof c == "function") f || Lf(n);
                else if (f) {
                    var p = null;
                    if (c && c.hasAttribute("formAction")) {
                        if (o = c, f = c[it] || null) p = f.formAction;
                        else if (cu(o) !== null) continue
                    } else p = f.action;
                    typeof p == "function" ? n[i + 1] = p : (n.splice(i, 3), i -= 3), Lf(n)
                }
            }
    }

    function Hf() {
        function e(c) {
            c.canIntercept && c.info === "react-transition" && c.intercept({
                handler: function() {
                    return new Promise(function(f) {
                        return o = f
                    })
                },
                focusReset: "manual",
                scroll: "manual"
            })
        }

        function t() {
            o !== null && (o(), o = null), i || setTimeout(n, 20)
        }

        function n() {
            if (!i && !navigation.transition) {
                var c = navigation.currentEntry;
                c && c.url != null && navigation.navigate(c.url, {
                    state: c.getState(),
                    info: "react-transition",
                    history: "replace"
                })
            }
        }
        if (typeof navigation == "object") {
            var i = !1,
                o = null;
            return navigation.addEventListener("navigate", e), navigation.addEventListener("navigatesuccess", t), navigation.addEventListener("navigateerror", t), setTimeout(n, 100),
                function() {
                    i = !0, navigation.removeEventListener("navigate", e), navigation.removeEventListener("navigatesuccess", t), navigation.removeEventListener("navigateerror", t), o !== null && (o(), o = null)
                }
        }
    }

    function du(e) {
        this._internalRoot = e
    }
    Dl.prototype.render = du.prototype.render = function(e) {
        var t = this._internalRoot;
        if (t === null) throw Error(r(409));
        var n = t.current,
            i = _t();
        Cf(n, i, e, t, null, null)
    }, Dl.prototype.unmount = du.prototype.unmount = function() {
        var e = this._internalRoot;
        if (e !== null) {
            this._internalRoot = null;
            var t = e.containerInfo;
            Cf(e.current, 2, null, e, null, null), dl(), t[fa] = null
        }
    };

    function Dl(e) {
        this._internalRoot = e
    }
    Dl.prototype.unstable_scheduleHydration = function(e) {
        if (e) {
            var t = Zu();
            e = {
                blockedOn: null,
                target: e,
                priority: t
            };
            for (var n = 0; n < Mn.length && t !== 0 && t < Mn[n].priority; n++);
            Mn.splice(n, 0, e), n === 0 && Bf(e)
        }
    };
    var Gf = a.version;
    if (Gf !== "19.2.4") throw Error(r(527, Gf, "19.2.4"));
    G.findDOMNode = function(e) {
        var t = e._reactInternals;
        if (t === void 0) throw typeof e.render == "function" ? Error(r(188)) : (e = Object.keys(e).join(","), Error(r(268, e)));
        return e = v(t), e = e !== null ? _(e) : null, e = e === null ? null : e.stateNode, e
    };
    var rv = {
        bundleType: 0,
        version: "19.2.4",
        rendererPackageName: "react-dom",
        currentDispatcherRef: D,
        reconcilerVersion: "19.2.4"
    };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
        var Ul = __REACT_DEVTOOLS_GLOBAL_HOOK__;
        if (!Ul.isDisabled && Ul.supportsFiber) try {
            ci = Ul.inject(rv), dt = Ul
        } catch {}
    }
    return as.createRoot = function(e, t) {
        if (!h(e)) throw Error(r(299));
        var n = !1,
            i = "",
            o = Qh,
            c = Jh,
            f = Zh;
        return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (i = t.identifierPrefix), t.onUncaughtError !== void 0 && (o = t.onUncaughtError), t.onCaughtError !== void 0 && (c = t.onCaughtError), t.onRecoverableError !== void 0 && (f = t.onRecoverableError)), t = Nf(e, 1, !1, null, null, n, i, null, o, c, f, Hf), e[fa] = t.current, Qo(e), new du(t)
    }, as.hydrateRoot = function(e, t, n) {
        if (!h(e)) throw Error(r(299));
        var i = !1,
            o = "",
            c = Qh,
            f = Jh,
            p = Zh,
            b = null;
        return n != null && (n.unstable_strictMode === !0 && (i = !0), n.identifierPrefix !== void 0 && (o = n.identifierPrefix), n.onUncaughtError !== void 0 && (c = n.onUncaughtError), n.onCaughtError !== void 0 && (f = n.onCaughtError), n.onRecoverableError !== void 0 && (p = n.onRecoverableError), n.formState !== void 0 && (b = n.formState)), t = Nf(e, 1, !0, t, n ? ? null, i, o, b, c, f, p, Hf), t.context = Rf(null), n = t.current, i = _t(), i = tr(i), o = jn(i), o.callback = null, Sn(n, o, i), n = i, t.current.lanes = n, di(t, n), Yt(t), e[fa] = t.current, Qo(e), new Dl(t)
    }, as.version = "19.2.4", as
}
var Pf;

function yv() {
    if (Pf) return gu.exports;
    Pf = 1;

    function s() {
        if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s)
        } catch (a) {
            console.error(a)
        }
    }
    return s(), gu.exports = vv(), gu.exports
}
var bv = yv();
const _v = wm(bv);

function jv({
    currentPage: s,
    onNavigate: a
}) {
    const [l, r] = Xe.useState(!1), h = [{
        label: "Home",
        page: "home"
    }, {
        label: "About",
        page: "about"
    }, {
        label: "Goals & Objectives",
        page: "goals"
    }, {
        label: "Achievements",
        page: "achievements"
    }, {
        label: "Events",
        page: "events"
    }, {
        label: "Join",
        page: "join"
    }, {
        label: "Donations",
        page: "donations"
    }, {
        label: "Gallery",
        page: "gallery"
    }, {
        label: "Governance",
        page: "governance"
    }, {
        label: "Contact",
        page: "contact"
    }], d = m => {
        a(m), r(!1)
    };
    return u.jsx("nav", {
        className: "navbar",
        children: u.jsxs("div", {
            className: "container nav-container",
            children: [u.jsxs("div", {
                className: "nav-brand",
                children: [u.jsx("h2", {
                    className: "logo",
                    children: "KMFA"
                }), u.jsx("span", {
                    className: "tagline",
                    children: "Karnataka Minifootball"
                })]
            }), u.jsx("button", {
                className: "mobile-toggle",
                onClick: () => r(!l),
                children: "☰"
            }), u.jsx("ul", {
                className: `nav-links ${l?"active":""}`,
                children: h.map(m => u.jsx("li", {
                    children: u.jsx("button", {
                        className: `nav-link ${s===m.page?"active":""}`,
                        onClick: () => d(m.page),
                        children: m.label
                    })
                }, m.page))
            })]
        })
    })
}

function Sv({
    onNavigate: s
}) {
    return u.jsx("footer", {
        className: "footer",
        children: u.jsxs("div", {
            className: "container",
            children: [u.jsxs("div", {
                className: "footer-content",
                children: [u.jsxs("div", {
                    className: "footer-section",
                    children: [u.jsx("h3", {
                        children: "Karnataka Minifootball Association"
                    }), u.jsx("p", {
                        children: "Promoting grassroots minifootball development across Karnataka through inclusivity, ethics, and community engagement."
                    })]
                }), u.jsxs("div", {
                    className: "footer-section",
                    children: [u.jsx("h3", {
                        children: "Quick Links"
                    }), u.jsxs("ul", {
                        children: [u.jsx("li", {
                            children: u.jsx("button", {
                                onClick: () => s("about"),
                                children: "About Us"
                            })
                        }), u.jsx("li", {
                            children: u.jsx("button", {
                                onClick: () => s("events"),
                                children: "Upcoming Events"
                            })
                        }), u.jsx("li", {
                            children: u.jsx("button", {
                                onClick: () => s("join"),
                                children: "Join Us"
                            })
                        }), u.jsx("li", {
                            children: u.jsx("button", {
                                onClick: () => s("contact"),
                                children: "Contact"
                            })
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "footer-section",
                    children: [u.jsx("h3", {
                        children: "Contact"
                    }), u.jsx("p", {
                        children: "Email: info@kmfa.org"
                    }), u.jsx("p", {
                        children: "Phone: +91 XXXXX XXXXX"
                    }), u.jsx("p", {
                        children: "Location: Karnataka, India"
                    })]
                }), u.jsxs("div", {
                    className: "footer-section",
                    children: [u.jsx("h3", {
                        children: "Follow Us"
                    }), u.jsxs("div", {
                        className: "social-links",
                        children: [u.jsx("a", {
                            href: "#",
                            className: "social-link",
                            children: "Facebook"
                        }), u.jsx("a", {
                            href: "#",
                            className: "social-link",
                            children: "Twitter"
                        }), u.jsx("a", {
                            href: "#",
                            className: "social-link",
                            children: "Instagram"
                        })]
                    })]
                })]
            }), u.jsx("div", {
                className: "footer-bottom",
                children: u.jsx("p", {
                    children: "© 2024 Karnataka Minifootball Association. All rights reserved."
                })
            })]
        })
    })
}

function Wf({
    onNavigate: s
}) {
    const [a, l] = Xe.useState([{
        id: "1",
        name: "State Minifootball Championship",
        date: "March 15, 2024",
        location: "Bangalore"
    }, {
        id: "2",
        name: "Youth Development Cup",
        date: "April 20, 2024",
        location: "Mysore"
    }, {
        id: "3",
        name: "Rural Outreach Tournament",
        date: "May 10, 2024",
        location: "Hassan"
    }]);
    return u.jsxs("div", {
        className: "home",
        children: [u.jsx("section", {
            className: "hero",
            children: u.jsx("div", {
                className: "container hero-content",
                children: u.jsxs("div", {
                    className: "hero-text",
                    children: [u.jsx("h1", {
                        children: "Karnataka Minifootball Association"
                    }), u.jsx("p", {
                        className: "hero-tagline",
                        children: "Empowering Grassroots Football Across Karnataka"
                    }), u.jsx("p", {
                        className: "hero-description",
                        children: "Dedicated to promoting minifootball development, inclusivity, and youth empowerment through fair governance and community engagement."
                    }), u.jsxs("div", {
                        className: "hero-cta",
                        children: [u.jsx("button", {
                            className: "btn-primary",
                            onClick: () => s("join"),
                            children: "Join the Association"
                        }), u.jsx("button", {
                            className: "btn-outline",
                            onClick: () => s("donations"),
                            children: "Support Our Mission"
                        })]
                    })]
                })
            })
        }), u.jsx("section", {
            className: "section highlights",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsxs("div", {
                    className: "section-title",
                    children: [u.jsx("h2", {
                        children: "Our Impact"
                    }), u.jsx("p", {
                        children: "Making a difference in the football community"
                    })]
                }), u.jsxs("div", {
                    className: "highlights-grid",
                    children: [u.jsxs("div", {
                        className: "highlight-card",
                        children: [u.jsx("div", {
                            className: "highlight-icon",
                            children: "🎯"
                        }), u.jsx("h3", {
                            children: "Grassroots Development"
                        }), u.jsx("p", {
                            children: "Building strong foundational programs for young players across Karnataka"
                        })]
                    }), u.jsxs("div", {
                        className: "highlight-card",
                        children: [u.jsx("div", {
                            className: "highlight-icon",
                            children: "👥"
                        }), u.jsx("h3", {
                            children: "Inclusive Community"
                        }), u.jsx("p", {
                            children: "Welcoming all genders, abilities, and backgrounds to the beautiful game"
                        })]
                    }), u.jsxs("div", {
                        className: "highlight-card",
                        children: [u.jsx("div", {
                            className: "highlight-icon",
                            children: "🏆"
                        }), u.jsx("h3", {
                            children: "Championship Tournaments"
                        }), u.jsx("p", {
                            children: "Organizing state-level competitions and national platform connections"
                        })]
                    }), u.jsxs("div", {
                        className: "highlight-card",
                        children: [u.jsx("div", {
                            className: "highlight-icon",
                            children: "🌱"
                        }), u.jsx("h3", {
                            children: "Rural Outreach"
                        }), u.jsx("p", {
                            children: "Extending football programs to underserved rural communities"
                        })]
                    }), u.jsxs("div", {
                        className: "highlight-card",
                        children: [u.jsx("div", {
                            className: "highlight-icon",
                            children: "⚖️"
                        }), u.jsx("h3", {
                            children: "Fair Governance"
                        }), u.jsx("p", {
                            children: "Operating with transparency and ethical principles in all activities"
                        })]
                    }), u.jsxs("div", {
                        className: "highlight-card",
                        children: [u.jsx("div", {
                            className: "highlight-icon",
                            children: "🌍"
                        }), u.jsx("h3", {
                            children: "Social Impact"
                        }), u.jsx("p", {
                            children: "Creating positive change through sports and community empowerment"
                        })]
                    })]
                })]
            })
        }), u.jsx("section", {
            className: "section upcoming-events-preview",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsxs("div", {
                    className: "section-title",
                    children: [u.jsx("h2", {
                        children: "Upcoming Events"
                    }), u.jsx("p", {
                        children: "Don't miss our latest tournaments and programs"
                    })]
                }), u.jsx("div", {
                    className: "events-list",
                    children: a.map(r => u.jsxs("div", {
                        className: "event-item",
                        children: [u.jsxs("div", {
                            className: "event-date",
                            children: [u.jsx("span", {
                                className: "date-icon",
                                children: "📅"
                            }), u.jsx("span", {
                                className: "date-text",
                                children: r.date
                            })]
                        }), u.jsxs("div", {
                            className: "event-info",
                            children: [u.jsx("h3", {
                                children: r.name
                            }), u.jsxs("p", {
                                children: ["📍 ", r.location]
                            })]
                        })]
                    }, r.id))
                }), u.jsx("div", {
                    style: {
                        textAlign: "center",
                        marginTop: "40px"
                    },
                    children: u.jsx("button", {
                        className: "btn-primary",
                        onClick: () => s("events"),
                        children: "View All Events"
                    })
                })]
            })
        }), u.jsx("section", {
            className: "section goals-preview",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsxs("div", {
                    className: "section-title",
                    children: [u.jsx("h2", {
                        children: "Our Mission"
                    }), u.jsx("p", {
                        children: "Building excellence through minifootball"
                    })]
                }), u.jsx("div", {
                    className: "mission-content",
                    children: u.jsxs("div", {
                        className: "mission-text",
                        children: [u.jsx("h3", {
                            children: "Vision"
                        }), u.jsx("p", {
                            children: "To establish Karnataka as a hub for minifootball excellence, nurturing talent from grassroots to national and international levels."
                        }), u.jsx("h3", {
                            children: "Mission"
                        }), u.jsx("p", {
                            children: "To promote, regulate, and develop minifootball across Karnataka through inclusive programs, ethical governance, and community engagement."
                        }), u.jsx("h3", {
                            children: "Core Values"
                        }), u.jsxs("ul", {
                            children: [u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Inclusivity:"
                                }), " Open to all genders, abilities, and socio-economic backgrounds"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Excellence:"
                                }), " Promoting high standards in player development and tournament management"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Transparency:"
                                }), " Operating with honesty and accountability in all decisions"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Community:"
                                }), " Building strong grassroots networks and social impact"]
                            })]
                        })]
                    })
                })]
            })
        })]
    })
}

function wv() {
    return u.jsxs("div", {
        className: "about",
        children: [u.jsx("section", {
            className: "section about-hero",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsx("h1", {
                    children: "About Karnataka Minifootball Association"
                }), u.jsx("p", {
                    children: "Learn more about KMFA and our commitment to developing minifootball"
                })]
            })
        }), u.jsx("section", {
            className: "section about-content",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsxs("div", {
                    className: "about-section",
                    children: [u.jsx("h2", {
                        children: "Who We Are"
                    }), u.jsx("p", {
                        children: "Karnataka Minifootball Association (KMFA) is the official governing body responsible for promoting, regulating, and developing minifootball across Karnataka. We are dedicated to creating opportunities for players of all backgrounds to experience the joy and benefits of football."
                    })]
                }), u.jsxs("div", {
                    className: "about-section",
                    children: [u.jsx("h2", {
                        children: "Formation & Purpose"
                    }), u.jsx("p", {
                        children: "Founded with a vision to democratize football in Karnataka, KMFA operates as a non-profit organization committed to grassroots development. Our formation was driven by the need to create structured pathways for minifootball players to develop their skills and compete at fair, well-organized tournaments."
                    }), u.jsx("p", {
                        children: "We believe that minifootball is an accessible entry point for youth and adults to engage with sports, build teamwork skills, and develop physically and mentally."
                    })]
                }), u.jsxs("div", {
                    className: "about-section",
                    children: [u.jsx("h2", {
                        children: "Vision"
                    }), u.jsx("p", {
                        children: "To establish Karnataka as a hub for minifootball excellence, nurturing talent from grassroots to national and international levels, while fostering inclusivity, ethical governance, and positive social impact."
                    })]
                }), u.jsxs("div", {
                    className: "about-section",
                    children: [u.jsx("h2", {
                        children: "Mission"
                    }), u.jsx("p", {
                        children: "To promote, regulate, and develop minifootball across Karnataka through:"
                    }), u.jsxs("ul", {
                        children: [u.jsx("li", {
                            children: "Organizing regular tournaments and leagues at district and state levels"
                        }), u.jsx("li", {
                            children: "Establishing grassroots development programs in schools and communities"
                        }), u.jsx("li", {
                            children: "Supporting rural outreach and underprivileged youth engagement"
                        }), u.jsx("li", {
                            children: "Promoting inclusivity for women, differently-abled individuals, and marginalized communities"
                        }), u.jsx("li", {
                            children: "Maintaining ethical standards and fair play principles"
                        }), u.jsx("li", {
                            children: "Building pathways to national and international recognition"
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "about-section",
                    children: [u.jsx("h2", {
                        children: "Core Values"
                    }), u.jsxs("div", {
                        className: "values-grid",
                        children: [u.jsxs("div", {
                            className: "value-card",
                            children: [u.jsx("h3", {
                                children: "Inclusivity"
                            }), u.jsx("p", {
                                children: "Open doors to all genders, abilities, and socio-economic backgrounds"
                            })]
                        }), u.jsxs("div", {
                            className: "value-card",
                            children: [u.jsx("h3", {
                                children: "Excellence"
                            }), u.jsx("p", {
                                children: "Promoting high standards in player development and program management"
                            })]
                        }), u.jsxs("div", {
                            className: "value-card",
                            children: [u.jsx("h3", {
                                children: "Transparency"
                            }), u.jsx("p", {
                                children: "Operating with honesty and accountability in all our decisions"
                            })]
                        }), u.jsxs("div", {
                            className: "value-card",
                            children: [u.jsx("h3", {
                                children: "Community"
                            }), u.jsx("p", {
                                children: "Building strong grassroots networks and creating positive social impact"
                            })]
                        }), u.jsxs("div", {
                            className: "value-card",
                            children: [u.jsx("h3", {
                                children: "Fair Play"
                            }), u.jsx("p", {
                                children: "Upholding ethical principles and rules of the game"
                            })]
                        }), u.jsxs("div", {
                            className: "value-card",
                            children: [u.jsx("h3", {
                                children: "Commitment"
                            }), u.jsx("p", {
                                children: "Dedicating ourselves to sustainable growth and player development"
                            })]
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "about-section",
                    children: [u.jsx("h2", {
                        children: "Commitment to Community Development"
                    }), u.jsx("p", {
                        children: "KMFA is committed to creating lasting positive change through minifootball. We believe sports can be a powerful tool for:"
                    }), u.jsxs("ul", {
                        children: [u.jsxs("li", {
                            children: [u.jsx("strong", {
                                children: "Youth Empowerment:"
                            }), " Providing opportunities for young people to develop skills, confidence, and leadership"]
                        }), u.jsxs("li", {
                            children: [u.jsx("strong", {
                                children: "Social Inclusion:"
                            }), " Breaking barriers and creating spaces for marginalized communities"]
                        }), u.jsxs("li", {
                            children: [u.jsx("strong", {
                                children: "Health & Wellness:"
                            }), " Promoting physical fitness and mental well-being through sports"]
                        }), u.jsxs("li", {
                            children: [u.jsx("strong", {
                                children: "Community Building:"
                            }), " Fostering unity and camaraderie within neighborhoods and regions"]
                        }), u.jsxs("li", {
                            children: [u.jsx("strong", {
                                children: "Talent Development:"
                            }), " Identifying and nurturing potential to connect with higher-level opportunities"]
                        })]
                    })]
                })]
            })
        })]
    })
}

function xv() {
    return u.jsxs("div", {
        className: "goals",
        children: [u.jsx("section", {
            className: "section goals-hero",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsx("h1", {
                    children: "Goals & Objectives"
                }), u.jsx("p", {
                    children: "Our strategic initiatives and targets for minifootball development"
                })]
            })
        }), u.jsx("section", {
            className: "section goals-content",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsxs("div", {
                    className: "goals-grid",
                    children: [u.jsxs("div", {
                        className: "goal-card",
                        children: [u.jsx("div", {
                            className: "goal-number",
                            children: "01"
                        }), u.jsx("h3", {
                            children: "Grassroots Minifootball Development"
                        }), u.jsx("p", {
                            children: "Establish minifootball programs at district and taluk levels, building a strong grassroots foundation. We aim to create structured development pathways for youth aged 8-18, ensuring quality coaching, proper facilities, and regular competitive opportunities."
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Create district-level development centers"
                            }), u.jsx("li", {
                                children: "Train and certify coaches"
                            }), u.jsx("li", {
                                children: "Organize age-group competitions"
                            }), u.jsx("li", {
                                children: "Provide equipment support to underfunded programs"
                            })]
                        })]
                    }), u.jsxs("div", {
                        className: "goal-card",
                        children: [u.jsx("div", {
                            className: "goal-number",
                            children: "02"
                        }), u.jsx("h3", {
                            children: "School & College Promotion"
                        }), u.jsx("p", {
                            children: "Integrate minifootball into school and college sports programs across Karnataka. We aim to reach 500+ educational institutions within 5 years, making minifootball a regular part of school sports curriculum."
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Conduct training sessions in schools"
                            }), u.jsx("li", {
                                children: "Establish inter-school tournaments"
                            }), u.jsx("li", {
                                children: "Support college leagues and championships"
                            }), u.jsx("li", {
                                children: "Provide coaching resources to institutions"
                            })]
                        })]
                    }), u.jsxs("div", {
                        className: "goal-card",
                        children: [u.jsx("div", {
                            className: "goal-number",
                            children: "03"
                        }), u.jsx("h3", {
                            children: "Rural Outreach Programs"
                        }), u.jsx("p", {
                            children: "Extend minifootball opportunities to rural and underserved communities. We're committed to reducing urban-rural gaps by bringing professional coaching and tournament opportunities to villages and small towns."
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Organize rural talent identification camps"
                            }), u.jsx("li", {
                                children: "Conduct free coaching clinics in villages"
                            }), u.jsx("li", {
                                children: "Create rural district leagues"
                            }), u.jsx("li", {
                                children: "Build community football fields"
                            })]
                        })]
                    }), u.jsxs("div", {
                        className: "goal-card",
                        children: [u.jsx("div", {
                            className: "goal-number",
                            children: "04"
                        }), u.jsx("h3", {
                            children: "Inclusivity Initiatives"
                        }), u.jsx("p", {
                            children: "Ensure equal opportunities for all sections of society including women, differently-abled athletes, and underprivileged youth. We aim to make minifootball truly inclusive through dedicated programs and resources."
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Women's tournaments and development programs"
                            }), u.jsx("li", {
                                children: "Inclusive sports programs for differently-abled individuals"
                            }), u.jsx("li", {
                                children: "Sponsorships for underprivileged talented players"
                            }), u.jsx("li", {
                                children: "Community outreach to marginalized groups"
                            })]
                        })]
                    }), u.jsxs("div", {
                        className: "goal-card",
                        children: [u.jsx("div", {
                            className: "goal-number",
                            children: "05"
                        }), u.jsx("h3", {
                            children: "Community Engagement & Social Impact"
                        }), u.jsx("p", {
                            children: "Use minifootball as a platform for social change. We aim to use sports to build values like teamwork, discipline, and leadership while creating positive community impact."
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Health and wellness programs"
                            }), u.jsx("li", {
                                children: "Character development through sports"
                            }), u.jsx("li", {
                                children: "Community tournaments and festivals"
                            }), u.jsx("li", {
                                children: "Youth empowerment and mentorship"
                            })]
                        })]
                    }), u.jsxs("div", {
                        className: "goal-card",
                        children: [u.jsx("div", {
                            className: "goal-number",
                            children: "06"
                        }), u.jsx("h3", {
                            children: "National & International Connection"
                        }), u.jsx("p", {
                            children: "Build pathways for talented players to reach national and international platforms. We aim to connect Karnataka's best talent with state and national teams, creating a pipeline for excellence."
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Scout and develop elite players"
                            }), u.jsx("li", {
                                children: "Partner with national federations"
                            }), u.jsx("li", {
                                children: "Send teams to national tournaments"
                            }), u.jsx("li", {
                                children: "Create international exchange programs"
                            })]
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "objectives-section",
                    children: [u.jsx("h2", {
                        children: "Key Objectives (3-5 Year Plan)"
                    }), u.jsxs("div", {
                        className: "objectives-list",
                        children: [u.jsxs("div", {
                            className: "objective-item",
                            children: [u.jsx("h3", {
                                children: "Year 1-2 Objectives"
                            }), u.jsxs("ul", {
                                children: [u.jsx("li", {
                                    children: "Establish KMFA governance structure and administrative framework"
                                }), u.jsx("li", {
                                    children: "Register 100+ clubs and 5000+ players"
                                }), u.jsx("li", {
                                    children: "Organize 50+ tournaments at district level"
                                }), u.jsx("li", {
                                    children: "Establish coaching standards and training programs"
                                }), u.jsx("li", {
                                    children: "Launch women's and youth development initiatives"
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "objective-item",
                            children: [u.jsx("h3", {
                                children: "Year 3-5 Objectives"
                            }), u.jsxs("ul", {
                                children: [u.jsx("li", {
                                    children: "Expand to 20+ districts with active programs"
                                }), u.jsx("li", {
                                    children: "Reach 500+ schools and colleges"
                                }), u.jsx("li", {
                                    children: "Train 200+ certified coaches"
                                }), u.jsx("li", {
                                    children: "Develop 1000+ players for higher levels"
                                }), u.jsx("li", {
                                    children: "Establish sustainable funding mechanisms"
                                }), u.jsx("li", {
                                    children: "Build partnerships with international federations"
                                })]
                            })]
                        })]
                    })]
                })]
            })
        })]
    })
}

function Ev() {
    return u.jsxs("div", {
        className: "achievements",
        children: [u.jsx("section", {
            className: "section achievements-hero",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsx("h1", {
                    children: "Our Achievements"
                }), u.jsx("p", {
                    children: "Milestones and successes in minifootball development"
                })]
            })
        }), u.jsx("section", {
            className: "section achievements-content",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsxs("div", {
                    className: "achievement-section",
                    children: [u.jsx("h2", {
                        children: "Major Tournaments Organized"
                    }), u.jsxs("div", {
                        className: "achievements-grid",
                        children: [u.jsxs("div", {
                            className: "achievement-card",
                            children: [u.jsx("h3", {
                                children: "State Minifootball Championship"
                            }), u.jsx("p", {
                                className: "achievement-year",
                                children: "2023-2024"
                            }), u.jsx("p", {
                                children: "Successfully organized the inaugural State Championship with 32 teams competing, representing 10 districts across Karnataka."
                            }), u.jsxs("div", {
                                className: "achievement-stats",
                                children: [u.jsx("span", {
                                    children: "32 Teams"
                                }), u.jsx("span", {
                                    children: "10 Districts"
                                }), u.jsx("span", {
                                    children: "500+ Players"
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "achievement-card",
                            children: [u.jsx("h3", {
                                children: "Youth Development Cup"
                            }), u.jsx("p", {
                                className: "achievement-year",
                                children: "2023-2024"
                            }), u.jsx("p", {
                                children: "Organized regional youth tournaments featuring players aged 8-16, reaching 250+ young talents in grassroots development."
                            }), u.jsxs("div", {
                                className: "achievement-stats",
                                children: [u.jsx("span", {
                                    children: "12 Tournaments"
                                }), u.jsx("span", {
                                    children: "250+ Players"
                                }), u.jsx("span", {
                                    children: "8 Age Groups"
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "achievement-card",
                            children: [u.jsx("h3", {
                                children: "Rural Outreach Tournament"
                            }), u.jsx("p", {
                                className: "achievement-year",
                                children: "2024"
                            }), u.jsx("p", {
                                children: "Conducted grassroots development tournaments in rural districts, bringing minifootball to underserved communities."
                            }), u.jsxs("div", {
                                className: "achievement-stats",
                                children: [u.jsx("span", {
                                    children: "15 Districts"
                                }), u.jsx("span", {
                                    children: "180 Teams"
                                }), u.jsx("span", {
                                    children: "2000+ Players"
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "achievement-card",
                            children: [u.jsx("h3", {
                                children: "Women's Minifootball League"
                            }), u.jsx("p", {
                                className: "achievement-year",
                                children: "2024"
                            }), u.jsx("p", {
                                children: "Launched dedicated women's league promoting gender inclusivity in minifootball with professional standards."
                            }), u.jsxs("div", {
                                className: "achievement-stats",
                                children: [u.jsx("span", {
                                    children: "24 Teams"
                                }), u.jsx("span", {
                                    children: "200+ Players"
                                }), u.jsx("span", {
                                    children: "4 Divisions"
                                })]
                            })]
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "achievement-section",
                    children: [u.jsx("h2", {
                        children: "Recognitions & Milestones"
                    }), u.jsxs("div", {
                        className: "milestones-list",
                        children: [u.jsxs("div", {
                            className: "milestone",
                            children: [u.jsx("span", {
                                className: "milestone-icon",
                                children: "⭐"
                            }), u.jsxs("div", {
                                className: "milestone-content",
                                children: [u.jsx("h3", {
                                    children: "Official Recognition"
                                }), u.jsx("p", {
                                    children: "Recognized as the official governing body for minifootball in Karnataka by state authorities"
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "milestone",
                            children: [u.jsx("span", {
                                className: "milestone-icon",
                                children: "👥"
                            }), u.jsxs("div", {
                                className: "milestone-content",
                                children: [u.jsx("h3", {
                                    children: "Player Registration"
                                }), u.jsx("p", {
                                    children: "Successfully registered 5000+ players across 100+ affiliated clubs in just 18 months"
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "milestone",
                            children: [u.jsx("span", {
                                className: "milestone-icon",
                                children: "🏆"
                            }), u.jsxs("div", {
                                className: "milestone-content",
                                children: [u.jsx("h3", {
                                    children: "National Participation"
                                }), u.jsx("p", {
                                    children: "Karnataka teams qualified and competed in national minifootball championships"
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "milestone",
                            children: [u.jsx("span", {
                                className: "milestone-icon",
                                children: "🎓"
                            }), u.jsxs("div", {
                                className: "milestone-content",
                                children: [u.jsx("h3", {
                                    children: "Coach Development"
                                }), u.jsx("p", {
                                    children: "Trained and certified 50+ coaches to international standards"
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "milestone",
                            children: [u.jsx("span", {
                                className: "milestone-icon",
                                children: "🌍"
                            }), u.jsxs("div", {
                                className: "milestone-content",
                                children: [u.jsx("h3", {
                                    children: "International Exposure"
                                }), u.jsx("p", {
                                    children: "Established partnerships with international minifootball organizations"
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "milestone",
                            children: [u.jsx("span", {
                                className: "milestone-icon",
                                children: "💡"
                            }), u.jsxs("div", {
                                className: "milestone-content",
                                children: [u.jsx("h3", {
                                    children: "Innovation Programs"
                                }), u.jsx("p", {
                                    children: "Launched grassroots development and community engagement programs"
                                })]
                            })]
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "achievement-section",
                    children: [u.jsx("h2", {
                        children: "Player & Team Success Stories"
                    }), u.jsxs("div", {
                        className: "success-stories",
                        children: [u.jsxs("div", {
                            className: "story",
                            children: [u.jsx("h3", {
                                children: "Rising Star: Rajesh Kumar"
                            }), u.jsx("p", {
                                children: "Discovered through KMFA's grassroots program in Hassan district, Rajesh progressed from village-level play to state championship finals. Now training with the state junior minifootball team for national selection."
                            })]
                        }), u.jsxs("div", {
                            className: "story",
                            children: [u.jsx("h3", {
                                children: "Team Excellence: Bangalore Blaze"
                            }), u.jsx("p", {
                                children: "From a small coaching center to state championship winners in 2 years. Bangalore Blaze represents the success of structured development and professional coaching standards promoted by KMFA."
                            })]
                        }), u.jsxs("div", {
                            className: "story",
                            children: [u.jsx("h3", {
                                children: "Women's Achievement: Mysore United"
                            }), u.jsx("p", {
                                children: "Women's team that participated in the inaugural Women's League, helping break barriers for women in minifootball. Many players now pursuing minifootball professionally."
                            })]
                        }), u.jsxs("div", {
                            className: "story",
                            children: [u.jsx("h3", {
                                children: "Inclusive Program: Differently-Abled Tournament"
                            }), u.jsx("p", {
                                children: "Successfully organized state's first minifootball tournament for differently-abled athletes, proving that minifootball is truly inclusive and accessible to all."
                            })]
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "achievement-section",
                    children: [u.jsx("h2", {
                        children: "Community Impact"
                    }), u.jsxs("div", {
                        className: "impact-stats",
                        children: [u.jsxs("div", {
                            className: "impact-card",
                            children: [u.jsx("h2", {
                                className: "impact-number",
                                children: "5000+"
                            }), u.jsx("p", {
                                children: "Registered Players"
                            })]
                        }), u.jsxs("div", {
                            className: "impact-card",
                            children: [u.jsx("h2", {
                                className: "impact-number",
                                children: "100+"
                            }), u.jsx("p", {
                                children: "Affiliated Clubs"
                            })]
                        }), u.jsxs("div", {
                            className: "impact-card",
                            children: [u.jsx("h2", {
                                className: "impact-number",
                                children: "20+"
                            }), u.jsx("p", {
                                children: "Districts Reached"
                            })]
                        }), u.jsxs("div", {
                            className: "impact-card",
                            children: [u.jsx("h2", {
                                className: "impact-number",
                                children: "200+"
                            }), u.jsx("p", {
                                children: "Tournaments Organized"
                            })]
                        }), u.jsxs("div", {
                            className: "impact-card",
                            children: [u.jsx("h2", {
                                className: "impact-number",
                                children: "50+"
                            }), u.jsx("p", {
                                children: "Certified Coaches"
                            })]
                        }), u.jsxs("div", {
                            className: "impact-card",
                            children: [u.jsx("h2", {
                                className: "impact-number",
                                children: "10000+"
                            }), u.jsx("p", {
                                children: "Community Beneficiaries"
                            })]
                        })]
                    })]
                })]
            })
        })]
    })
}

function Tv() {
    const [s] = Xe.useState([{
        id: "1",
        name: "State Minifootball Championship",
        date: "March 15-20, 2024",
        time: "8:00 AM onwards",
        location: "Bangalore City Football Stadium",
        category: "Championship",
        description: "The premier minifootball championship featuring elite teams from across Karnataka competing for state glory.",
        registration: "Team registration open"
    }, {
        id: "2",
        name: "Youth Development Cup - U-16",
        date: "April 10-12, 2024",
        time: "9:00 AM onwards",
        location: "Mysore Sports Complex",
        category: "Youth",
        description: "Tournament for young players aged 13-16, providing competitive exposure and development opportunities.",
        registration: "Individual & team registration open"
    }, {
        id: "3",
        name: "Women's Minifootball League 2024",
        date: "April 25 - May 15, 2024",
        time: "6:00 PM onwards",
        location: "Multiple venues across Karnataka",
        category: "Women",
        description: "Inaugural women's league promoting gender inclusivity and professional standards in minifootball.",
        registration: "Team registration ongoing"
    }, {
        id: "4",
        name: "Rural Outreach Tournament - Hassan",
        date: "May 5-7, 2024",
        time: "7:00 AM onwards",
        location: "Hassan District Sports Stadium",
        category: "Community",
        description: "Grassroots development tournament bringing minifootball opportunities to rural communities.",
        registration: "Village teams registration open"
    }, {
        id: "5",
        name: "School Minifootball Championship",
        date: "May 20-24, 2024",
        time: "3:30 PM onwards",
        location: "Various school grounds",
        category: "School",
        description: "Inter-school tournament for students to compete and develop their minifootball skills.",
        registration: "School team registration started"
    }, {
        id: "6",
        name: "Coaching Certification Workshop",
        date: "June 1-5, 2024",
        time: "9:00 AM to 5:00 PM",
        location: "KMFA Training Center, Bangalore",
        category: "Workshop",
        description: "Comprehensive coaching certification program based on international standards.",
        registration: "Application deadline May 20"
    }, {
        id: "7",
        name: "District League Finals - South",
        date: "June 10-12, 2024",
        time: "6:00 PM onwards",
        location: "Kottayam District Stadium",
        category: "League",
        description: "South Karnataka district league finals bringing together the best teams from the region.",
        registration: "Qualified teams advancing"
    }, {
        id: "8",
        name: "National Minifootball Championship Qualifiers",
        date: "July 1-5, 2024",
        time: "7:00 AM onwards",
        location: "TBA - Karnataka venues",
        category: "National",
        description: "Qualifying tournament for Karnataka teams to compete in national minifootball championships.",
        registration: "State champions will participate"
    }]), [a, l] = Xe.useState("all"), r = a === "all" ? s : s.filter(d => d.category === a), h = [{
        id: "all",
        name: "All Events"
    }, {
        id: "Championship",
        name: "Championship"
    }, {
        id: "Youth",
        name: "Youth"
    }, {
        id: "Women",
        name: "Women"
    }, {
        id: "Community",
        name: "Community"
    }, {
        id: "School",
        name: "School"
    }, {
        id: "Workshop",
        name: "Workshop"
    }, {
        id: "League",
        name: "League"
    }, {
        id: "National",
        name: "National"
    }];
    return u.jsxs("div", {
        className: "events-page",
        children: [u.jsx("section", {
            className: "section events-hero",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsx("h1", {
                    children: "Upcoming Events"
                }), u.jsx("p", {
                    children: "Tournaments, leagues, and programs happening across Karnataka"
                })]
            })
        }), u.jsx("section", {
            className: "section events-content",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsxs("div", {
                    className: "events-filters",
                    children: [u.jsx("h3", {
                        children: "Filter by Category"
                    }), u.jsx("div", {
                        className: "filter-buttons",
                        children: h.map(d => u.jsx("button", {
                            className: `filter-btn ${a===d.id?"active":""}`,
                            onClick: () => l(d.id),
                            children: d.name
                        }, d.id))
                    })]
                }), u.jsx("div", {
                    className: "events-list",
                    children: r.map(d => u.jsxs("div", {
                        className: "event-card",
                        children: [u.jsx("div", {
                            className: "event-category-badge",
                            children: d.category
                        }), u.jsxs("div", {
                            className: "event-details",
                            children: [u.jsx("h2", {
                                children: d.name
                            }), u.jsxs("div", {
                                className: "event-info-row",
                                children: [u.jsx("span", {
                                    className: "info-label",
                                    children: "📅 Date:"
                                }), u.jsx("span", {
                                    children: d.date
                                })]
                            }), u.jsxs("div", {
                                className: "event-info-row",
                                children: [u.jsx("span", {
                                    className: "info-label",
                                    children: "⏰ Time:"
                                }), u.jsx("span", {
                                    children: d.time
                                })]
                            }), u.jsxs("div", {
                                className: "event-info-row",
                                children: [u.jsx("span", {
                                    className: "info-label",
                                    children: "📍 Location:"
                                }), u.jsx("span", {
                                    children: d.location
                                })]
                            }), u.jsx("div", {
                                className: "event-description",
                                children: u.jsx("p", {
                                    children: d.description
                                })
                            }), d.registration && u.jsx("div", {
                                className: "event-registration",
                                children: u.jsxs("span", {
                                    className: "registration-status",
                                    children: ["✓ ", d.registration]
                                })
                            }), u.jsx("button", {
                                className: "btn-primary",
                                children: "Learn More"
                            })]
                        })]
                    }, d.id))
                }), r.length === 0 && u.jsx("div", {
                    className: "no-events",
                    children: u.jsx("p", {
                        children: "No events found in this category."
                    })
                })]
            })
        }), u.jsx("section", {
            className: "section events-note",
            children: u.jsx("div", {
                className: "container",
                children: u.jsxs("div", {
                    className: "info-box",
                    children: [u.jsx("h3", {
                        children: "Stay Updated"
                    }), u.jsxs("p", {
                        children: ["For more information about any event, please contact us at ", u.jsx("strong", {
                            children: "events@kmfa.org"
                        }), " or call us at ", u.jsx("strong", {
                            children: "+91 XXXXX XXXXX"
                        })]
                    }), u.jsx("p", {
                        children: "Follow our social media channels for real-time updates on tournaments, results, and community initiatives."
                    })]
                })
            })
        })]
    })
}

function Yl(s, a) {
    var l = {};
    for (var r in s) Object.prototype.hasOwnProperty.call(s, r) && a.indexOf(r) < 0 && (l[r] = s[r]);
    if (s != null && typeof Object.getOwnPropertySymbols == "function")
        for (var h = 0, r = Object.getOwnPropertySymbols(s); h < r.length; h++) a.indexOf(r[h]) < 0 && Object.prototype.propertyIsEnumerable.call(s, r[h]) && (l[r[h]] = s[r[h]]);
    return l
}

function Av(s, a, l, r) {
    function h(d) {
        return d instanceof l ? d : new l(function(m) {
            m(d)
        })
    }
    return new(l || (l = Promise))(function(d, m) {
        function g(_) {
            try {
                v(r.next(_))
            } catch (w) {
                m(w)
            }
        }

        function y(_) {
            try {
                v(r.throw(_))
            } catch (w) {
                m(w)
            }
        }

        function v(_) {
            _.done ? d(_.value) : h(_.value).then(g, y)
        }
        v((r = r.apply(s, a || [])).next())
    })
}
const Ov = s => s ? (...a) => s(...a) : (...a) => fetch(...a);
class Bu extends Error {
    constructor(a, l = "FunctionsError", r) {
        super(a), this.name = l, this.context = r
    }
}
class Nv extends Bu {
    constructor(a) {
        super("Failed to send a request to the Edge Function", "FunctionsFetchError", a)
    }
}
class Ff extends Bu {
    constructor(a) {
        super("Relay Error invoking the Edge Function", "FunctionsRelayError", a)
    }
}
class em extends Bu {
    constructor(a) {
        super("Edge Function returned a non-2xx status code", "FunctionsHttpError", a)
    }
}
var Tu;
(function(s) {
    s.Any = "any", s.ApNortheast1 = "ap-northeast-1", s.ApNortheast2 = "ap-northeast-2", s.ApSouth1 = "ap-south-1", s.ApSoutheast1 = "ap-southeast-1", s.ApSoutheast2 = "ap-southeast-2", s.CaCentral1 = "ca-central-1", s.EuCentral1 = "eu-central-1", s.EuWest1 = "eu-west-1", s.EuWest2 = "eu-west-2", s.EuWest3 = "eu-west-3", s.SaEast1 = "sa-east-1", s.UsEast1 = "us-east-1", s.UsWest1 = "us-west-1", s.UsWest2 = "us-west-2"
})(Tu || (Tu = {}));
class Rv {
    constructor(a, {
        headers: l = {},
        customFetch: r,
        region: h = Tu.Any
    } = {}) {
        this.url = a, this.headers = l, this.region = h, this.fetch = Ov(r)
    }
    setAuth(a) {
        this.headers.Authorization = `Bearer ${a}`
    }
    invoke(a) {
        return Av(this, arguments, void 0, function*(l, r = {}) {
            var h;
            let d, m;
            try {
                const {
                    headers: g,
                    method: y,
                    body: v,
                    signal: _,
                    timeout: w
                } = r;
                let E = {},
                    {
                        region: O
                    } = r;
                O || (O = this.region);
                const k = new URL(`${this.url}/${l}`);
                O && O !== "any" && (E["x-region"] = O, k.searchParams.set("forceFunctionRegion", O));
                let B;
                v && (g && !Object.prototype.hasOwnProperty.call(g, "Content-Type") || !g) ? typeof Blob < "u" && v instanceof Blob || v instanceof ArrayBuffer ? (E["Content-Type"] = "application/octet-stream", B = v) : typeof v == "string" ? (E["Content-Type"] = "text/plain", B = v) : typeof FormData < "u" && v instanceof FormData ? B = v : (E["Content-Type"] = "application/json", B = JSON.stringify(v)) : v && typeof v != "string" && !(typeof Blob < "u" && v instanceof Blob) && !(v instanceof ArrayBuffer) && !(typeof FormData < "u" && v instanceof FormData) ? B = JSON.stringify(v) : B = v;
                let L = _;
                w && (m = new AbortController, d = setTimeout(() => m.abort(), w), _ ? (L = m.signal, _.addEventListener("abort", () => m.abort())) : L = m.signal);
                const H = yield this.fetch(k.toString(), {
                    method: y || "POST",
                    headers: Object.assign(Object.assign(Object.assign({}, E), this.headers), g),
                    body: B,
                    signal: L
                }).catch(ye => {
                    throw new Nv(ye)
                }), $ = H.headers.get("x-relay-error");
                if ($ && $ === "true") throw new Ff(H);
                if (!H.ok) throw new em(H);
                let q = ((h = H.headers.get("Content-Type")) !== null && h !== void 0 ? h : "text/plain").split(";")[0].trim(),
                    I;
                return q === "application/json" ? I = yield H.json(): q === "application/octet-stream" || q === "application/pdf" ? I = yield H.blob(): q === "text/event-stream" ? I = H : q === "multipart/form-data" ? I = yield H.formData(): I = yield H.text(), {
                    data: I,
                    error: null,
                    response: H
                }
            } catch (g) {
                return {
                    data: null,
                    error: g,
                    response: g instanceof em || g instanceof Ff ? g.context : void 0
                }
            } finally {
                d && clearTimeout(d)
            }
        })
    }
}
var Cv = class extends Error {
        constructor(s) {
            super(s.message), this.name = "PostgrestError", this.details = s.details, this.hint = s.hint, this.code = s.code
        }
    },
    Dv = class {
        constructor(s) {
            var a, l, r;
            this.shouldThrowOnError = !1, this.method = s.method, this.url = s.url, this.headers = new Headers(s.headers), this.schema = s.schema, this.body = s.body, this.shouldThrowOnError = (a = s.shouldThrowOnError) !== null && a !== void 0 ? a : !1, this.signal = s.signal, this.isMaybeSingle = (l = s.isMaybeSingle) !== null && l !== void 0 ? l : !1, this.urlLengthLimit = (r = s.urlLengthLimit) !== null && r !== void 0 ? r : 8e3, s.fetch ? this.fetch = s.fetch : this.fetch = fetch
        }
        throwOnError() {
            return this.shouldThrowOnError = !0, this
        }
        setHeader(s, a) {
            return this.headers = new Headers(this.headers), this.headers.set(s, a), this
        }
        then(s, a) {
            var l = this;
            this.schema === void 0 || (["GET", "HEAD"].includes(this.method) ? this.headers.set("Accept-Profile", this.schema) : this.headers.set("Content-Profile", this.schema)), this.method !== "GET" && this.method !== "HEAD" && this.headers.set("Content-Type", "application/json");
            const r = this.fetch;
            let h = r(this.url.toString(), {
                method: this.method,
                headers: this.headers,
                body: JSON.stringify(this.body),
                signal: this.signal
            }).then(async d => {
                let m = null,
                    g = null,
                    y = null,
                    v = d.status,
                    _ = d.statusText;
                if (d.ok) {
                    var w, E;
                    if (l.method !== "HEAD") {
                        var O;
                        const H = await d.text();
                        H === "" || (l.headers.get("Accept") === "text/csv" || l.headers.get("Accept") && (!((O = l.headers.get("Accept")) === null || O === void 0) && O.includes("application/vnd.pgrst.plan+text")) ? g = H : g = JSON.parse(H))
                    }
                    const B = (w = l.headers.get("Prefer")) === null || w === void 0 ? void 0 : w.match(/count=(exact|planned|estimated)/),
                        L = (E = d.headers.get("content-range")) === null || E === void 0 ? void 0 : E.split("/");
                    B && L && L.length > 1 && (y = parseInt(L[1])), l.isMaybeSingle && l.method === "GET" && Array.isArray(g) && (g.length > 1 ? (m = {
                        code: "PGRST116",
                        details: `Results contain ${g.length} rows, application/vnd.pgrst.object+json requires 1 row`,
                        hint: null,
                        message: "JSON object requested, multiple (or no) rows returned"
                    }, g = null, y = null, v = 406, _ = "Not Acceptable") : g.length === 1 ? g = g[0] : g = null)
                } else {
                    var k;
                    const B = await d.text();
                    try {
                        m = JSON.parse(B), Array.isArray(m) && d.status === 404 && (g = [], m = null, v = 200, _ = "OK")
                    } catch {
                        d.status === 404 && B === "" ? (v = 204, _ = "No Content") : m = {
                            message: B
                        }
                    }
                    if (m && l.isMaybeSingle && (!(m == null || (k = m.details) === null || k === void 0) && k.includes("0 rows")) && (m = null, v = 200, _ = "OK"), m && l.shouldThrowOnError) throw new Cv(m)
                }
                return {
                    error: m,
                    data: g,
                    count: y,
                    status: v,
                    statusText: _
                }
            });
            return this.shouldThrowOnError || (h = h.catch(d => {
                var m;
                let g = "",
                    y = "",
                    v = "";
                const _ = d ? .cause;
                if (_) {
                    var w, E, O, k;
                    const H = (w = _ ? .message) !== null && w !== void 0 ? w : "",
                        $ = (E = _ ? .code) !== null && E !== void 0 ? E : "";
                    g = `${(O=d?.name)!==null&&O!==void 0?O:"FetchError"}: ${d?.message}`, g += `

Caused by: ${(k=_?.name)!==null&&k!==void 0?k:"Error"}: ${H}`, $ && (g += ` (${$})`), _ ? .stack && (g += `
${_.stack}`)
                } else {
                    var B;
                    g = (B = d ? .stack) !== null && B !== void 0 ? B : ""
                }
                const L = this.url.toString().length;
                return d ? .name === "AbortError" || d ? .code === "ABORT_ERR" ? (v = "", y = "Request was aborted (timeout or manual cancellation)", L > this.urlLengthLimit && (y += `. Note: Your request URL is ${L} characters, which may exceed server limits. If selecting many fields, consider using views. If filtering with large arrays (e.g., .in('id', [many IDs])), consider using an RPC function to pass values server-side.`)) : (_ ? .name === "HeadersOverflowError" || _ ? .code === "UND_ERR_HEADERS_OVERFLOW") && (v = "", y = "HTTP headers exceeded server limits (typically 16KB)", L > this.urlLengthLimit && (y += `. Your request URL is ${L} characters. If selecting many fields, consider using views. If filtering with large arrays (e.g., .in('id', [200+ IDs])), consider using an RPC function instead.`)), {
                    error: {
                        message: `${(m=d?.name)!==null&&m!==void 0?m:"FetchError"}: ${d?.message}`,
                        details: g,
                        hint: y,
                        code: v
                    },
                    data: null,
                    count: null,
                    status: 0,
                    statusText: ""
                }
            })), h.then(s, a)
        }
        returns() {
            return this
        }
        overrideTypes() {
            return this
        }
    },
    Uv = class extends Dv {
        select(s) {
            let a = !1;
            const l = (s ? ? "*").split("").map(r => /\s/.test(r) && !a ? "" : (r === '"' && (a = !a), r)).join("");
            return this.url.searchParams.set("select", l), this.headers.append("Prefer", "return=representation"), this
        }
        order(s, {
            ascending: a = !0,
            nullsFirst: l,
            foreignTable: r,
            referencedTable: h = r
        } = {}) {
            const d = h ? `${h}.order` : "order",
                m = this.url.searchParams.get(d);
            return this.url.searchParams.set(d, `${m?`${m},`:""}${s}.${a?"asc":"desc"}${l===void 0?"":l?".nullsfirst":".nullslast"}`), this
        }
        limit(s, {
            foreignTable: a,
            referencedTable: l = a
        } = {}) {
            const r = typeof l > "u" ? "limit" : `${l}.limit`;
            return this.url.searchParams.set(r, `${s}`), this
        }
        range(s, a, {
            foreignTable: l,
            referencedTable: r = l
        } = {}) {
            const h = typeof r > "u" ? "offset" : `${r}.offset`,
                d = typeof r > "u" ? "limit" : `${r}.limit`;
            return this.url.searchParams.set(h, `${s}`), this.url.searchParams.set(d, `${a-s+1}`), this
        }
        abortSignal(s) {
            return this.signal = s, this
        }
        single() {
            return this.headers.set("Accept", "application/vnd.pgrst.object+json"), this
        }
        maybeSingle() {
            return this.method === "GET" ? this.headers.set("Accept", "application/json") : this.headers.set("Accept", "application/vnd.pgrst.object+json"), this.isMaybeSingle = !0, this
        }
        csv() {
            return this.headers.set("Accept", "text/csv"), this
        }
        geojson() {
            return this.headers.set("Accept", "application/geo+json"), this
        }
        explain({
            analyze: s = !1,
            verbose: a = !1,
            settings: l = !1,
            buffers: r = !1,
            wal: h = !1,
            format: d = "text"
        } = {}) {
            var m;
            const g = [s ? "analyze" : null, a ? "verbose" : null, l ? "settings" : null, r ? "buffers" : null, h ? "wal" : null].filter(Boolean).join("|"),
                y = (m = this.headers.get("Accept")) !== null && m !== void 0 ? m : "application/json";
            return this.headers.set("Accept", `application/vnd.pgrst.plan+${d}; for="${y}"; options=${g};`), d === "json" ? this : this
        }
        rollback() {
            return this.headers.append("Prefer", "tx=rollback"), this
        }
        returns() {
            return this
        }
        maxAffected(s) {
            return this.headers.append("Prefer", "handling=strict"), this.headers.append("Prefer", `max-affected=${s}`), this
        }
    };
const tm = new RegExp("[,()]");
var ai = class extends Uv {
        eq(s, a) {
            return this.url.searchParams.append(s, `eq.${a}`), this
        }
        neq(s, a) {
            return this.url.searchParams.append(s, `neq.${a}`), this
        }
        gt(s, a) {
            return this.url.searchParams.append(s, `gt.${a}`), this
        }
        gte(s, a) {
            return this.url.searchParams.append(s, `gte.${a}`), this
        }
        lt(s, a) {
            return this.url.searchParams.append(s, `lt.${a}`), this
        }
        lte(s, a) {
            return this.url.searchParams.append(s, `lte.${a}`), this
        }
        like(s, a) {
            return this.url.searchParams.append(s, `like.${a}`), this
        }
        likeAllOf(s, a) {
            return this.url.searchParams.append(s, `like(all).{${a.join(",")}}`), this
        }
        likeAnyOf(s, a) {
            return this.url.searchParams.append(s, `like(any).{${a.join(",")}}`), this
        }
        ilike(s, a) {
            return this.url.searchParams.append(s, `ilike.${a}`), this
        }
        ilikeAllOf(s, a) {
            return this.url.searchParams.append(s, `ilike(all).{${a.join(",")}}`), this
        }
        ilikeAnyOf(s, a) {
            return this.url.searchParams.append(s, `ilike(any).{${a.join(",")}}`), this
        }
        regexMatch(s, a) {
            return this.url.searchParams.append(s, `match.${a}`), this
        }
        regexIMatch(s, a) {
            return this.url.searchParams.append(s, `imatch.${a}`), this
        }
        is(s, a) {
            return this.url.searchParams.append(s, `is.${a}`), this
        }
        isDistinct(s, a) {
            return this.url.searchParams.append(s, `isdistinct.${a}`), this
        } in (s, a) {
            const l = Array.from(new Set(a)).map(r => typeof r == "string" && tm.test(r) ? `"${r}"` : `${r}`).join(",");
            return this.url.searchParams.append(s, `in.(${l})`), this
        }
        notIn(s, a) {
            const l = Array.from(new Set(a)).map(r => typeof r == "string" && tm.test(r) ? `"${r}"` : `${r}`).join(",");
            return this.url.searchParams.append(s, `not.in.(${l})`), this
        }
        contains(s, a) {
            return typeof a == "string" ? this.url.searchParams.append(s, `cs.${a}`) : Array.isArray(a) ? this.url.searchParams.append(s, `cs.{${a.join(",")}}`) : this.url.searchParams.append(s, `cs.${JSON.stringify(a)}`), this
        }
        containedBy(s, a) {
            return typeof a == "string" ? this.url.searchParams.append(s, `cd.${a}`) : Array.isArray(a) ? this.url.searchParams.append(s, `cd.{${a.join(",")}}`) : this.url.searchParams.append(s, `cd.${JSON.stringify(a)}`), this
        }
        rangeGt(s, a) {
            return this.url.searchParams.append(s, `sr.${a}`), this
        }
        rangeGte(s, a) {
            return this.url.searchParams.append(s, `nxl.${a}`), this
        }
        rangeLt(s, a) {
            return this.url.searchParams.append(s, `sl.${a}`), this
        }
        rangeLte(s, a) {
            return this.url.searchParams.append(s, `nxr.${a}`), this
        }
        rangeAdjacent(s, a) {
            return this.url.searchParams.append(s, `adj.${a}`), this
        }
        overlaps(s, a) {
            return typeof a == "string" ? this.url.searchParams.append(s, `ov.${a}`) : this.url.searchParams.append(s, `ov.{${a.join(",")}}`), this
        }
        textSearch(s, a, {
            config: l,
            type: r
        } = {}) {
            let h = "";
            r === "plain" ? h = "pl" : r === "phrase" ? h = "ph" : r === "websearch" && (h = "w");
            const d = l === void 0 ? "" : `(${l})`;
            return this.url.searchParams.append(s, `${h}fts${d}.${a}`), this
        }
        match(s) {
            return Object.entries(s).forEach(([a, l]) => {
                this.url.searchParams.append(a, `eq.${l}`)
            }), this
        }
        not(s, a, l) {
            return this.url.searchParams.append(s, `not.${a}.${l}`), this
        }
        or(s, {
            foreignTable: a,
            referencedTable: l = a
        } = {}) {
            const r = l ? `${l}.or` : "or";
            return this.url.searchParams.append(r, `(${s})`), this
        }
        filter(s, a, l) {
            return this.url.searchParams.append(s, `${a}.${l}`), this
        }
    },
    kv = class {
        constructor(s, {
            headers: a = {},
            schema: l,
            fetch: r,
            urlLengthLimit: h = 8e3
        }) {
            this.url = s, this.headers = new Headers(a), this.schema = l, this.fetch = r, this.urlLengthLimit = h
        }
        cloneRequestState() {
            return {
                url: new URL(this.url.toString()),
                headers: new Headers(this.headers)
            }
        }
        select(s, a) {
            const {
                head: l = !1,
                count: r
            } = a ? ? {}, h = l ? "HEAD" : "GET";
            let d = !1;
            const m = (s ? ? "*").split("").map(v => /\s/.test(v) && !d ? "" : (v === '"' && (d = !d), v)).join(""),
                {
                    url: g,
                    headers: y
                } = this.cloneRequestState();
            return g.searchParams.set("select", m), r && y.append("Prefer", `count=${r}`), new ai({
                method: h,
                url: g,
                headers: y,
                schema: this.schema,
                fetch: this.fetch,
                urlLengthLimit: this.urlLengthLimit
            })
        }
        insert(s, {
            count: a,
            defaultToNull: l = !0
        } = {}) {
            var r;
            const h = "POST",
                {
                    url: d,
                    headers: m
                } = this.cloneRequestState();
            if (a && m.append("Prefer", `count=${a}`), l || m.append("Prefer", "missing=default"), Array.isArray(s)) {
                const g = s.reduce((y, v) => y.concat(Object.keys(v)), []);
                if (g.length > 0) {
                    const y = [...new Set(g)].map(v => `"${v}"`);
                    d.searchParams.set("columns", y.join(","))
                }
            }
            return new ai({
                method: h,
                url: d,
                headers: m,
                schema: this.schema,
                body: s,
                fetch: (r = this.fetch) !== null && r !== void 0 ? r : fetch,
                urlLengthLimit: this.urlLengthLimit
            })
        }
        upsert(s, {
            onConflict: a,
            ignoreDuplicates: l = !1,
            count: r,
            defaultToNull: h = !0
        } = {}) {
            var d;
            const m = "POST",
                {
                    url: g,
                    headers: y
                } = this.cloneRequestState();
            if (y.append("Prefer", `resolution=${l?"ignore":"merge"}-duplicates`), a !== void 0 && g.searchParams.set("on_conflict", a), r && y.append("Prefer", `count=${r}`), h || y.append("Prefer", "missing=default"), Array.isArray(s)) {
                const v = s.reduce((_, w) => _.concat(Object.keys(w)), []);
                if (v.length > 0) {
                    const _ = [...new Set(v)].map(w => `"${w}"`);
                    g.searchParams.set("columns", _.join(","))
                }
            }
            return new ai({
                method: m,
                url: g,
                headers: y,
                schema: this.schema,
                body: s,
                fetch: (d = this.fetch) !== null && d !== void 0 ? d : fetch,
                urlLengthLimit: this.urlLengthLimit
            })
        }
        update(s, {
            count: a
        } = {}) {
            var l;
            const r = "PATCH",
                {
                    url: h,
                    headers: d
                } = this.cloneRequestState();
            return a && d.append("Prefer", `count=${a}`), new ai({
                method: r,
                url: h,
                headers: d,
                schema: this.schema,
                body: s,
                fetch: (l = this.fetch) !== null && l !== void 0 ? l : fetch,
                urlLengthLimit: this.urlLengthLimit
            })
        }
        delete({
            count: s
        } = {}) {
            var a;
            const l = "DELETE",
                {
                    url: r,
                    headers: h
                } = this.cloneRequestState();
            return s && h.append("Prefer", `count=${s}`), new ai({
                method: l,
                url: r,
                headers: h,
                schema: this.schema,
                fetch: (a = this.fetch) !== null && a !== void 0 ? a : fetch,
                urlLengthLimit: this.urlLengthLimit
            })
        }
    };

function os(s) {
    "@babel/helpers - typeof";
    return os = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(a) {
        return typeof a
    } : function(a) {
        return a && typeof Symbol == "function" && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
    }, os(s)
}

function zv(s, a) {
    if (os(s) != "object" || !s) return s;
    var l = s[Symbol.toPrimitive];
    if (l !== void 0) {
        var r = l.call(s, a);
        if (os(r) != "object") return r;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (a === "string" ? String : Number)(s)
}

function Mv(s) {
    var a = zv(s, "string");
    return os(a) == "symbol" ? a : a + ""
}

function Bv(s, a, l) {
    return (a = Mv(a)) in s ? Object.defineProperty(s, a, {
        value: l,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : s[a] = l, s
}

function nm(s, a) {
    var l = Object.keys(s);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(s);
        a && (r = r.filter(function(h) {
            return Object.getOwnPropertyDescriptor(s, h).enumerable
        })), l.push.apply(l, r)
    }
    return l
}

function kl(s) {
    for (var a = 1; a < arguments.length; a++) {
        var l = arguments[a] != null ? arguments[a] : {};
        a % 2 ? nm(Object(l), !0).forEach(function(r) {
            Bv(s, r, l[r])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(s, Object.getOwnPropertyDescriptors(l)) : nm(Object(l)).forEach(function(r) {
            Object.defineProperty(s, r, Object.getOwnPropertyDescriptor(l, r))
        })
    }
    return s
}
var qv = class xm {
    constructor(a, {
        headers: l = {},
        schema: r,
        fetch: h,
        timeout: d,
        urlLengthLimit: m = 8e3
    } = {}) {
        this.url = a, this.headers = new Headers(l), this.schemaName = r, this.urlLengthLimit = m;
        const g = h ? ? globalThis.fetch;
        d !== void 0 && d > 0 ? this.fetch = (y, v) => {
            const _ = new AbortController,
                w = setTimeout(() => _.abort(), d),
                E = v ? .signal;
            if (E) {
                if (E.aborted) return clearTimeout(w), g(y, v);
                const O = () => {
                    clearTimeout(w), _.abort()
                };
                return E.addEventListener("abort", O, {
                    once: !0
                }), g(y, kl(kl({}, v), {}, {
                    signal: _.signal
                })).finally(() => {
                    clearTimeout(w), E.removeEventListener("abort", O)
                })
            }
            return g(y, kl(kl({}, v), {}, {
                signal: _.signal
            })).finally(() => clearTimeout(w))
        } : this.fetch = g
    }
    from(a) {
        if (!a || typeof a != "string" || a.trim() === "") throw new Error("Invalid relation name: relation must be a non-empty string.");
        return new kv(new URL(`${this.url}/${a}`), {
            headers: new Headers(this.headers),
            schema: this.schemaName,
            fetch: this.fetch,
            urlLengthLimit: this.urlLengthLimit
        })
    }
    schema(a) {
        return new xm(this.url, {
            headers: this.headers,
            schema: a,
            fetch: this.fetch,
            urlLengthLimit: this.urlLengthLimit
        })
    }
    rpc(a, l = {}, {
        head: r = !1,
        get: h = !1,
        count: d
    } = {}) {
        var m;
        let g;
        const y = new URL(`${this.url}/rpc/${a}`);
        let v;
        const _ = O => O !== null && typeof O == "object" && (!Array.isArray(O) || O.some(_)),
            w = r && Object.values(l).some(_);
        w ? (g = "POST", v = l) : r || h ? (g = r ? "HEAD" : "GET", Object.entries(l).filter(([O, k]) => k !== void 0).map(([O, k]) => [O, Array.isArray(k) ? `{${k.join(",")}}` : `${k}`]).forEach(([O, k]) => {
            y.searchParams.append(O, k)
        })) : (g = "POST", v = l);
        const E = new Headers(this.headers);
        return w ? E.set("Prefer", d ? `count=${d},return=minimal` : "return=minimal") : d && E.set("Prefer", `count=${d}`), new ai({
            method: g,
            url: y,
            headers: E,
            schema: this.schemaName,
            body: v,
            fetch: (m = this.fetch) !== null && m !== void 0 ? m : fetch,
            urlLengthLimit: this.urlLengthLimit
        })
    }
};
class Lv {
    constructor() {}
    static detectEnvironment() {
        var a;
        if (typeof WebSocket < "u") return {
            type: "native",
            constructor: WebSocket
        };
        if (typeof globalThis < "u" && typeof globalThis.WebSocket < "u") return {
            type: "native",
            constructor: globalThis.WebSocket
        };
        if (typeof global < "u" && typeof global.WebSocket < "u") return {
            type: "native",
            constructor: global.WebSocket
        };
        if (typeof globalThis < "u" && typeof globalThis.WebSocketPair < "u" && typeof globalThis.WebSocket > "u") return {
            type: "cloudflare",
            error: "Cloudflare Workers detected. WebSocket clients are not supported in Cloudflare Workers.",
            workaround: "Use Cloudflare Workers WebSocket API for server-side WebSocket handling, or deploy to a different runtime."
        };
        if (typeof globalThis < "u" && globalThis.EdgeRuntime || typeof navigator < "u" && (!((a = navigator.userAgent) === null || a === void 0) && a.includes("Vercel-Edge"))) return {
            type: "unsupported",
            error: "Edge runtime detected (Vercel Edge/Netlify Edge). WebSockets are not supported in edge functions.",
            workaround: "Use serverless functions or a different deployment target for WebSocket functionality."
        };
        const l = globalThis.process;
        if (l) {
            const r = l.versions;
            if (r && r.node) {
                const h = r.node,
                    d = parseInt(h.replace(/^v/, "").split(".")[0]);
                return d >= 22 ? typeof globalThis.WebSocket < "u" ? {
                    type: "native",
                    constructor: globalThis.WebSocket
                } : {
                    type: "unsupported",
                    error: `Node.js ${d} detected but native WebSocket not found.`,
                    workaround: "Provide a WebSocket implementation via the transport option."
                } : {
                    type: "unsupported",
                    error: `Node.js ${d} detected without native WebSocket support.`,
                    workaround: `For Node.js < 22, install "ws" package and provide it via the transport option:
import ws from "ws"
new RealtimeClient(url, { transport: ws })`
                }
            }
        }
        return {
            type: "unsupported",
            error: "Unknown JavaScript runtime without WebSocket support.",
            workaround: "Ensure you're running in a supported environment (browser, Node.js, Deno) or provide a custom WebSocket implementation."
        }
    }
    static getWebSocketConstructor() {
        const a = this.detectEnvironment();
        if (a.constructor) return a.constructor;
        let l = a.error || "WebSocket not supported in this environment.";
        throw a.workaround && (l += `

Suggested solution: ${a.workaround}`), new Error(l)
    }
    static createWebSocket(a, l) {
        const r = this.getWebSocketConstructor();
        return new r(a, l)
    }
    static isWebSocketSupported() {
        try {
            const a = this.detectEnvironment();
            return a.type === "native" || a.type === "ws"
        } catch {
            return !1
        }
    }
}
const Hv = "2.95.3",
    Gv = `realtime-js/${Hv}`,
    Kv = "1.0.0",
    Em = "2.0.0",
    am = Em,
    Au = 1e4,
    $v = 1e3,
    Yv = 100;
var qn;
(function(s) {
    s[s.connecting = 0] = "connecting", s[s.open = 1] = "open", s[s.closing = 2] = "closing", s[s.closed = 3] = "closed"
})(qn || (qn = {}));
var $e;
(function(s) {
    s.closed = "closed", s.errored = "errored", s.joined = "joined", s.joining = "joining", s.leaving = "leaving"
})($e || ($e = {}));
var Lt;
(function(s) {
    s.close = "phx_close", s.error = "phx_error", s.join = "phx_join", s.reply = "phx_reply", s.leave = "phx_leave", s.access_token = "access_token"
})(Lt || (Lt = {}));
var Ou;
(function(s) {
    s.websocket = "websocket"
})(Ou || (Ou = {}));
var ua;
(function(s) {
    s.Connecting = "connecting", s.Open = "open", s.Closing = "closing", s.Closed = "closed"
})(ua || (ua = {}));
class Vv {
    constructor(a) {
        this.HEADER_LENGTH = 1, this.USER_BROADCAST_PUSH_META_LENGTH = 6, this.KINDS = {
            userBroadcastPush: 3,
            userBroadcast: 4
        }, this.BINARY_ENCODING = 0, this.JSON_ENCODING = 1, this.BROADCAST_EVENT = "broadcast", this.allowedMetadataKeys = [], this.allowedMetadataKeys = a ? ? []
    }
    encode(a, l) {
        if (a.event === this.BROADCAST_EVENT && !(a.payload instanceof ArrayBuffer) && typeof a.payload.event == "string") return l(this._binaryEncodeUserBroadcastPush(a));
        let r = [a.join_ref, a.ref, a.topic, a.event, a.payload];
        return l(JSON.stringify(r))
    }
    _binaryEncodeUserBroadcastPush(a) {
        var l;
        return this._isArrayBuffer((l = a.payload) === null || l === void 0 ? void 0 : l.payload) ? this._encodeBinaryUserBroadcastPush(a) : this._encodeJsonUserBroadcastPush(a)
    }
    _encodeBinaryUserBroadcastPush(a) {
        var l, r;
        const h = (r = (l = a.payload) === null || l === void 0 ? void 0 : l.payload) !== null && r !== void 0 ? r : new ArrayBuffer(0);
        return this._encodeUserBroadcastPush(a, this.BINARY_ENCODING, h)
    }
    _encodeJsonUserBroadcastPush(a) {
        var l, r;
        const h = (r = (l = a.payload) === null || l === void 0 ? void 0 : l.payload) !== null && r !== void 0 ? r : {},
            m = new TextEncoder().encode(JSON.stringify(h)).buffer;
        return this._encodeUserBroadcastPush(a, this.JSON_ENCODING, m)
    }
    _encodeUserBroadcastPush(a, l, r) {
        var h, d;
        const m = a.topic,
            g = (h = a.ref) !== null && h !== void 0 ? h : "",
            y = (d = a.join_ref) !== null && d !== void 0 ? d : "",
            v = a.payload.event,
            _ = this.allowedMetadataKeys ? this._pick(a.payload, this.allowedMetadataKeys) : {},
            w = Object.keys(_).length === 0 ? "" : JSON.stringify(_);
        if (y.length > 255) throw new Error(`joinRef length ${y.length} exceeds maximum of 255`);
        if (g.length > 255) throw new Error(`ref length ${g.length} exceeds maximum of 255`);
        if (m.length > 255) throw new Error(`topic length ${m.length} exceeds maximum of 255`);
        if (v.length > 255) throw new Error(`userEvent length ${v.length} exceeds maximum of 255`);
        if (w.length > 255) throw new Error(`metadata length ${w.length} exceeds maximum of 255`);
        const E = this.USER_BROADCAST_PUSH_META_LENGTH + y.length + g.length + m.length + v.length + w.length,
            O = new ArrayBuffer(this.HEADER_LENGTH + E);
        let k = new DataView(O),
            B = 0;
        k.setUint8(B++, this.KINDS.userBroadcastPush), k.setUint8(B++, y.length), k.setUint8(B++, g.length), k.setUint8(B++, m.length), k.setUint8(B++, v.length), k.setUint8(B++, w.length), k.setUint8(B++, l), Array.from(y, H => k.setUint8(B++, H.charCodeAt(0))), Array.from(g, H => k.setUint8(B++, H.charCodeAt(0))), Array.from(m, H => k.setUint8(B++, H.charCodeAt(0))), Array.from(v, H => k.setUint8(B++, H.charCodeAt(0))), Array.from(w, H => k.setUint8(B++, H.charCodeAt(0)));
        var L = new Uint8Array(O.byteLength + r.byteLength);
        return L.set(new Uint8Array(O), 0), L.set(new Uint8Array(r), O.byteLength), L.buffer
    }
    decode(a, l) {
        if (this._isArrayBuffer(a)) {
            let r = this._binaryDecode(a);
            return l(r)
        }
        if (typeof a == "string") {
            const r = JSON.parse(a),
                [h, d, m, g, y] = r;
            return l({
                join_ref: h,
                ref: d,
                topic: m,
                event: g,
                payload: y
            })
        }
        return l({})
    }
    _binaryDecode(a) {
        const l = new DataView(a),
            r = l.getUint8(0),
            h = new TextDecoder;
        if (r === this.KINDS.userBroadcast) return this._decodeUserBroadcast(a, l, h)
    }
    _decodeUserBroadcast(a, l, r) {
        const h = l.getUint8(1),
            d = l.getUint8(2),
            m = l.getUint8(3),
            g = l.getUint8(4);
        let y = this.HEADER_LENGTH + 4;
        const v = r.decode(a.slice(y, y + h));
        y = y + h;
        const _ = r.decode(a.slice(y, y + d));
        y = y + d;
        const w = r.decode(a.slice(y, y + m));
        y = y + m;
        const E = a.slice(y, a.byteLength),
            O = g === this.JSON_ENCODING ? JSON.parse(r.decode(E)) : E,
            k = {
                type: this.BROADCAST_EVENT,
                event: _,
                payload: O
            };
        return m > 0 && (k.meta = JSON.parse(w)), {
            join_ref: null,
            ref: null,
            topic: v,
            event: this.BROADCAST_EVENT,
            payload: k
        }
    }
    _isArrayBuffer(a) {
        var l;
        return a instanceof ArrayBuffer || ((l = a ? .constructor) === null || l === void 0 ? void 0 : l.name) === "ArrayBuffer"
    }
    _pick(a, l) {
        return !a || typeof a != "object" ? {} : Object.fromEntries(Object.entries(a).filter(([r]) => l.includes(r)))
    }
}
class Tm {
    constructor(a, l) {
        this.callback = a, this.timerCalc = l, this.timer = void 0, this.tries = 0, this.callback = a, this.timerCalc = l
    }
    reset() {
        this.tries = 0, clearTimeout(this.timer), this.timer = void 0
    }
    scheduleTimeout() {
        clearTimeout(this.timer), this.timer = setTimeout(() => {
            this.tries = this.tries + 1, this.callback()
        }, this.timerCalc(this.tries + 1))
    }
}
var Ee;
(function(s) {
    s.abstime = "abstime", s.bool = "bool", s.date = "date", s.daterange = "daterange", s.float4 = "float4", s.float8 = "float8", s.int2 = "int2", s.int4 = "int4", s.int4range = "int4range", s.int8 = "int8", s.int8range = "int8range", s.json = "json", s.jsonb = "jsonb", s.money = "money", s.numeric = "numeric", s.oid = "oid", s.reltime = "reltime", s.text = "text", s.time = "time", s.timestamp = "timestamp", s.timestamptz = "timestamptz", s.timetz = "timetz", s.tsrange = "tsrange", s.tstzrange = "tstzrange"
})(Ee || (Ee = {}));
const im = (s, a, l = {}) => {
        var r;
        const h = (r = l.skipTypes) !== null && r !== void 0 ? r : [];
        return a ? Object.keys(a).reduce((d, m) => (d[m] = Xv(m, s, a, h), d), {}) : {}
    },
    Xv = (s, a, l, r) => {
        const h = a.find(g => g.name === s),
            d = h ? .type,
            m = l[s];
        return d && !r.includes(d) ? Am(d, m) : Nu(m)
    },
    Am = (s, a) => {
        if (s.charAt(0) === "_") {
            const l = s.slice(1, s.length);
            return Iv(a, l)
        }
        switch (s) {
            case Ee.bool:
                return Qv(a);
            case Ee.float4:
            case Ee.float8:
            case Ee.int2:
            case Ee.int4:
            case Ee.int8:
            case Ee.numeric:
            case Ee.oid:
                return Jv(a);
            case Ee.json:
            case Ee.jsonb:
                return Zv(a);
            case Ee.timestamp:
                return Pv(a);
            case Ee.abstime:
            case Ee.date:
            case Ee.daterange:
            case Ee.int4range:
            case Ee.int8range:
            case Ee.money:
            case Ee.reltime:
            case Ee.text:
            case Ee.time:
            case Ee.timestamptz:
            case Ee.timetz:
            case Ee.tsrange:
            case Ee.tstzrange:
                return Nu(a);
            default:
                return Nu(a)
        }
    },
    Nu = s => s,
    Qv = s => {
        switch (s) {
            case "t":
                return !0;
            case "f":
                return !1;
            default:
                return s
        }
    },
    Jv = s => {
        if (typeof s == "string") {
            const a = parseFloat(s);
            if (!Number.isNaN(a)) return a
        }
        return s
    },
    Zv = s => {
        if (typeof s == "string") try {
            return JSON.parse(s)
        } catch {
            return s
        }
        return s
    },
    Iv = (s, a) => {
        if (typeof s != "string") return s;
        const l = s.length - 1,
            r = s[l];
        if (s[0] === "{" && r === "}") {
            let d;
            const m = s.slice(1, l);
            try {
                d = JSON.parse("[" + m + "]")
            } catch {
                d = m ? m.split(",") : []
            }
            return d.map(g => Am(a, g))
        }
        return s
    },
    Pv = s => typeof s == "string" ? s.replace(" ", "T") : s,
    Om = s => {
        const a = new URL(s);
        return a.protocol = a.protocol.replace(/^ws/i, "http"), a.pathname = a.pathname.replace(/\/+$/, "").replace(/\/socket\/websocket$/i, "").replace(/\/socket$/i, "").replace(/\/websocket$/i, ""), a.pathname === "" || a.pathname === "/" ? a.pathname = "/api/broadcast" : a.pathname = a.pathname + "/api/broadcast", a.href
    };
class bu {
    constructor(a, l, r = {}, h = Au) {
        this.channel = a, this.event = l, this.payload = r, this.timeout = h, this.sent = !1, this.timeoutTimer = void 0, this.ref = "", this.receivedResp = null, this.recHooks = [], this.refEvent = null
    }
    resend(a) {
        this.timeout = a, this._cancelRefEvent(), this.ref = "", this.refEvent = null, this.receivedResp = null, this.sent = !1, this.send()
    }
    send() {
        this._hasReceived("timeout") || (this.startTimeout(), this.sent = !0, this.channel.socket.push({
            topic: this.channel.topic,
            event: this.event,
            payload: this.payload,
            ref: this.ref,
            join_ref: this.channel._joinRef()
        }))
    }
    updatePayload(a) {
        this.payload = Object.assign(Object.assign({}, this.payload), a)
    }
    receive(a, l) {
        var r;
        return this._hasReceived(a) && l((r = this.receivedResp) === null || r === void 0 ? void 0 : r.response), this.recHooks.push({
            status: a,
            callback: l
        }), this
    }
    startTimeout() {
        if (this.timeoutTimer) return;
        this.ref = this.channel.socket._makeRef(), this.refEvent = this.channel._replyEventName(this.ref);
        const a = l => {
            this._cancelRefEvent(), this._cancelTimeout(), this.receivedResp = l, this._matchReceive(l)
        };
        this.channel._on(this.refEvent, {}, a), this.timeoutTimer = setTimeout(() => {
            this.trigger("timeout", {})
        }, this.timeout)
    }
    trigger(a, l) {
        this.refEvent && this.channel._trigger(this.refEvent, {
            status: a,
            response: l
        })
    }
    destroy() {
        this._cancelRefEvent(), this._cancelTimeout()
    }
    _cancelRefEvent() {
        this.refEvent && this.channel._off(this.refEvent, {})
    }
    _cancelTimeout() {
        clearTimeout(this.timeoutTimer), this.timeoutTimer = void 0
    }
    _matchReceive({
        status: a,
        response: l
    }) {
        this.recHooks.filter(r => r.status === a).forEach(r => r.callback(l))
    }
    _hasReceived(a) {
        return this.receivedResp && this.receivedResp.status === a
    }
}
var sm;
(function(s) {
    s.SYNC = "sync", s.JOIN = "join", s.LEAVE = "leave"
})(sm || (sm = {}));
class ls {
    constructor(a, l) {
        this.channel = a, this.state = {}, this.pendingDiffs = [], this.joinRef = null, this.enabled = !1, this.caller = {
            onJoin: () => {},
            onLeave: () => {},
            onSync: () => {}
        };
        const r = l ? .events || {
            state: "presence_state",
            diff: "presence_diff"
        };
        this.channel._on(r.state, {}, h => {
            const {
                onJoin: d,
                onLeave: m,
                onSync: g
            } = this.caller;
            this.joinRef = this.channel._joinRef(), this.state = ls.syncState(this.state, h, d, m), this.pendingDiffs.forEach(y => {
                this.state = ls.syncDiff(this.state, y, d, m)
            }), this.pendingDiffs = [], g()
        }), this.channel._on(r.diff, {}, h => {
            const {
                onJoin: d,
                onLeave: m,
                onSync: g
            } = this.caller;
            this.inPendingSyncState() ? this.pendingDiffs.push(h) : (this.state = ls.syncDiff(this.state, h, d, m), g())
        }), this.onJoin((h, d, m) => {
            this.channel._trigger("presence", {
                event: "join",
                key: h,
                currentPresences: d,
                newPresences: m
            })
        }), this.onLeave((h, d, m) => {
            this.channel._trigger("presence", {
                event: "leave",
                key: h,
                currentPresences: d,
                leftPresences: m
            })
        }), this.onSync(() => {
            this.channel._trigger("presence", {
                event: "sync"
            })
        })
    }
    static syncState(a, l, r, h) {
        const d = this.cloneDeep(a),
            m = this.transformState(l),
            g = {},
            y = {};
        return this.map(d, (v, _) => {
            m[v] || (y[v] = _)
        }), this.map(m, (v, _) => {
            const w = d[v];
            if (w) {
                const E = _.map(L => L.presence_ref),
                    O = w.map(L => L.presence_ref),
                    k = _.filter(L => O.indexOf(L.presence_ref) < 0),
                    B = w.filter(L => E.indexOf(L.presence_ref) < 0);
                k.length > 0 && (g[v] = k), B.length > 0 && (y[v] = B)
            } else g[v] = _
        }), this.syncDiff(d, {
            joins: g,
            leaves: y
        }, r, h)
    }
    static syncDiff(a, l, r, h) {
        const {
            joins: d,
            leaves: m
        } = {
            joins: this.transformState(l.joins),
            leaves: this.transformState(l.leaves)
        };
        return r || (r = () => {}), h || (h = () => {}), this.map(d, (g, y) => {
            var v;
            const _ = (v = a[g]) !== null && v !== void 0 ? v : [];
            if (a[g] = this.cloneDeep(y), _.length > 0) {
                const w = a[g].map(O => O.presence_ref),
                    E = _.filter(O => w.indexOf(O.presence_ref) < 0);
                a[g].unshift(...E)
            }
            r(g, _, y)
        }), this.map(m, (g, y) => {
            let v = a[g];
            if (!v) return;
            const _ = y.map(w => w.presence_ref);
            v = v.filter(w => _.indexOf(w.presence_ref) < 0), a[g] = v, h(g, v, y), v.length === 0 && delete a[g]
        }), a
    }
    static map(a, l) {
        return Object.getOwnPropertyNames(a).map(r => l(r, a[r]))
    }
    static transformState(a) {
        return a = this.cloneDeep(a), Object.getOwnPropertyNames(a).reduce((l, r) => {
            const h = a[r];
            return "metas" in h ? l[r] = h.metas.map(d => (d.presence_ref = d.phx_ref, delete d.phx_ref, delete d.phx_ref_prev, d)) : l[r] = h, l
        }, {})
    }
    static cloneDeep(a) {
        return JSON.parse(JSON.stringify(a))
    }
    onJoin(a) {
        this.caller.onJoin = a
    }
    onLeave(a) {
        this.caller.onLeave = a
    }
    onSync(a) {
        this.caller.onSync = a
    }
    inPendingSyncState() {
        return !this.joinRef || this.joinRef !== this.channel._joinRef()
    }
}
var lm;
(function(s) {
    s.ALL = "*", s.INSERT = "INSERT", s.UPDATE = "UPDATE", s.DELETE = "DELETE"
})(lm || (lm = {}));
var rs;
(function(s) {
    s.BROADCAST = "broadcast", s.PRESENCE = "presence", s.POSTGRES_CHANGES = "postgres_changes", s.SYSTEM = "system"
})(rs || (rs = {}));
var hn;
(function(s) {
    s.SUBSCRIBED = "SUBSCRIBED", s.TIMED_OUT = "TIMED_OUT", s.CLOSED = "CLOSED", s.CHANNEL_ERROR = "CHANNEL_ERROR"
})(hn || (hn = {}));
class li {
    constructor(a, l = {
        config: {}
    }, r) {
        var h, d;
        if (this.topic = a, this.params = l, this.socket = r, this.bindings = {}, this.state = $e.closed, this.joinedOnce = !1, this.pushBuffer = [], this.subTopic = a.replace(/^realtime:/i, ""), this.params.config = Object.assign({
                broadcast: {
                    ack: !1,
                    self: !1
                },
                presence: {
                    key: "",
                    enabled: !1
                },
                private: !1
            }, l.config), this.timeout = this.socket.timeout, this.joinPush = new bu(this, Lt.join, this.params, this.timeout), this.rejoinTimer = new Tm(() => this._rejoinUntilConnected(), this.socket.reconnectAfterMs), this.joinPush.receive("ok", () => {
                this.state = $e.joined, this.rejoinTimer.reset(), this.pushBuffer.forEach(m => m.send()), this.pushBuffer = []
            }), this._onClose(() => {
                this.rejoinTimer.reset(), this.socket.log("channel", `close ${this.topic} ${this._joinRef()}`), this.state = $e.closed, this.socket._remove(this)
            }), this._onError(m => {
                this._isLeaving() || this._isClosed() || (this.socket.log("channel", `error ${this.topic}`, m), this.state = $e.errored, this.rejoinTimer.scheduleTimeout())
            }), this.joinPush.receive("timeout", () => {
                this._isJoining() && (this.socket.log("channel", `timeout ${this.topic}`, this.joinPush.timeout), this.state = $e.errored, this.rejoinTimer.scheduleTimeout())
            }), this.joinPush.receive("error", m => {
                this._isLeaving() || this._isClosed() || (this.socket.log("channel", `error ${this.topic}`, m), this.state = $e.errored, this.rejoinTimer.scheduleTimeout())
            }), this._on(Lt.reply, {}, (m, g) => {
                this._trigger(this._replyEventName(g), m)
            }), this.presence = new ls(this), this.broadcastEndpointURL = Om(this.socket.endPoint), this.private = this.params.config.private || !1, !this.private && (!((d = (h = this.params.config) === null || h === void 0 ? void 0 : h.broadcast) === null || d === void 0) && d.replay)) throw `tried to use replay on public channel '${this.topic}'. It must be a private channel.`
    }
    subscribe(a, l = this.timeout) {
        var r, h, d;
        if (this.socket.isConnected() || this.socket.connect(), this.state == $e.closed) {
            const {
                config: {
                    broadcast: m,
                    presence: g,
                    private: y
                }
            } = this.params, v = (h = (r = this.bindings.postgres_changes) === null || r === void 0 ? void 0 : r.map(O => O.filter)) !== null && h !== void 0 ? h : [], _ = !!this.bindings[rs.PRESENCE] && this.bindings[rs.PRESENCE].length > 0 || ((d = this.params.config.presence) === null || d === void 0 ? void 0 : d.enabled) === !0, w = {}, E = {
                broadcast: m,
                presence: Object.assign(Object.assign({}, g), {
                    enabled: _
                }),
                postgres_changes: v,
                private: y
            };
            this.socket.accessTokenValue && (w.access_token = this.socket.accessTokenValue), this._onError(O => a ? .(hn.CHANNEL_ERROR, O)), this._onClose(() => a ? .(hn.CLOSED)), this.updateJoinPayload(Object.assign({
                config: E
            }, w)), this.joinedOnce = !0, this._rejoin(l), this.joinPush.receive("ok", async ({
                postgres_changes: O
            }) => {
                var k;
                if (this.socket._isManualToken() || this.socket.setAuth(), O === void 0) {
                    a ? .(hn.SUBSCRIBED);
                    return
                } else {
                    const B = this.bindings.postgres_changes,
                        L = (k = B ? .length) !== null && k !== void 0 ? k : 0,
                        H = [];
                    for (let $ = 0; $ < L; $++) {
                        const q = B[$],
                            {
                                filter: {
                                    event: I,
                                    schema: ye,
                                    table: ie,
                                    filter: J
                                }
                            } = q,
                            Ne = O && O[$];
                        if (Ne && Ne.event === I && li.isFilterValueEqual(Ne.schema, ye) && li.isFilterValueEqual(Ne.table, ie) && li.isFilterValueEqual(Ne.filter, J)) H.push(Object.assign(Object.assign({}, q), {
                            id: Ne.id
                        }));
                        else {
                            this.unsubscribe(), this.state = $e.errored, a ? .(hn.CHANNEL_ERROR, new Error("mismatch between server and client bindings for postgres changes"));
                            return
                        }
                    }
                    this.bindings.postgres_changes = H, a && a(hn.SUBSCRIBED);
                    return
                }
            }).receive("error", O => {
                this.state = $e.errored, a ? .(hn.CHANNEL_ERROR, new Error(JSON.stringify(Object.values(O).join(", ") || "error")))
            }).receive("timeout", () => {
                a ? .(hn.TIMED_OUT)
            })
        }
        return this
    }
    presenceState() {
        return this.presence.state
    }
    async track(a, l = {}) {
        return await this.send({
            type: "presence",
            event: "track",
            payload: a
        }, l.timeout || this.timeout)
    }
    async untrack(a = {}) {
        return await this.send({
            type: "presence",
            event: "untrack"
        }, a)
    }
    on(a, l, r) {
        return this.state === $e.joined && a === rs.PRESENCE && (this.socket.log("channel", `resubscribe to ${this.topic} due to change in presence callbacks on joined channel`), this.unsubscribe().then(async () => await this.subscribe())), this._on(a, l, r)
    }
    async httpSend(a, l, r = {}) {
        var h;
        if (l == null) return Promise.reject("Payload is required for httpSend()");
        const d = {
            apikey: this.socket.apiKey ? this.socket.apiKey : "",
            "Content-Type": "application/json"
        };
        this.socket.accessTokenValue && (d.Authorization = `Bearer ${this.socket.accessTokenValue}`);
        const m = {
                method: "POST",
                headers: d,
                body: JSON.stringify({
                    messages: [{
                        topic: this.subTopic,
                        event: a,
                        payload: l,
                        private: this.private
                    }]
                })
            },
            g = await this._fetchWithTimeout(this.broadcastEndpointURL, m, (h = r.timeout) !== null && h !== void 0 ? h : this.timeout);
        if (g.status === 202) return {
            success: !0
        };
        let y = g.statusText;
        try {
            const v = await g.json();
            y = v.error || v.message || y
        } catch {}
        return Promise.reject(new Error(y))
    }
    async send(a, l = {}) {
        var r, h;
        if (!this._canPush() && a.type === "broadcast") {
            console.warn("Realtime send() is automatically falling back to REST API. This behavior will be deprecated in the future. Please use httpSend() explicitly for REST delivery.");
            const {
                event: d,
                payload: m
            } = a, g = {
                apikey: this.socket.apiKey ? this.socket.apiKey : "",
                "Content-Type": "application/json"
            };
            this.socket.accessTokenValue && (g.Authorization = `Bearer ${this.socket.accessTokenValue}`);
            const y = {
                method: "POST",
                headers: g,
                body: JSON.stringify({
                    messages: [{
                        topic: this.subTopic,
                        event: d,
                        payload: m,
                        private: this.private
                    }]
                })
            };
            try {
                const v = await this._fetchWithTimeout(this.broadcastEndpointURL, y, (r = l.timeout) !== null && r !== void 0 ? r : this.timeout);
                return await ((h = v.body) === null || h === void 0 ? void 0 : h.cancel()), v.ok ? "ok" : "error"
            } catch (v) {
                return v.name === "AbortError" ? "timed out" : "error"
            }
        } else return new Promise(d => {
            var m, g, y;
            const v = this._push(a.type, a, l.timeout || this.timeout);
            a.type === "broadcast" && !(!((y = (g = (m = this.params) === null || m === void 0 ? void 0 : m.config) === null || g === void 0 ? void 0 : g.broadcast) === null || y === void 0) && y.ack) && d("ok"), v.receive("ok", () => d("ok")), v.receive("error", () => d("error")), v.receive("timeout", () => d("timed out"))
        })
    }
    updateJoinPayload(a) {
        this.joinPush.updatePayload(a)
    }
    unsubscribe(a = this.timeout) {
        this.state = $e.leaving;
        const l = () => {
            this.socket.log("channel", `leave ${this.topic}`), this._trigger(Lt.close, "leave", this._joinRef())
        };
        this.joinPush.destroy();
        let r = null;
        return new Promise(h => {
            r = new bu(this, Lt.leave, {}, a), r.receive("ok", () => {
                l(), h("ok")
            }).receive("timeout", () => {
                l(), h("timed out")
            }).receive("error", () => {
                h("error")
            }), r.send(), this._canPush() || r.trigger("ok", {})
        }).finally(() => {
            r ? .destroy()
        })
    }
    teardown() {
        this.pushBuffer.forEach(a => a.destroy()), this.pushBuffer = [], this.rejoinTimer.reset(), this.joinPush.destroy(), this.state = $e.closed, this.bindings = {}
    }
    async _fetchWithTimeout(a, l, r) {
        const h = new AbortController,
            d = setTimeout(() => h.abort(), r),
            m = await this.socket.fetch(a, Object.assign(Object.assign({}, l), {
                signal: h.signal
            }));
        return clearTimeout(d), m
    }
    _push(a, l, r = this.timeout) {
        if (!this.joinedOnce) throw `tried to push '${a}' to '${this.topic}' before joining. Use channel.subscribe() before pushing events`;
        let h = new bu(this, a, l, r);
        return this._canPush() ? h.send() : this._addToPushBuffer(h), h
    }
    _addToPushBuffer(a) {
        if (a.startTimeout(), this.pushBuffer.push(a), this.pushBuffer.length > Yv) {
            const l = this.pushBuffer.shift();
            l && (l.destroy(), this.socket.log("channel", `discarded push due to buffer overflow: ${l.event}`, l.payload))
        }
    }
    _onMessage(a, l, r) {
        return l
    }
    _isMember(a) {
        return this.topic === a
    }
    _joinRef() {
        return this.joinPush.ref
    }
    _trigger(a, l, r) {
        var h, d;
        const m = a.toLocaleLowerCase(),
            {
                close: g,
                error: y,
                leave: v,
                join: _
            } = Lt;
        if (r && [g, y, v, _].indexOf(m) >= 0 && r !== this._joinRef()) return;
        let E = this._onMessage(m, l, r);
        if (l && !E) throw "channel onMessage callbacks must return the payload, modified or unmodified";
        ["insert", "update", "delete"].includes(m) ? (h = this.bindings.postgres_changes) === null || h === void 0 || h.filter(O => {
            var k, B, L;
            return ((k = O.filter) === null || k === void 0 ? void 0 : k.event) === "*" || ((L = (B = O.filter) === null || B === void 0 ? void 0 : B.event) === null || L === void 0 ? void 0 : L.toLocaleLowerCase()) === m
        }).map(O => O.callback(E, r)) : (d = this.bindings[m]) === null || d === void 0 || d.filter(O => {
            var k, B, L, H, $, q;
            if (["broadcast", "presence", "postgres_changes"].includes(m))
                if ("id" in O) {
                    const I = O.id,
                        ye = (k = O.filter) === null || k === void 0 ? void 0 : k.event;
                    return I && ((B = l.ids) === null || B === void 0 ? void 0 : B.includes(I)) && (ye === "*" || ye ? .toLocaleLowerCase() === ((L = l.data) === null || L === void 0 ? void 0 : L.type.toLocaleLowerCase()))
                } else {
                    const I = ($ = (H = O ? .filter) === null || H === void 0 ? void 0 : H.event) === null || $ === void 0 ? void 0 : $.toLocaleLowerCase();
                    return I === "*" || I === ((q = l ? .event) === null || q === void 0 ? void 0 : q.toLocaleLowerCase())
                }
            else return O.type.toLocaleLowerCase() === m
        }).map(O => {
            if (typeof E == "object" && "ids" in E) {
                const k = E.data,
                    {
                        schema: B,
                        table: L,
                        commit_timestamp: H,
                        type: $,
                        errors: q
                    } = k;
                E = Object.assign(Object.assign({}, {
                    schema: B,
                    table: L,
                    commit_timestamp: H,
                    eventType: $,
                    new: {},
                    old: {},
                    errors: q
                }), this._getPayloadRecords(k))
            }
            O.callback(E, r)
        })
    }
    _isClosed() {
        return this.state === $e.closed
    }
    _isJoined() {
        return this.state === $e.joined
    }
    _isJoining() {
        return this.state === $e.joining
    }
    _isLeaving() {
        return this.state === $e.leaving
    }
    _replyEventName(a) {
        return `chan_reply_${a}`
    }
    _on(a, l, r) {
        const h = a.toLocaleLowerCase(),
            d = {
                type: h,
                filter: l,
                callback: r
            };
        return this.bindings[h] ? this.bindings[h].push(d) : this.bindings[h] = [d], this
    }
    _off(a, l) {
        const r = a.toLocaleLowerCase();
        return this.bindings[r] && (this.bindings[r] = this.bindings[r].filter(h => {
            var d;
            return !(((d = h.type) === null || d === void 0 ? void 0 : d.toLocaleLowerCase()) === r && li.isEqual(h.filter, l))
        })), this
    }
    static isEqual(a, l) {
        if (Object.keys(a).length !== Object.keys(l).length) return !1;
        for (const r in a)
            if (a[r] !== l[r]) return !1;
        return !0
    }
    static isFilterValueEqual(a, l) {
        return (a ? ? void 0) === (l ? ? void 0)
    }
    _rejoinUntilConnected() {
        this.rejoinTimer.scheduleTimeout(), this.socket.isConnected() && this._rejoin()
    }
    _onClose(a) {
        this._on(Lt.close, {}, a)
    }
    _onError(a) {
        this._on(Lt.error, {}, l => a(l))
    }
    _canPush() {
        return this.socket.isConnected() && this._isJoined()
    }
    _rejoin(a = this.timeout) {
        this._isLeaving() || (this.socket._leaveOpenTopic(this.topic), this.state = $e.joining, this.joinPush.resend(a))
    }
    _getPayloadRecords(a) {
        const l = {
            new: {},
            old: {}
        };
        return (a.type === "INSERT" || a.type === "UPDATE") && (l.new = im(a.columns, a.record)), (a.type === "UPDATE" || a.type === "DELETE") && (l.old = im(a.columns, a.old_record)), l
    }
}
const _u = () => {},
    zl = {
        HEARTBEAT_INTERVAL: 25e3,
        RECONNECT_DELAY: 10,
        HEARTBEAT_TIMEOUT_FALLBACK: 100
    },
    Wv = [1e3, 2e3, 5e3, 1e4],
    Fv = 1e4,
    ey = `
  addEventListener("message", (e) => {
    if (e.data.event === "start") {
      setInterval(() => postMessage({ event: "keepAlive" }), e.data.interval);
    }
  });`;
class ty {
    constructor(a, l) {
        var r;
        if (this.accessTokenValue = null, this.apiKey = null, this._manuallySetToken = !1, this.channels = new Array, this.endPoint = "", this.httpEndpoint = "", this.headers = {}, this.params = {}, this.timeout = Au, this.transport = null, this.heartbeatIntervalMs = zl.HEARTBEAT_INTERVAL, this.heartbeatTimer = void 0, this.pendingHeartbeatRef = null, this.heartbeatCallback = _u, this.ref = 0, this.reconnectTimer = null, this.vsn = am, this.logger = _u, this.conn = null, this.sendBuffer = [], this.serializer = new Vv, this.stateChangeCallbacks = {
                open: [],
                close: [],
                error: [],
                message: []
            }, this.accessToken = null, this._connectionState = "disconnected", this._wasManualDisconnect = !1, this._authPromise = null, this._heartbeatSentAt = null, this._resolveFetch = h => h ? (...d) => h(...d) : (...d) => fetch(...d), !(!((r = l ? .params) === null || r === void 0) && r.apikey)) throw new Error("API key is required to connect to Realtime");
        this.apiKey = l.params.apikey, this.endPoint = `${a}/${Ou.websocket}`, this.httpEndpoint = Om(a), this._initializeOptions(l), this._setupReconnectionTimer(), this.fetch = this._resolveFetch(l ? .fetch)
    }
    connect() {
        if (!(this.isConnecting() || this.isDisconnecting() || this.conn !== null && this.isConnected())) {
            if (this._setConnectionState("connecting"), this.accessToken && !this._authPromise && this._setAuthSafely("connect"), this.transport) this.conn = new this.transport(this.endpointURL());
            else try {
                this.conn = Lv.createWebSocket(this.endpointURL())
            } catch (a) {
                this._setConnectionState("disconnected");
                const l = a.message;
                throw l.includes("Node.js") ? new Error(`${l}

To use Realtime in Node.js, you need to provide a WebSocket implementation:

Option 1: Use Node.js 22+ which has native WebSocket support
Option 2: Install and provide the "ws" package:

  npm install ws

  import ws from "ws"
  const client = new RealtimeClient(url, {
    ...options,
    transport: ws
  })`) : new Error(`WebSocket not available: ${l}`)
            }
            this._setupConnectionHandlers()
        }
    }
    endpointURL() {
        return this._appendParams(this.endPoint, Object.assign({}, this.params, {
            vsn: this.vsn
        }))
    }
    disconnect(a, l) {
        if (!this.isDisconnecting())
            if (this._setConnectionState("disconnecting", !0), this.conn) {
                const r = setTimeout(() => {
                    this._setConnectionState("disconnected")
                }, 100);
                this.conn.onclose = () => {
                    clearTimeout(r), this._setConnectionState("disconnected")
                }, typeof this.conn.close == "function" && (a ? this.conn.close(a, l ? ? "") : this.conn.close()), this._teardownConnection()
            } else this._setConnectionState("disconnected")
    }
    getChannels() {
        return this.channels
    }
    async removeChannel(a) {
        const l = await a.unsubscribe();
        return l === "ok" && this._remove(a), this.channels.length === 0 && this.disconnect(), l
    }
    async removeAllChannels() {
        const a = await Promise.all(this.channels.map(l => l.unsubscribe()));
        return this.channels = [], this.disconnect(), a
    }
    log(a, l, r) {
        this.logger(a, l, r)
    }
    connectionState() {
        switch (this.conn && this.conn.readyState) {
            case qn.connecting:
                return ua.Connecting;
            case qn.open:
                return ua.Open;
            case qn.closing:
                return ua.Closing;
            default:
                return ua.Closed
        }
    }
    isConnected() {
        return this.connectionState() === ua.Open
    }
    isConnecting() {
        return this._connectionState === "connecting"
    }
    isDisconnecting() {
        return this._connectionState === "disconnecting"
    }
    channel(a, l = {
        config: {}
    }) {
        const r = `realtime:${a}`,
            h = this.getChannels().find(d => d.topic === r);
        if (h) return h; {
            const d = new li(`realtime:${a}`, l, this);
            return this.channels.push(d), d
        }
    }
    push(a) {
        const {
            topic: l,
            event: r,
            payload: h,
            ref: d
        } = a, m = () => {
            this.encode(a, g => {
                var y;
                (y = this.conn) === null || y === void 0 || y.send(g)
            })
        };
        this.log("push", `${l} ${r} (${d})`, h), this.isConnected() ? m() : this.sendBuffer.push(m)
    }
    async setAuth(a = null) {
        this._authPromise = this._performAuth(a);
        try {
            await this._authPromise
        } finally {
            this._authPromise = null
        }
    }
    _isManualToken() {
        return this._manuallySetToken
    }
    async sendHeartbeat() {
        var a;
        if (!this.isConnected()) {
            try {
                this.heartbeatCallback("disconnected")
            } catch (l) {
                this.log("error", "error in heartbeat callback", l)
            }
            return
        }
        if (this.pendingHeartbeatRef) {
            this.pendingHeartbeatRef = null, this._heartbeatSentAt = null, this.log("transport", "heartbeat timeout. Attempting to re-establish connection");
            try {
                this.heartbeatCallback("timeout")
            } catch (l) {
                this.log("error", "error in heartbeat callback", l)
            }
            this._wasManualDisconnect = !1, (a = this.conn) === null || a === void 0 || a.close($v, "heartbeat timeout"), setTimeout(() => {
                var l;
                this.isConnected() || (l = this.reconnectTimer) === null || l === void 0 || l.scheduleTimeout()
            }, zl.HEARTBEAT_TIMEOUT_FALLBACK);
            return
        }
        this._heartbeatSentAt = Date.now(), this.pendingHeartbeatRef = this._makeRef(), this.push({
            topic: "phoenix",
            event: "heartbeat",
            payload: {},
            ref: this.pendingHeartbeatRef
        });
        try {
            this.heartbeatCallback("sent")
        } catch (l) {
            this.log("error", "error in heartbeat callback", l)
        }
        this._setAuthSafely("heartbeat")
    }
    onHeartbeat(a) {
        this.heartbeatCallback = a
    }
    flushSendBuffer() {
        this.isConnected() && this.sendBuffer.length > 0 && (this.sendBuffer.forEach(a => a()), this.sendBuffer = [])
    }
    _makeRef() {
        let a = this.ref + 1;
        return a === this.ref ? this.ref = 0 : this.ref = a, this.ref.toString()
    }
    _leaveOpenTopic(a) {
        let l = this.channels.find(r => r.topic === a && (r._isJoined() || r._isJoining()));
        l && (this.log("transport", `leaving duplicate topic "${a}"`), l.unsubscribe())
    }
    _remove(a) {
        this.channels = this.channels.filter(l => l.topic !== a.topic)
    }
    _onConnMessage(a) {
        this.decode(a.data, l => {
            if (l.topic === "phoenix" && l.event === "phx_reply" && l.ref && l.ref === this.pendingHeartbeatRef) {
                const v = this._heartbeatSentAt ? Date.now() - this._heartbeatSentAt : void 0;
                try {
                    this.heartbeatCallback(l.payload.status === "ok" ? "ok" : "error", v)
                } catch (_) {
                    this.log("error", "error in heartbeat callback", _)
                }
                this._heartbeatSentAt = null, this.pendingHeartbeatRef = null
            }
            const {
                topic: r,
                event: h,
                payload: d,
                ref: m
            } = l, g = m ? `(${m})` : "", y = d.status || "";
            this.log("receive", `${y} ${r} ${h} ${g}`.trim(), d), this.channels.filter(v => v._isMember(r)).forEach(v => v._trigger(h, d, m)), this._triggerStateCallbacks("message", l)
        })
    }
    _clearTimer(a) {
        var l;
        a === "heartbeat" && this.heartbeatTimer ? (clearInterval(this.heartbeatTimer), this.heartbeatTimer = void 0) : a === "reconnect" && ((l = this.reconnectTimer) === null || l === void 0 || l.reset())
    }
    _clearAllTimers() {
        this._clearTimer("heartbeat"), this._clearTimer("reconnect")
    }
    _setupConnectionHandlers() {
        this.conn && ("binaryType" in this.conn && (this.conn.binaryType = "arraybuffer"), this.conn.onopen = () => this._onConnOpen(), this.conn.onerror = a => this._onConnError(a), this.conn.onmessage = a => this._onConnMessage(a), this.conn.onclose = a => this._onConnClose(a), this.conn.readyState === qn.open && this._onConnOpen())
    }
    _teardownConnection() {
        if (this.conn) {
            if (this.conn.readyState === qn.open || this.conn.readyState === qn.connecting) try {
                this.conn.close()
            } catch (a) {
                this.log("error", "Error closing connection", a)
            }
            this.conn.onopen = null, this.conn.onerror = null, this.conn.onmessage = null, this.conn.onclose = null, this.conn = null
        }
        this._clearAllTimers(), this._terminateWorker(), this.channels.forEach(a => a.teardown())
    }
    _onConnOpen() {
        this._setConnectionState("connected"), this.log("transport", `connected to ${this.endpointURL()}`), (this._authPromise || (this.accessToken && !this.accessTokenValue ? this.setAuth() : Promise.resolve())).then(() => {
            this.flushSendBuffer()
        }).catch(l => {
            this.log("error", "error waiting for auth on connect", l), this.flushSendBuffer()
        }), this._clearTimer("reconnect"), this.worker ? this.workerRef || this._startWorkerHeartbeat() : this._startHeartbeat(), this._triggerStateCallbacks("open")
    }
    _startHeartbeat() {
        this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.heartbeatTimer = setInterval(() => this.sendHeartbeat(), this.heartbeatIntervalMs)
    }
    _startWorkerHeartbeat() {
        this.workerUrl ? this.log("worker", `starting worker for from ${this.workerUrl}`) : this.log("worker", "starting default worker");
        const a = this._workerObjectUrl(this.workerUrl);
        this.workerRef = new Worker(a), this.workerRef.onerror = l => {
            this.log("worker", "worker error", l.message), this._terminateWorker()
        }, this.workerRef.onmessage = l => {
            l.data.event === "keepAlive" && this.sendHeartbeat()
        }, this.workerRef.postMessage({
            event: "start",
            interval: this.heartbeatIntervalMs
        })
    }
    _terminateWorker() {
        this.workerRef && (this.log("worker", "terminating worker"), this.workerRef.terminate(), this.workerRef = void 0)
    }
    _onConnClose(a) {
        var l;
        this._setConnectionState("disconnected"), this.log("transport", "close", a), this._triggerChanError(), this._clearTimer("heartbeat"), this._wasManualDisconnect || (l = this.reconnectTimer) === null || l === void 0 || l.scheduleTimeout(), this._triggerStateCallbacks("close", a)
    }
    _onConnError(a) {
        this._setConnectionState("disconnected"), this.log("transport", `${a}`), this._triggerChanError(), this._triggerStateCallbacks("error", a);
        try {
            this.heartbeatCallback("error")
        } catch (l) {
            this.log("error", "error in heartbeat callback", l)
        }
    }
    _triggerChanError() {
        this.channels.forEach(a => a._trigger(Lt.error))
    }
    _appendParams(a, l) {
        if (Object.keys(l).length === 0) return a;
        const r = a.match(/\?/) ? "&" : "?",
            h = new URLSearchParams(l);
        return `${a}${r}${h}`
    }
    _workerObjectUrl(a) {
        let l;
        if (a) l = a;
        else {
            const r = new Blob([ey], {
                type: "application/javascript"
            });
            l = URL.createObjectURL(r)
        }
        return l
    }
    _setConnectionState(a, l = !1) {
        this._connectionState = a, a === "connecting" ? this._wasManualDisconnect = !1 : a === "disconnecting" && (this._wasManualDisconnect = l)
    }
    async _performAuth(a = null) {
        let l, r = !1;
        if (a) l = a, r = !0;
        else if (this.accessToken) try {
            l = await this.accessToken()
        } catch (h) {
            this.log("error", "Error fetching access token from callback", h), l = this.accessTokenValue
        } else l = this.accessTokenValue;
        r ? this._manuallySetToken = !0 : this.accessToken && (this._manuallySetToken = !1), this.accessTokenValue != l && (this.accessTokenValue = l, this.channels.forEach(h => {
            const d = {
                access_token: l,
                version: Gv
            };
            l && h.updateJoinPayload(d), h.joinedOnce && h._isJoined() && h._push(Lt.access_token, {
                access_token: l
            })
        }))
    }
    async _waitForAuthIfNeeded() {
        this._authPromise && await this._authPromise
    }
    _setAuthSafely(a = "general") {
        this._isManualToken() || this.setAuth().catch(l => {
            this.log("error", `Error setting auth in ${a}`, l)
        })
    }
    _triggerStateCallbacks(a, l) {
        try {
            this.stateChangeCallbacks[a].forEach(r => {
                try {
                    r(l)
                } catch (h) {
                    this.log("error", `error in ${a} callback`, h)
                }
            })
        } catch (r) {
            this.log("error", `error triggering ${a} callbacks`, r)
        }
    }
    _setupReconnectionTimer() {
        this.reconnectTimer = new Tm(async () => {
            setTimeout(async () => {
                await this._waitForAuthIfNeeded(), this.isConnected() || this.connect()
            }, zl.RECONNECT_DELAY)
        }, this.reconnectAfterMs)
    }
    _initializeOptions(a) {
        var l, r, h, d, m, g, y, v, _, w, E, O;
        switch (this.transport = (l = a ? .transport) !== null && l !== void 0 ? l : null, this.timeout = (r = a ? .timeout) !== null && r !== void 0 ? r : Au, this.heartbeatIntervalMs = (h = a ? .heartbeatIntervalMs) !== null && h !== void 0 ? h : zl.HEARTBEAT_INTERVAL, this.worker = (d = a ? .worker) !== null && d !== void 0 ? d : !1, this.accessToken = (m = a ? .accessToken) !== null && m !== void 0 ? m : null, this.heartbeatCallback = (g = a ? .heartbeatCallback) !== null && g !== void 0 ? g : _u, this.vsn = (y = a ? .vsn) !== null && y !== void 0 ? y : am, a ? .params && (this.params = a.params), a ? .logger && (this.logger = a.logger), (a ? .logLevel || a ? .log_level) && (this.logLevel = a.logLevel || a.log_level, this.params = Object.assign(Object.assign({}, this.params), {
            log_level: this.logLevel
        })), this.reconnectAfterMs = (v = a ? .reconnectAfterMs) !== null && v !== void 0 ? v : (k => Wv[k - 1] || Fv), this.vsn) {
            case Kv:
                this.encode = (_ = a ? .encode) !== null && _ !== void 0 ? _ : ((k, B) => B(JSON.stringify(k))), this.decode = (w = a ? .decode) !== null && w !== void 0 ? w : ((k, B) => B(JSON.parse(k)));
                break;
            case Em:
                this.encode = (E = a ? .encode) !== null && E !== void 0 ? E : this.serializer.encode.bind(this.serializer), this.decode = (O = a ? .decode) !== null && O !== void 0 ? O : this.serializer.decode.bind(this.serializer);
                break;
            default:
                throw new Error(`Unsupported serializer version: ${this.vsn}`)
        }
        if (this.worker) {
            if (typeof window < "u" && !window.Worker) throw new Error("Web Worker is not supported");
            this.workerUrl = a ? .workerUrl
        }
    }
}
var us = class extends Error {
    constructor(s, a) {
        super(s), this.name = "IcebergError", this.status = a.status, this.icebergType = a.icebergType, this.icebergCode = a.icebergCode, this.details = a.details, this.isCommitStateUnknown = a.icebergType === "CommitStateUnknownException" || [500, 502, 504].includes(a.status) && a.icebergType ? .includes("CommitState") === !0
    }
    isNotFound() {
        return this.status === 404
    }
    isConflict() {
        return this.status === 409
    }
    isAuthenticationTimeout() {
        return this.status === 419
    }
};

function ny(s, a, l) {
    const r = new URL(a, s);
    if (l)
        for (const [h, d] of Object.entries(l)) d !== void 0 && r.searchParams.set(h, d);
    return r.toString()
}
async function ay(s) {
    return !s || s.type === "none" ? {} : s.type === "bearer" ? {
        Authorization: `Bearer ${s.token}`
    } : s.type === "header" ? {
        [s.name]: s.value
    } : s.type === "custom" ? await s.getHeaders() : {}
}

function iy(s) {
    const a = s.fetchImpl ? ? globalThis.fetch;
    return {
        async request({
            method: l,
            path: r,
            query: h,
            body: d,
            headers: m
        }) {
            const g = ny(s.baseUrl, r, h),
                y = await ay(s.auth),
                v = await a(g, {
                    method: l,
                    headers: { ...d ? {
                            "Content-Type": "application/json"
                        } : {},
                        ...y,
                        ...m
                    },
                    body: d ? JSON.stringify(d) : void 0
                }),
                _ = await v.text(),
                w = (v.headers.get("content-type") || "").includes("application/json"),
                E = w && _ ? JSON.parse(_) : _;
            if (!v.ok) {
                const O = w ? E : void 0,
                    k = O ? .error;
                throw new us(k ? .message ? ? `Request failed with status ${v.status}`, {
                    status: v.status,
                    icebergType: k ? .type,
                    icebergCode: k ? .code,
                    details: O
                })
            }
            return {
                status: v.status,
                headers: v.headers,
                data: E
            }
        }
    }
}

function Ml(s) {
    return s.join("")
}
var sy = class {
    constructor(s, a = "") {
        this.client = s, this.prefix = a
    }
    async listNamespaces(s) {
        const a = s ? {
            parent: Ml(s.namespace)
        } : void 0;
        return (await this.client.request({
            method: "GET",
            path: `${this.prefix}/namespaces`,
            query: a
        })).data.namespaces.map(r => ({
            namespace: r
        }))
    }
    async createNamespace(s, a) {
        const l = {
            namespace: s.namespace,
            properties: a ? .properties
        };
        return (await this.client.request({
            method: "POST",
            path: `${this.prefix}/namespaces`,
            body: l
        })).data
    }
    async dropNamespace(s) {
        await this.client.request({
            method: "DELETE",
            path: `${this.prefix}/namespaces/${Ml(s.namespace)}`
        })
    }
    async loadNamespaceMetadata(s) {
        return {
            properties: (await this.client.request({
                method: "GET",
                path: `${this.prefix}/namespaces/${Ml(s.namespace)}`
            })).data.properties
        }
    }
    async namespaceExists(s) {
        try {
            return await this.client.request({
                method: "HEAD",
                path: `${this.prefix}/namespaces/${Ml(s.namespace)}`
            }), !0
        } catch (a) {
            if (a instanceof us && a.status === 404) return !1;
            throw a
        }
    }
    async createNamespaceIfNotExists(s, a) {
        try {
            return await this.createNamespace(s, a)
        } catch (l) {
            if (l instanceof us && l.status === 409) return;
            throw l
        }
    }
};

function Pa(s) {
    return s.join("")
}
var ly = class {
        constructor(s, a = "", l) {
            this.client = s, this.prefix = a, this.accessDelegation = l
        }
        async listTables(s) {
            return (await this.client.request({
                method: "GET",
                path: `${this.prefix}/namespaces/${Pa(s.namespace)}/tables`
            })).data.identifiers
        }
        async createTable(s, a) {
            const l = {};
            return this.accessDelegation && (l["X-Iceberg-Access-Delegation"] = this.accessDelegation), (await this.client.request({
                method: "POST",
                path: `${this.prefix}/namespaces/${Pa(s.namespace)}/tables`,
                body: a,
                headers: l
            })).data.metadata
        }
        async updateTable(s, a) {
            const l = await this.client.request({
                method: "POST",
                path: `${this.prefix}/namespaces/${Pa(s.namespace)}/tables/${s.name}`,
                body: a
            });
            return {
                "metadata-location": l.data["metadata-location"],
                metadata: l.data.metadata
            }
        }
        async dropTable(s, a) {
            await this.client.request({
                method: "DELETE",
                path: `${this.prefix}/namespaces/${Pa(s.namespace)}/tables/${s.name}`,
                query: {
                    purgeRequested: String(a ? .purge ? ? !1)
                }
            })
        }
        async loadTable(s) {
            const a = {};
            return this.accessDelegation && (a["X-Iceberg-Access-Delegation"] = this.accessDelegation), (await this.client.request({
                method: "GET",
                path: `${this.prefix}/namespaces/${Pa(s.namespace)}/tables/${s.name}`,
                headers: a
            })).data.metadata
        }
        async tableExists(s) {
            const a = {};
            this.accessDelegation && (a["X-Iceberg-Access-Delegation"] = this.accessDelegation);
            try {
                return await this.client.request({
                    method: "HEAD",
                    path: `${this.prefix}/namespaces/${Pa(s.namespace)}/tables/${s.name}`,
                    headers: a
                }), !0
            } catch (l) {
                if (l instanceof us && l.status === 404) return !1;
                throw l
            }
        }
        async createTableIfNotExists(s, a) {
            try {
                return await this.createTable(s, a)
            } catch (l) {
                if (l instanceof us && l.status === 409) return await this.loadTable({
                    namespace: s.namespace,
                    name: a.name
                });
                throw l
            }
        }
    },
    ry = class {
        constructor(s) {
            let a = "v1";
            s.catalogName && (a += `/${s.catalogName}`);
            const l = s.baseUrl.endsWith("/") ? s.baseUrl : `${s.baseUrl}/`;
            this.client = iy({
                baseUrl: l,
                auth: s.auth,
                fetchImpl: s.fetch
            }), this.accessDelegation = s.accessDelegation ? .join(","), this.namespaceOps = new sy(this.client, a), this.tableOps = new ly(this.client, a, this.accessDelegation)
        }
        async listNamespaces(s) {
            return this.namespaceOps.listNamespaces(s)
        }
        async createNamespace(s, a) {
            return this.namespaceOps.createNamespace(s, a)
        }
        async dropNamespace(s) {
            await this.namespaceOps.dropNamespace(s)
        }
        async loadNamespaceMetadata(s) {
            return this.namespaceOps.loadNamespaceMetadata(s)
        }
        async listTables(s) {
            return this.tableOps.listTables(s)
        }
        async createTable(s, a) {
            return this.tableOps.createTable(s, a)
        }
        async updateTable(s, a) {
            return this.tableOps.updateTable(s, a)
        }
        async dropTable(s, a) {
            await this.tableOps.dropTable(s, a)
        }
        async loadTable(s) {
            return this.tableOps.loadTable(s)
        }
        async namespaceExists(s) {
            return this.namespaceOps.namespaceExists(s)
        }
        async tableExists(s) {
            return this.tableOps.tableExists(s)
        }
        async createNamespaceIfNotExists(s, a) {
            return this.namespaceOps.createNamespaceIfNotExists(s, a)
        }
        async createTableIfNotExists(s, a) {
            return this.tableOps.createTableIfNotExists(s, a)
        }
    },
    Vl = class extends Error {
        constructor(s, a = "storage", l, r) {
            super(s), this.__isStorageError = !0, this.namespace = a, this.name = a === "vectors" ? "StorageVectorsError" : "StorageError", this.status = l, this.statusCode = r
        }
    };

function Xl(s) {
    return typeof s == "object" && s !== null && "__isStorageError" in s
}
var Bl = class extends Vl {
        constructor(s, a, l, r = "storage") {
            super(s, r, a, l), this.name = r === "vectors" ? "StorageVectorsApiError" : "StorageApiError", this.status = a, this.statusCode = l
        }
        toJSON() {
            return {
                name: this.name,
                message: this.message,
                status: this.status,
                statusCode: this.statusCode
            }
        }
    },
    Nm = class extends Vl {
        constructor(s, a, l = "storage") {
            super(s, l), this.name = l === "vectors" ? "StorageVectorsUnknownError" : "StorageUnknownError", this.originalError = a
        }
    };
const oy = s => s ? (...a) => s(...a) : (...a) => fetch(...a),
    uy = s => {
        if (typeof s != "object" || s === null) return !1;
        const a = Object.getPrototypeOf(s);
        return (a === null || a === Object.prototype || Object.getPrototypeOf(a) === null) && !(Symbol.toStringTag in s) && !(Symbol.iterator in s)
    },
    Ru = s => {
        if (Array.isArray(s)) return s.map(l => Ru(l));
        if (typeof s == "function" || s !== Object(s)) return s;
        const a = {};
        return Object.entries(s).forEach(([l, r]) => {
            const h = l.replace(/([-_][a-z])/gi, d => d.toUpperCase().replace(/[-_]/g, ""));
            a[h] = Ru(r)
        }), a
    },
    cy = s => !s || typeof s != "string" || s.length === 0 || s.length > 100 || s.trim() !== s || s.includes("/") || s.includes("\\") ? !1 : /^[\w!.\*'() &$@=;:+,?-]+$/.test(s);

function cs(s) {
    "@babel/helpers - typeof";
    return cs = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(a) {
        return typeof a
    } : function(a) {
        return a && typeof Symbol == "function" && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
    }, cs(s)
}

function hy(s, a) {
    if (cs(s) != "object" || !s) return s;
    var l = s[Symbol.toPrimitive];
    if (l !== void 0) {
        var r = l.call(s, a);
        if (cs(r) != "object") return r;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (a === "string" ? String : Number)(s)
}

function dy(s) {
    var a = hy(s, "string");
    return cs(a) == "symbol" ? a : a + ""
}

function fy(s, a, l) {
    return (a = dy(a)) in s ? Object.defineProperty(s, a, {
        value: l,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : s[a] = l, s
}

function rm(s, a) {
    var l = Object.keys(s);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(s);
        a && (r = r.filter(function(h) {
            return Object.getOwnPropertyDescriptor(s, h).enumerable
        })), l.push.apply(l, r)
    }
    return l
}

function F(s) {
    for (var a = 1; a < arguments.length; a++) {
        var l = arguments[a] != null ? arguments[a] : {};
        a % 2 ? rm(Object(l), !0).forEach(function(r) {
            fy(s, r, l[r])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(s, Object.getOwnPropertyDescriptors(l)) : rm(Object(l)).forEach(function(r) {
            Object.defineProperty(s, r, Object.getOwnPropertyDescriptor(l, r))
        })
    }
    return s
}
const om = s => {
        var a;
        return s.msg || s.message || s.error_description || (typeof s.error == "string" ? s.error : (a = s.error) === null || a === void 0 ? void 0 : a.message) || JSON.stringify(s)
    },
    my = async (s, a, l, r) => {
        if (s && typeof s == "object" && "status" in s && "ok" in s && typeof s.status == "number" && !l ? .noResolveJson) {
            const h = s,
                d = h.status || 500;
            if (typeof h.json == "function") h.json().then(m => {
                const g = m ? .statusCode || m ? .code || d + "";
                a(new Bl(om(m), d, g, r))
            }).catch(() => {
                if (r === "vectors") {
                    const m = d + "";
                    a(new Bl(h.statusText || `HTTP ${d} error`, d, m, r))
                } else {
                    const m = d + "";
                    a(new Bl(h.statusText || `HTTP ${d} error`, d, m, r))
                }
            });
            else {
                const m = d + "";
                a(new Bl(h.statusText || `HTTP ${d} error`, d, m, r))
            }
        } else a(new Nm(om(s), s, r))
    },
    gy = (s, a, l, r) => {
        const h = {
            method: s,
            headers: a ? .headers || {}
        };
        return s === "GET" || s === "HEAD" || !r ? F(F({}, h), l) : (uy(r) ? (h.headers = F({
            "Content-Type": "application/json"
        }, a ? .headers), h.body = JSON.stringify(r)) : h.body = r, a ? .duplex && (h.duplex = a.duplex), F(F({}, h), l))
    };
async function is(s, a, l, r, h, d, m) {
    return new Promise((g, y) => {
        s(l, gy(a, r, h, d)).then(v => {
            if (!v.ok) throw v;
            if (r ? .noResolveJson) return v;
            if (m === "vectors") {
                const _ = v.headers.get("content-type");
                if (v.headers.get("content-length") === "0" || v.status === 204) return {};
                if (!_ || !_.includes("application/json")) return {}
            }
            return v.json()
        }).then(v => g(v)).catch(v => my(v, y, r, m))
    })
}

function Rm(s = "storage") {
    return {
        get: async (a, l, r, h) => is(a, "GET", l, r, h, void 0, s),
        post: async (a, l, r, h, d) => is(a, "POST", l, h, d, r, s),
        put: async (a, l, r, h, d) => is(a, "PUT", l, h, d, r, s),
        head: async (a, l, r, h) => is(a, "HEAD", l, F(F({}, r), {}, {
            noResolveJson: !0
        }), h, void 0, s),
        remove: async (a, l, r, h, d) => is(a, "DELETE", l, h, d, r, s)
    }
}
const py = Rm("storage"),
    {
        get: hs,
        post: qt,
        put: Cu,
        head: vy,
        remove: qu
    } = py,
    St = Rm("vectors");
var oi = class {
        constructor(s, a = {}, l, r = "storage") {
            this.shouldThrowOnError = !1, this.url = s, this.headers = a, this.fetch = oy(l), this.namespace = r
        }
        throwOnError() {
            return this.shouldThrowOnError = !0, this
        }
        async handleOperation(s) {
            var a = this;
            try {
                return {
                    data: await s(),
                    error: null
                }
            } catch (l) {
                if (a.shouldThrowOnError) throw l;
                if (Xl(l)) return {
                    data: null,
                    error: l
                };
                throw l
            }
        }
    },
    yy = class {
        constructor(s, a) {
            this.downloadFn = s, this.shouldThrowOnError = a
        }
        then(s, a) {
            return this.execute().then(s, a)
        }
        async execute() {
            var s = this;
            try {
                return {
                    data: (await s.downloadFn()).body,
                    error: null
                }
            } catch (a) {
                if (s.shouldThrowOnError) throw a;
                if (Xl(a)) return {
                    data: null,
                    error: a
                };
                throw a
            }
        }
    };
let Cm;
Cm = Symbol.toStringTag;
var by = class {
    constructor(s, a) {
        this.downloadFn = s, this.shouldThrowOnError = a, this[Cm] = "BlobDownloadBuilder", this.promise = null
    }
    asStream() {
        return new yy(this.downloadFn, this.shouldThrowOnError)
    }
    then(s, a) {
        return this.getPromise().then(s, a)
    } catch (s) {
        return this.getPromise().catch(s)
    } finally(s) {
        return this.getPromise().finally(s)
    }
    getPromise() {
        return this.promise || (this.promise = this.execute()), this.promise
    }
    async execute() {
        var s = this;
        try {
            return {
                data: await (await s.downloadFn()).blob(),
                error: null
            }
        } catch (a) {
            if (s.shouldThrowOnError) throw a;
            if (Xl(a)) return {
                data: null,
                error: a
            };
            throw a
        }
    }
};
const _y = {
        limit: 100,
        offset: 0,
        sortBy: {
            column: "name",
            order: "asc"
        }
    },
    um = {
        cacheControl: "3600",
        contentType: "text/plain;charset=UTF-8",
        upsert: !1
    };
var jy = class extends oi {
    constructor(s, a = {}, l, r) {
        super(s, a, r, "storage"), this.bucketId = l
    }
    async uploadOrUpdate(s, a, l, r) {
        var h = this;
        return h.handleOperation(async () => {
            let d;
            const m = F(F({}, um), r);
            let g = F(F({}, h.headers), s === "POST" && {
                "x-upsert": String(m.upsert)
            });
            const y = m.metadata;
            typeof Blob < "u" && l instanceof Blob ? (d = new FormData, d.append("cacheControl", m.cacheControl), y && d.append("metadata", h.encodeMetadata(y)), d.append("", l)) : typeof FormData < "u" && l instanceof FormData ? (d = l, d.has("cacheControl") || d.append("cacheControl", m.cacheControl), y && !d.has("metadata") && d.append("metadata", h.encodeMetadata(y))) : (d = l, g["cache-control"] = `max-age=${m.cacheControl}`, g["content-type"] = m.contentType, y && (g["x-metadata"] = h.toBase64(h.encodeMetadata(y))), (typeof ReadableStream < "u" && d instanceof ReadableStream || d && typeof d == "object" && "pipe" in d && typeof d.pipe == "function") && !m.duplex && (m.duplex = "half")), r ? .headers && (g = F(F({}, g), r.headers));
            const v = h._removeEmptyFolders(a),
                _ = h._getFinalPath(v),
                w = await (s == "PUT" ? Cu : qt)(h.fetch, `${h.url}/object/${_}`, d, F({
                    headers: g
                }, m ? .duplex ? {
                    duplex: m.duplex
                } : {}));
            return {
                path: v,
                id: w.Id,
                fullPath: w.Key
            }
        })
    }
    async upload(s, a, l) {
        return this.uploadOrUpdate("POST", s, a, l)
    }
    async uploadToSignedUrl(s, a, l, r) {
        var h = this;
        const d = h._removeEmptyFolders(s),
            m = h._getFinalPath(d),
            g = new URL(h.url + `/object/upload/sign/${m}`);
        return g.searchParams.set("token", a), h.handleOperation(async () => {
            let y;
            const v = F({
                    upsert: um.upsert
                }, r),
                _ = F(F({}, h.headers), {
                    "x-upsert": String(v.upsert)
                });
            return typeof Blob < "u" && l instanceof Blob ? (y = new FormData, y.append("cacheControl", v.cacheControl), y.append("", l)) : typeof FormData < "u" && l instanceof FormData ? (y = l, y.append("cacheControl", v.cacheControl)) : (y = l, _["cache-control"] = `max-age=${v.cacheControl}`, _["content-type"] = v.contentType), {
                path: d,
                fullPath: (await Cu(h.fetch, g.toString(), y, {
                    headers: _
                })).Key
            }
        })
    }
    async createSignedUploadUrl(s, a) {
        var l = this;
        return l.handleOperation(async () => {
            let r = l._getFinalPath(s);
            const h = F({}, l.headers);
            a ? .upsert && (h["x-upsert"] = "true");
            const d = await qt(l.fetch, `${l.url}/object/upload/sign/${r}`, {}, {
                    headers: h
                }),
                m = new URL(l.url + d.url),
                g = m.searchParams.get("token");
            if (!g) throw new Vl("No token returned by API");
            return {
                signedUrl: m.toString(),
                path: s,
                token: g
            }
        })
    }
    async update(s, a, l) {
        return this.uploadOrUpdate("PUT", s, a, l)
    }
    async move(s, a, l) {
        var r = this;
        return r.handleOperation(async () => await qt(r.fetch, `${r.url}/object/move`, {
            bucketId: r.bucketId,
            sourceKey: s,
            destinationKey: a,
            destinationBucket: l ? .destinationBucket
        }, {
            headers: r.headers
        }))
    }
    async copy(s, a, l) {
        var r = this;
        return r.handleOperation(async () => ({
            path: (await qt(r.fetch, `${r.url}/object/copy`, {
                bucketId: r.bucketId,
                sourceKey: s,
                destinationKey: a,
                destinationBucket: l ? .destinationBucket
            }, {
                headers: r.headers
            })).Key
        }))
    }
    async createSignedUrl(s, a, l) {
        var r = this;
        return r.handleOperation(async () => {
            let h = r._getFinalPath(s),
                d = await qt(r.fetch, `${r.url}/object/sign/${h}`, F({
                    expiresIn: a
                }, l ? .transform ? {
                    transform: l.transform
                } : {}), {
                    headers: r.headers
                });
            const m = l ? .download ? `&download=${l.download===!0?"":l.download}` : "";
            return {
                signedUrl: encodeURI(`${r.url}${d.signedURL}${m}`)
            }
        })
    }
    async createSignedUrls(s, a, l) {
        var r = this;
        return r.handleOperation(async () => {
            const h = await qt(r.fetch, `${r.url}/object/sign/${r.bucketId}`, {
                    expiresIn: a,
                    paths: s
                }, {
                    headers: r.headers
                }),
                d = l ? .download ? `&download=${l.download===!0?"":l.download}` : "";
            return h.map(m => F(F({}, m), {}, {
                signedUrl: m.signedURL ? encodeURI(`${r.url}${m.signedURL}${d}`) : null
            }))
        })
    }
    download(s, a, l) {
        const r = typeof a ? .transform < "u" ? "render/image/authenticated" : "object",
            h = this.transformOptsToQueryString(a ? .transform || {}),
            d = h ? `?${h}` : "",
            m = this._getFinalPath(s),
            g = () => hs(this.fetch, `${this.url}/${r}/${m}${d}`, {
                headers: this.headers,
                noResolveJson: !0
            }, l);
        return new by(g, this.shouldThrowOnError)
    }
    async info(s) {
        var a = this;
        const l = a._getFinalPath(s);
        return a.handleOperation(async () => Ru(await hs(a.fetch, `${a.url}/object/info/${l}`, {
            headers: a.headers
        })))
    }
    async exists(s) {
        var a = this;
        const l = a._getFinalPath(s);
        try {
            return await vy(a.fetch, `${a.url}/object/${l}`, {
                headers: a.headers
            }), {
                data: !0,
                error: null
            }
        } catch (r) {
            if (a.shouldThrowOnError) throw r;
            if (Xl(r) && r instanceof Nm) {
                const h = r.originalError;
                if ([400, 404].includes(h ? .status)) return {
                    data: !1,
                    error: r
                }
            }
            throw r
        }
    }
    getPublicUrl(s, a) {
        const l = this._getFinalPath(s),
            r = [],
            h = a ? .download ? `download=${a.download===!0?"":a.download}` : "";
        h !== "" && r.push(h);
        const d = typeof a ? .transform < "u" ? "render/image" : "object",
            m = this.transformOptsToQueryString(a ? .transform || {});
        m !== "" && r.push(m);
        let g = r.join("&");
        return g !== "" && (g = `?${g}`), {
            data: {
                publicUrl: encodeURI(`${this.url}/${d}/public/${l}${g}`)
            }
        }
    }
    async remove(s) {
        var a = this;
        return a.handleOperation(async () => await qu(a.fetch, `${a.url}/object/${a.bucketId}`, {
            prefixes: s
        }, {
            headers: a.headers
        }))
    }
    async list(s, a, l) {
        var r = this;
        return r.handleOperation(async () => {
            const h = F(F(F({}, _y), a), {}, {
                prefix: s || ""
            });
            return await qt(r.fetch, `${r.url}/object/list/${r.bucketId}`, h, {
                headers: r.headers
            }, l)
        })
    }
    async listV2(s, a) {
        var l = this;
        return l.handleOperation(async () => {
            const r = F({}, s);
            return await qt(l.fetch, `${l.url}/object/list-v2/${l.bucketId}`, r, {
                headers: l.headers
            }, a)
        })
    }
    encodeMetadata(s) {
        return JSON.stringify(s)
    }
    toBase64(s) {
        return typeof Buffer < "u" ? Buffer.from(s).toString("base64") : btoa(s)
    }
    _getFinalPath(s) {
        return `${this.bucketId}/${s.replace(/^\/+/,"")}`
    }
    _removeEmptyFolders(s) {
        return s.replace(/^\/|\/$/g, "").replace(/\/+/g, "/")
    }
    transformOptsToQueryString(s) {
        const a = [];
        return s.width && a.push(`width=${s.width}`), s.height && a.push(`height=${s.height}`), s.resize && a.push(`resize=${s.resize}`), s.format && a.push(`format=${s.format}`), s.quality && a.push(`quality=${s.quality}`), a.join("&")
    }
};
const Sy = "2.95.3",
    gs = {
        "X-Client-Info": `storage-js/${Sy}`
    };
var wy = class extends oi {
        constructor(s, a = {}, l, r) {
            const h = new URL(s);
            r ? .useNewHostname && /supabase\.(co|in|red)$/.test(h.hostname) && !h.hostname.includes("storage.supabase.") && (h.hostname = h.hostname.replace("supabase.", "storage.supabase."));
            const d = h.href.replace(/\/$/, ""),
                m = F(F({}, gs), a);
            super(d, m, l, "storage")
        }
        async listBuckets(s) {
            var a = this;
            return a.handleOperation(async () => {
                const l = a.listBucketOptionsToQueryString(s);
                return await hs(a.fetch, `${a.url}/bucket${l}`, {
                    headers: a.headers
                })
            })
        }
        async getBucket(s) {
            var a = this;
            return a.handleOperation(async () => await hs(a.fetch, `${a.url}/bucket/${s}`, {
                headers: a.headers
            }))
        }
        async createBucket(s, a = {
            public: !1
        }) {
            var l = this;
            return l.handleOperation(async () => await qt(l.fetch, `${l.url}/bucket`, {
                id: s,
                name: s,
                type: a.type,
                public: a.public,
                file_size_limit: a.fileSizeLimit,
                allowed_mime_types: a.allowedMimeTypes
            }, {
                headers: l.headers
            }))
        }
        async updateBucket(s, a) {
            var l = this;
            return l.handleOperation(async () => await Cu(l.fetch, `${l.url}/bucket/${s}`, {
                id: s,
                name: s,
                public: a.public,
                file_size_limit: a.fileSizeLimit,
                allowed_mime_types: a.allowedMimeTypes
            }, {
                headers: l.headers
            }))
        }
        async emptyBucket(s) {
            var a = this;
            return a.handleOperation(async () => await qt(a.fetch, `${a.url}/bucket/${s}/empty`, {}, {
                headers: a.headers
            }))
        }
        async deleteBucket(s) {
            var a = this;
            return a.handleOperation(async () => await qu(a.fetch, `${a.url}/bucket/${s}`, {}, {
                headers: a.headers
            }))
        }
        listBucketOptionsToQueryString(s) {
            const a = {};
            return s && ("limit" in s && (a.limit = String(s.limit)), "offset" in s && (a.offset = String(s.offset)), s.search && (a.search = s.search), s.sortColumn && (a.sortColumn = s.sortColumn), s.sortOrder && (a.sortOrder = s.sortOrder)), Object.keys(a).length > 0 ? "?" + new URLSearchParams(a).toString() : ""
        }
    },
    xy = class extends oi {
        constructor(s, a = {}, l) {
            const r = s.replace(/\/$/, ""),
                h = F(F({}, gs), a);
            super(r, h, l, "storage")
        }
        async createBucket(s) {
            var a = this;
            return a.handleOperation(async () => await qt(a.fetch, `${a.url}/bucket`, {
                name: s
            }, {
                headers: a.headers
            }))
        }
        async listBuckets(s) {
            var a = this;
            return a.handleOperation(async () => {
                const l = new URLSearchParams;
                s ? .limit !== void 0 && l.set("limit", s.limit.toString()), s ? .offset !== void 0 && l.set("offset", s.offset.toString()), s ? .sortColumn && l.set("sortColumn", s.sortColumn), s ? .sortOrder && l.set("sortOrder", s.sortOrder), s ? .search && l.set("search", s.search);
                const r = l.toString(),
                    h = r ? `${a.url}/bucket?${r}` : `${a.url}/bucket`;
                return await hs(a.fetch, h, {
                    headers: a.headers
                })
            })
        }
        async deleteBucket(s) {
            var a = this;
            return a.handleOperation(async () => await qu(a.fetch, `${a.url}/bucket/${s}`, {}, {
                headers: a.headers
            }))
        }
        from(s) {
            var a = this;
            if (!cy(s)) throw new Vl("Invalid bucket name: File, folder, and bucket names must follow AWS object key naming guidelines and should avoid the use of any other characters.");
            const l = new ry({
                    baseUrl: this.url,
                    catalogName: s,
                    auth: {
                        type: "custom",
                        getHeaders: async () => a.headers
                    },
                    fetch: this.fetch
                }),
                r = this.shouldThrowOnError;
            return new Proxy(l, {
                get(h, d) {
                    const m = h[d];
                    return typeof m != "function" ? m : async (...g) => {
                        try {
                            return {
                                data: await m.apply(h, g),
                                error: null
                            }
                        } catch (y) {
                            if (r) throw y;
                            return {
                                data: null,
                                error: y
                            }
                        }
                    }
                }
            })
        }
    },
    Ey = class extends oi {
        constructor(s, a = {}, l) {
            const r = s.replace(/\/$/, ""),
                h = F(F({}, gs), {}, {
                    "Content-Type": "application/json"
                }, a);
            super(r, h, l, "vectors")
        }
        async createIndex(s) {
            var a = this;
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/CreateIndex`, s, {
                headers: a.headers
            }) || {})
        }
        async getIndex(s, a) {
            var l = this;
            return l.handleOperation(async () => await St.post(l.fetch, `${l.url}/GetIndex`, {
                vectorBucketName: s,
                indexName: a
            }, {
                headers: l.headers
            }))
        }
        async listIndexes(s) {
            var a = this;
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/ListIndexes`, s, {
                headers: a.headers
            }))
        }
        async deleteIndex(s, a) {
            var l = this;
            return l.handleOperation(async () => await St.post(l.fetch, `${l.url}/DeleteIndex`, {
                vectorBucketName: s,
                indexName: a
            }, {
                headers: l.headers
            }) || {})
        }
    },
    Ty = class extends oi {
        constructor(s, a = {}, l) {
            const r = s.replace(/\/$/, ""),
                h = F(F({}, gs), {}, {
                    "Content-Type": "application/json"
                }, a);
            super(r, h, l, "vectors")
        }
        async putVectors(s) {
            var a = this;
            if (s.vectors.length < 1 || s.vectors.length > 500) throw new Error("Vector batch size must be between 1 and 500 items");
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/PutVectors`, s, {
                headers: a.headers
            }) || {})
        }
        async getVectors(s) {
            var a = this;
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/GetVectors`, s, {
                headers: a.headers
            }))
        }
        async listVectors(s) {
            var a = this;
            if (s.segmentCount !== void 0) {
                if (s.segmentCount < 1 || s.segmentCount > 16) throw new Error("segmentCount must be between 1 and 16");
                if (s.segmentIndex !== void 0 && (s.segmentIndex < 0 || s.segmentIndex >= s.segmentCount)) throw new Error(`segmentIndex must be between 0 and ${s.segmentCount-1}`)
            }
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/ListVectors`, s, {
                headers: a.headers
            }))
        }
        async queryVectors(s) {
            var a = this;
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/QueryVectors`, s, {
                headers: a.headers
            }))
        }
        async deleteVectors(s) {
            var a = this;
            if (s.keys.length < 1 || s.keys.length > 500) throw new Error("Keys batch size must be between 1 and 500 items");
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/DeleteVectors`, s, {
                headers: a.headers
            }) || {})
        }
    },
    Ay = class extends oi {
        constructor(s, a = {}, l) {
            const r = s.replace(/\/$/, ""),
                h = F(F({}, gs), {}, {
                    "Content-Type": "application/json"
                }, a);
            super(r, h, l, "vectors")
        }
        async createBucket(s) {
            var a = this;
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/CreateVectorBucket`, {
                vectorBucketName: s
            }, {
                headers: a.headers
            }) || {})
        }
        async getBucket(s) {
            var a = this;
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/GetVectorBucket`, {
                vectorBucketName: s
            }, {
                headers: a.headers
            }))
        }
        async listBuckets(s = {}) {
            var a = this;
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/ListVectorBuckets`, s, {
                headers: a.headers
            }))
        }
        async deleteBucket(s) {
            var a = this;
            return a.handleOperation(async () => await St.post(a.fetch, `${a.url}/DeleteVectorBucket`, {
                vectorBucketName: s
            }, {
                headers: a.headers
            }) || {})
        }
    },
    Oy = class extends Ay {
        constructor(s, a = {}) {
            super(s, a.headers || {}, a.fetch)
        }
        from(s) {
            return new Ny(this.url, this.headers, s, this.fetch)
        }
        async createBucket(s) {
            var a = () => super.createBucket,
                l = this;
            return a().call(l, s)
        }
        async getBucket(s) {
            var a = () => super.getBucket,
                l = this;
            return a().call(l, s)
        }
        async listBuckets(s = {}) {
            var a = () => super.listBuckets,
                l = this;
            return a().call(l, s)
        }
        async deleteBucket(s) {
            var a = () => super.deleteBucket,
                l = this;
            return a().call(l, s)
        }
    },
    Ny = class extends Ey {
        constructor(s, a, l, r) {
            super(s, a, r), this.vectorBucketName = l
        }
        async createIndex(s) {
            var a = () => super.createIndex,
                l = this;
            return a().call(l, F(F({}, s), {}, {
                vectorBucketName: l.vectorBucketName
            }))
        }
        async listIndexes(s = {}) {
            var a = () => super.listIndexes,
                l = this;
            return a().call(l, F(F({}, s), {}, {
                vectorBucketName: l.vectorBucketName
            }))
        }
        async getIndex(s) {
            var a = () => super.getIndex,
                l = this;
            return a().call(l, l.vectorBucketName, s)
        }
        async deleteIndex(s) {
            var a = () => super.deleteIndex,
                l = this;
            return a().call(l, l.vectorBucketName, s)
        }
        index(s) {
            return new Ry(this.url, this.headers, this.vectorBucketName, s, this.fetch)
        }
    },
    Ry = class extends Ty {
        constructor(s, a, l, r, h) {
            super(s, a, h), this.vectorBucketName = l, this.indexName = r
        }
        async putVectors(s) {
            var a = () => super.putVectors,
                l = this;
            return a().call(l, F(F({}, s), {}, {
                vectorBucketName: l.vectorBucketName,
                indexName: l.indexName
            }))
        }
        async getVectors(s) {
            var a = () => super.getVectors,
                l = this;
            return a().call(l, F(F({}, s), {}, {
                vectorBucketName: l.vectorBucketName,
                indexName: l.indexName
            }))
        }
        async listVectors(s = {}) {
            var a = () => super.listVectors,
                l = this;
            return a().call(l, F(F({}, s), {}, {
                vectorBucketName: l.vectorBucketName,
                indexName: l.indexName
            }))
        }
        async queryVectors(s) {
            var a = () => super.queryVectors,
                l = this;
            return a().call(l, F(F({}, s), {}, {
                vectorBucketName: l.vectorBucketName,
                indexName: l.indexName
            }))
        }
        async deleteVectors(s) {
            var a = () => super.deleteVectors,
                l = this;
            return a().call(l, F(F({}, s), {}, {
                vectorBucketName: l.vectorBucketName,
                indexName: l.indexName
            }))
        }
    },
    Cy = class extends wy {
        constructor(s, a = {}, l, r) {
            super(s, a, l, r)
        }
        from(s) {
            return new jy(this.url, this.headers, s, this.fetch)
        }
        get vectors() {
            return new Oy(this.url + "/vector", {
                headers: this.headers,
                fetch: this.fetch
            })
        }
        get analytics() {
            return new xy(this.url + "/iceberg", this.headers, this.fetch)
        }
    };
const Dm = "2.95.3",
    ii = 30 * 1e3,
    Du = 3,
    ju = Du * ii,
    Dy = "http://localhost:9999",
    Uy = "supabase.auth.token",
    ky = {
        "X-Client-Info": `gotrue-js/${Dm}`
    },
    Uu = "X-Supabase-Api-Version",
    Um = {
        "2024-01-01": {
            timestamp: Date.parse("2024-01-01T00:00:00.0Z"),
            name: "2024-01-01"
        }
    },
    zy = /^([a-z0-9_-]{4})*($|[a-z0-9_-]{3}$|[a-z0-9_-]{2}$)$/i,
    My = 600 * 1e3;
class ds extends Error {
    constructor(a, l, r) {
        super(a), this.__isAuthError = !0, this.name = "AuthError", this.status = l, this.code = r
    }
}

function Q(s) {
    return typeof s == "object" && s !== null && "__isAuthError" in s
}
class By extends ds {
    constructor(a, l, r) {
        super(a, l, r), this.name = "AuthApiError", this.status = l, this.code = r
    }
}

function qy(s) {
    return Q(s) && s.name === "AuthApiError"
}
class ca extends ds {
    constructor(a, l) {
        super(a), this.name = "AuthUnknownError", this.originalError = l
    }
}
class dn extends ds {
    constructor(a, l, r, h) {
        super(a, r, h), this.name = l, this.status = r
    }
}
class jt extends dn {
    constructor() {
        super("Auth session missing!", "AuthSessionMissingError", 400, void 0)
    }
}

function Su(s) {
    return Q(s) && s.name === "AuthSessionMissingError"
}
class Wa extends dn {
    constructor() {
        super("Auth session or user missing", "AuthInvalidTokenResponseError", 500, void 0)
    }
}
class ql extends dn {
    constructor(a) {
        super(a, "AuthInvalidCredentialsError", 400, void 0)
    }
}
class Ll extends dn {
    constructor(a, l = null) {
        super(a, "AuthImplicitGrantRedirectError", 500, void 0), this.details = null, this.details = l
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            status: this.status,
            details: this.details
        }
    }
}

function Ly(s) {
    return Q(s) && s.name === "AuthImplicitGrantRedirectError"
}
class cm extends dn {
    constructor(a, l = null) {
        super(a, "AuthPKCEGrantCodeExchangeError", 500, void 0), this.details = null, this.details = l
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            status: this.status,
            details: this.details
        }
    }
}
class Hy extends dn {
    constructor() {
        super("PKCE code verifier not found in storage. This can happen if the auth flow was initiated in a different browser or device, or if the storage was cleared. For SSR frameworks (Next.js, SvelteKit, etc.), use @supabase/ssr on both the server and client to store the code verifier in cookies.", "AuthPKCECodeVerifierMissingError", 400, "pkce_code_verifier_not_found")
    }
}
class ku extends dn {
    constructor(a, l) {
        super(a, "AuthRetryableFetchError", l, void 0)
    }
}

function wu(s) {
    return Q(s) && s.name === "AuthRetryableFetchError"
}
class hm extends dn {
    constructor(a, l, r) {
        super(a, "AuthWeakPasswordError", l, "weak_password"), this.reasons = r
    }
}
class zu extends dn {
    constructor(a) {
        super(a, "AuthInvalidJwtError", 400, "invalid_jwt")
    }
}
const Gl = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".split(""),
    dm = ` 	
\r=`.split(""),
    Gy = (() => {
        const s = new Array(128);
        for (let a = 0; a < s.length; a += 1) s[a] = -1;
        for (let a = 0; a < dm.length; a += 1) s[dm[a].charCodeAt(0)] = -2;
        for (let a = 0; a < Gl.length; a += 1) s[Gl[a].charCodeAt(0)] = a;
        return s
    })();

function fm(s, a, l) {
    if (s !== null)
        for (a.queue = a.queue << 8 | s, a.queuedBits += 8; a.queuedBits >= 6;) {
            const r = a.queue >> a.queuedBits - 6 & 63;
            l(Gl[r]), a.queuedBits -= 6
        } else if (a.queuedBits > 0)
            for (a.queue = a.queue << 6 - a.queuedBits, a.queuedBits = 6; a.queuedBits >= 6;) {
                const r = a.queue >> a.queuedBits - 6 & 63;
                l(Gl[r]), a.queuedBits -= 6
            }
}

function km(s, a, l) {
    const r = Gy[s];
    if (r > -1)
        for (a.queue = a.queue << 6 | r, a.queuedBits += 6; a.queuedBits >= 8;) l(a.queue >> a.queuedBits - 8 & 255), a.queuedBits -= 8;
    else {
        if (r === -2) return;
        throw new Error(`Invalid Base64-URL character "${String.fromCharCode(s)}"`)
    }
}

function mm(s) {
    const a = [],
        l = m => {
            a.push(String.fromCodePoint(m))
        },
        r = {
            utf8seq: 0,
            codepoint: 0
        },
        h = {
            queue: 0,
            queuedBits: 0
        },
        d = m => {
            Yy(m, r, l)
        };
    for (let m = 0; m < s.length; m += 1) km(s.charCodeAt(m), h, d);
    return a.join("")
}

function Ky(s, a) {
    if (s <= 127) {
        a(s);
        return
    } else if (s <= 2047) {
        a(192 | s >> 6), a(128 | s & 63);
        return
    } else if (s <= 65535) {
        a(224 | s >> 12), a(128 | s >> 6 & 63), a(128 | s & 63);
        return
    } else if (s <= 1114111) {
        a(240 | s >> 18), a(128 | s >> 12 & 63), a(128 | s >> 6 & 63), a(128 | s & 63);
        return
    }
    throw new Error(`Unrecognized Unicode codepoint: ${s.toString(16)}`)
}

function $y(s, a) {
    for (let l = 0; l < s.length; l += 1) {
        let r = s.charCodeAt(l);
        if (r > 55295 && r <= 56319) {
            const h = (r - 55296) * 1024 & 65535;
            r = (s.charCodeAt(l + 1) - 56320 & 65535 | h) + 65536, l += 1
        }
        Ky(r, a)
    }
}

function Yy(s, a, l) {
    if (a.utf8seq === 0) {
        if (s <= 127) {
            l(s);
            return
        }
        for (let r = 1; r < 6; r += 1)
            if ((s >> 7 - r & 1) === 0) {
                a.utf8seq = r;
                break
            }
        if (a.utf8seq === 2) a.codepoint = s & 31;
        else if (a.utf8seq === 3) a.codepoint = s & 15;
        else if (a.utf8seq === 4) a.codepoint = s & 7;
        else throw new Error("Invalid UTF-8 sequence");
        a.utf8seq -= 1
    } else if (a.utf8seq > 0) {
        if (s <= 127) throw new Error("Invalid UTF-8 sequence");
        a.codepoint = a.codepoint << 6 | s & 63, a.utf8seq -= 1, a.utf8seq === 0 && l(a.codepoint)
    }
}

function ri(s) {
    const a = [],
        l = {
            queue: 0,
            queuedBits: 0
        },
        r = h => {
            a.push(h)
        };
    for (let h = 0; h < s.length; h += 1) km(s.charCodeAt(h), l, r);
    return new Uint8Array(a)
}

function Vy(s) {
    const a = [];
    return $y(s, l => a.push(l)), new Uint8Array(a)
}

function ha(s) {
    const a = [],
        l = {
            queue: 0,
            queuedBits: 0
        },
        r = h => {
            a.push(h)
        };
    return s.forEach(h => fm(h, l, r)), fm(null, l, r), a.join("")
}

function Xy(s) {
    return Math.round(Date.now() / 1e3) + s
}

function Qy() {
    return Symbol("auth-callback")
}
const Fe = () => typeof window < "u" && typeof document < "u",
    la = {
        tested: !1,
        writable: !1
    },
    zm = () => {
        if (!Fe()) return !1;
        try {
            if (typeof globalThis.localStorage != "object") return !1
        } catch {
            return !1
        }
        if (la.tested) return la.writable;
        const s = `lswt-${Math.random()}${Math.random()}`;
        try {
            globalThis.localStorage.setItem(s, s), globalThis.localStorage.removeItem(s), la.tested = !0, la.writable = !0
        } catch {
            la.tested = !0, la.writable = !1
        }
        return la.writable
    };

function Jy(s) {
    const a = {},
        l = new URL(s);
    if (l.hash && l.hash[0] === "#") try {
        new URLSearchParams(l.hash.substring(1)).forEach((h, d) => {
            a[d] = h
        })
    } catch {}
    return l.searchParams.forEach((r, h) => {
        a[h] = r
    }), a
}
const Mm = s => s ? (...a) => s(...a) : (...a) => fetch(...a),
    Zy = s => typeof s == "object" && s !== null && "status" in s && "ok" in s && "json" in s && typeof s.json == "function",
    si = async (s, a, l) => {
        await s.setItem(a, JSON.stringify(l))
    },
    ra = async (s, a) => {
        const l = await s.getItem(a);
        if (!l) return null;
        try {
            return JSON.parse(l)
        } catch {
            return l
        }
    },
    We = async (s, a) => {
        await s.removeItem(a)
    };
class Ql {
    constructor() {
        this.promise = new Ql.promiseConstructor((a, l) => {
            this.resolve = a, this.reject = l
        })
    }
}
Ql.promiseConstructor = Promise;

function Hl(s) {
    const a = s.split(".");
    if (a.length !== 3) throw new zu("Invalid JWT structure");
    for (let r = 0; r < a.length; r++)
        if (!zy.test(a[r])) throw new zu("JWT not in base64url format");
    return {
        header: JSON.parse(mm(a[0])),
        payload: JSON.parse(mm(a[1])),
        signature: ri(a[2]),
        raw: {
            header: a[0],
            payload: a[1]
        }
    }
}
async function Iy(s) {
    return await new Promise(a => {
        setTimeout(() => a(null), s)
    })
}

function Py(s, a) {
    return new Promise((r, h) => {
        (async () => {
            for (let d = 0; d < 1 / 0; d++) try {
                const m = await s(d);
                if (!a(d, null, m)) {
                    r(m);
                    return
                }
            } catch (m) {
                if (!a(d, m)) {
                    h(m);
                    return
                }
            }
        })()
    })
}

function Wy(s) {
    return ("0" + s.toString(16)).substr(-2)
}

function Fy() {
    const a = new Uint32Array(56);
    if (typeof crypto > "u") {
        const l = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~",
            r = l.length;
        let h = "";
        for (let d = 0; d < 56; d++) h += l.charAt(Math.floor(Math.random() * r));
        return h
    }
    return crypto.getRandomValues(a), Array.from(a, Wy).join("")
}
async function e0(s) {
    const l = new TextEncoder().encode(s),
        r = await crypto.subtle.digest("SHA-256", l),
        h = new Uint8Array(r);
    return Array.from(h).map(d => String.fromCharCode(d)).join("")
}
async function t0(s) {
    if (!(typeof crypto < "u" && typeof crypto.subtle < "u" && typeof TextEncoder < "u")) return console.warn("WebCrypto API is not supported. Code challenge method will default to use plain instead of sha256."), s;
    const l = await e0(s);
    return btoa(l).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
}
async function Fa(s, a, l = !1) {
    const r = Fy();
    let h = r;
    l && (h += "/PASSWORD_RECOVERY"), await si(s, `${a}-code-verifier`, h);
    const d = await t0(r);
    return [d, r === d ? "plain" : "s256"]
}
const n0 = /^2[0-9]{3}-(0[1-9]|1[0-2])-(0[1-9]|1[0-9]|2[0-9]|3[0-1])$/i;

function a0(s) {
    const a = s.headers.get(Uu);
    if (!a || !a.match(n0)) return null;
    try {
        return new Date(`${a}T00:00:00.0Z`)
    } catch {
        return null
    }
}

function i0(s) {
    if (!s) throw new Error("Missing exp claim");
    const a = Math.floor(Date.now() / 1e3);
    if (s <= a) throw new Error("JWT has expired")
}

function s0(s) {
    switch (s) {
        case "RS256":
            return {
                name: "RSASSA-PKCS1-v1_5",
                hash: {
                    name: "SHA-256"
                }
            };
        case "ES256":
            return {
                name: "ECDSA",
                namedCurve: "P-256",
                hash: {
                    name: "SHA-256"
                }
            };
        default:
            throw new Error("Invalid alg claim")
    }
}
const l0 = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

function ei(s) {
    if (!l0.test(s)) throw new Error("@supabase/auth-js: Expected parameter to be UUID but is not")
}

function xu() {
    const s = {};
    return new Proxy(s, {
        get: (a, l) => {
            if (l === "__isUserNotAvailableProxy") return !0;
            if (typeof l == "symbol") {
                const r = l.toString();
                if (r === "Symbol(Symbol.toPrimitive)" || r === "Symbol(Symbol.toStringTag)" || r === "Symbol(util.inspect.custom)") return
            }
            throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Accessing the "${l}" property of the session object is not supported. Please use getUser() instead.`)
        },
        set: (a, l) => {
            throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Setting the "${l}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`)
        },
        deleteProperty: (a, l) => {
            throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Deleting the "${l}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`)
        }
    })
}

function r0(s, a) {
    return new Proxy(s, {
        get: (l, r, h) => {
            if (r === "__isInsecureUserWarningProxy") return !0;
            if (typeof r == "symbol") {
                const d = r.toString();
                if (d === "Symbol(Symbol.toPrimitive)" || d === "Symbol(Symbol.toStringTag)" || d === "Symbol(util.inspect.custom)" || d === "Symbol(nodejs.util.inspect.custom)") return Reflect.get(l, r, h)
            }
            return !a.value && typeof r == "string" && (console.warn("Using the user object as returned from supabase.auth.getSession() or from some supabase.auth.onAuthStateChange() events could be insecure! This value comes directly from the storage medium (usually cookies on the server) and may not be authentic. Use supabase.auth.getUser() instead which authenticates the data by contacting the Supabase Auth server."), a.value = !0), Reflect.get(l, r, h)
        }
    })
}

function gm(s) {
    return JSON.parse(JSON.stringify(s))
}
const oa = s => s.msg || s.message || s.error_description || s.error || JSON.stringify(s),
    o0 = [502, 503, 504];
async function pm(s) {
    var a;
    if (!Zy(s)) throw new ku(oa(s), 0);
    if (o0.includes(s.status)) throw new ku(oa(s), s.status);
    let l;
    try {
        l = await s.json()
    } catch (d) {
        throw new ca(oa(d), d)
    }
    let r;
    const h = a0(s);
    if (h && h.getTime() >= Um["2024-01-01"].timestamp && typeof l == "object" && l && typeof l.code == "string" ? r = l.code : typeof l == "object" && l && typeof l.error_code == "string" && (r = l.error_code), r) {
        if (r === "weak_password") throw new hm(oa(l), s.status, ((a = l.weak_password) === null || a === void 0 ? void 0 : a.reasons) || []);
        if (r === "session_not_found") throw new jt
    } else if (typeof l == "object" && l && typeof l.weak_password == "object" && l.weak_password && Array.isArray(l.weak_password.reasons) && l.weak_password.reasons.length && l.weak_password.reasons.reduce((d, m) => d && typeof m == "string", !0)) throw new hm(oa(l), s.status, l.weak_password.reasons);
    throw new By(oa(l), s.status || 500, r)
}
const u0 = (s, a, l, r) => {
    const h = {
        method: s,
        headers: a ? .headers || {}
    };
    return s === "GET" ? h : (h.headers = Object.assign({
        "Content-Type": "application/json;charset=UTF-8"
    }, a ? .headers), h.body = JSON.stringify(r), Object.assign(Object.assign({}, h), l))
};
async function W(s, a, l, r) {
    var h;
    const d = Object.assign({}, r ? .headers);
    d[Uu] || (d[Uu] = Um["2024-01-01"].name), r ? .jwt && (d.Authorization = `Bearer ${r.jwt}`);
    const m = (h = r ? .query) !== null && h !== void 0 ? h : {};
    r ? .redirectTo && (m.redirect_to = r.redirectTo);
    const g = Object.keys(m).length ? "?" + new URLSearchParams(m).toString() : "",
        y = await c0(s, a, l + g, {
            headers: d,
            noResolveJson: r ? .noResolveJson
        }, {}, r ? .body);
    return r ? .xform ? r ? .xform(y) : {
        data: Object.assign({}, y),
        error: null
    }
}
async function c0(s, a, l, r, h, d) {
    const m = u0(a, r, h, d);
    let g;
    try {
        g = await s(l, Object.assign({}, m))
    } catch (y) {
        throw console.error(y), new ku(oa(y), 0)
    }
    if (g.ok || await pm(g), r ? .noResolveJson) return g;
    try {
        return await g.json()
    } catch (y) {
        await pm(y)
    }
}

function Bt(s) {
    var a;
    let l = null;
    f0(s) && (l = Object.assign({}, s), s.expires_at || (l.expires_at = Xy(s.expires_in)));
    const r = (a = s.user) !== null && a !== void 0 ? a : s;
    return {
        data: {
            session: l,
            user: r
        },
        error: null
    }
}

function vm(s) {
    const a = Bt(s);
    return !a.error && s.weak_password && typeof s.weak_password == "object" && Array.isArray(s.weak_password.reasons) && s.weak_password.reasons.length && s.weak_password.message && typeof s.weak_password.message == "string" && s.weak_password.reasons.reduce((l, r) => l && typeof r == "string", !0) && (a.data.weak_password = s.weak_password), a
}

function Ln(s) {
    var a;
    return {
        data: {
            user: (a = s.user) !== null && a !== void 0 ? a : s
        },
        error: null
    }
}

function h0(s) {
    return {
        data: s,
        error: null
    }
}

function d0(s) {
    const {
        action_link: a,
        email_otp: l,
        hashed_token: r,
        redirect_to: h,
        verification_type: d
    } = s, m = Yl(s, ["action_link", "email_otp", "hashed_token", "redirect_to", "verification_type"]), g = {
        action_link: a,
        email_otp: l,
        hashed_token: r,
        redirect_to: h,
        verification_type: d
    }, y = Object.assign({}, m);
    return {
        data: {
            properties: g,
            user: y
        },
        error: null
    }
}

function ym(s) {
    return s
}

function f0(s) {
    return s.access_token && s.refresh_token && s.expires_in
}
const Eu = ["global", "local", "others"];
class m0 {
    constructor({
        url: a = "",
        headers: l = {},
        fetch: r
    }) {
        this.url = a, this.headers = l, this.fetch = Mm(r), this.mfa = {
            listFactors: this._listFactors.bind(this),
            deleteFactor: this._deleteFactor.bind(this)
        }, this.oauth = {
            listClients: this._listOAuthClients.bind(this),
            createClient: this._createOAuthClient.bind(this),
            getClient: this._getOAuthClient.bind(this),
            updateClient: this._updateOAuthClient.bind(this),
            deleteClient: this._deleteOAuthClient.bind(this),
            regenerateClientSecret: this._regenerateOAuthClientSecret.bind(this)
        }
    }
    async signOut(a, l = Eu[0]) {
        if (Eu.indexOf(l) < 0) throw new Error(`@supabase/auth-js: Parameter scope must be one of ${Eu.join(", ")}`);
        try {
            return await W(this.fetch, "POST", `${this.url}/logout?scope=${l}`, {
                headers: this.headers,
                jwt: a,
                noResolveJson: !0
            }), {
                data: null,
                error: null
            }
        } catch (r) {
            if (Q(r)) return {
                data: null,
                error: r
            };
            throw r
        }
    }
    async inviteUserByEmail(a, l = {}) {
        try {
            return await W(this.fetch, "POST", `${this.url}/invite`, {
                body: {
                    email: a,
                    data: l.data
                },
                headers: this.headers,
                redirectTo: l.redirectTo,
                xform: Ln
            })
        } catch (r) {
            if (Q(r)) return {
                data: {
                    user: null
                },
                error: r
            };
            throw r
        }
    }
    async generateLink(a) {
        try {
            const {
                options: l
            } = a, r = Yl(a, ["options"]), h = Object.assign(Object.assign({}, r), l);
            return "newEmail" in r && (h.new_email = r ? .newEmail, delete h.newEmail), await W(this.fetch, "POST", `${this.url}/admin/generate_link`, {
                body: h,
                headers: this.headers,
                xform: d0,
                redirectTo: l ? .redirectTo
            })
        } catch (l) {
            if (Q(l)) return {
                data: {
                    properties: null,
                    user: null
                },
                error: l
            };
            throw l
        }
    }
    async createUser(a) {
        try {
            return await W(this.fetch, "POST", `${this.url}/admin/users`, {
                body: a,
                headers: this.headers,
                xform: Ln
            })
        } catch (l) {
            if (Q(l)) return {
                data: {
                    user: null
                },
                error: l
            };
            throw l
        }
    }
    async listUsers(a) {
        var l, r, h, d, m, g, y;
        try {
            const v = {
                    nextPage: null,
                    lastPage: 0,
                    total: 0
                },
                _ = await W(this.fetch, "GET", `${this.url}/admin/users`, {
                    headers: this.headers,
                    noResolveJson: !0,
                    query: {
                        page: (r = (l = a ? .page) === null || l === void 0 ? void 0 : l.toString()) !== null && r !== void 0 ? r : "",
                        per_page: (d = (h = a ? .perPage) === null || h === void 0 ? void 0 : h.toString()) !== null && d !== void 0 ? d : ""
                    },
                    xform: ym
                });
            if (_.error) throw _.error;
            const w = await _.json(),
                E = (m = _.headers.get("x-total-count")) !== null && m !== void 0 ? m : 0,
                O = (y = (g = _.headers.get("link")) === null || g === void 0 ? void 0 : g.split(",")) !== null && y !== void 0 ? y : [];
            return O.length > 0 && (O.forEach(k => {
                const B = parseInt(k.split(";")[0].split("=")[1].substring(0, 1)),
                    L = JSON.parse(k.split(";")[1].split("=")[1]);
                v[`${L}Page`] = B
            }), v.total = parseInt(E)), {
                data: Object.assign(Object.assign({}, w), v),
                error: null
            }
        } catch (v) {
            if (Q(v)) return {
                data: {
                    users: []
                },
                error: v
            };
            throw v
        }
    }
    async getUserById(a) {
        ei(a);
        try {
            return await W(this.fetch, "GET", `${this.url}/admin/users/${a}`, {
                headers: this.headers,
                xform: Ln
            })
        } catch (l) {
            if (Q(l)) return {
                data: {
                    user: null
                },
                error: l
            };
            throw l
        }
    }
    async updateUserById(a, l) {
        ei(a);
        try {
            return await W(this.fetch, "PUT", `${this.url}/admin/users/${a}`, {
                body: l,
                headers: this.headers,
                xform: Ln
            })
        } catch (r) {
            if (Q(r)) return {
                data: {
                    user: null
                },
                error: r
            };
            throw r
        }
    }
    async deleteUser(a, l = !1) {
        ei(a);
        try {
            return await W(this.fetch, "DELETE", `${this.url}/admin/users/${a}`, {
                headers: this.headers,
                body: {
                    should_soft_delete: l
                },
                xform: Ln
            })
        } catch (r) {
            if (Q(r)) return {
                data: {
                    user: null
                },
                error: r
            };
            throw r
        }
    }
    async _listFactors(a) {
        ei(a.userId);
        try {
            const {
                data: l,
                error: r
            } = await W(this.fetch, "GET", `${this.url}/admin/users/${a.userId}/factors`, {
                headers: this.headers,
                xform: h => ({
                    data: {
                        factors: h
                    },
                    error: null
                })
            });
            return {
                data: l,
                error: r
            }
        } catch (l) {
            if (Q(l)) return {
                data: null,
                error: l
            };
            throw l
        }
    }
    async _deleteFactor(a) {
        ei(a.userId), ei(a.id);
        try {
            return {
                data: await W(this.fetch, "DELETE", `${this.url}/admin/users/${a.userId}/factors/${a.id}`, {
                    headers: this.headers
                }),
                error: null
            }
        } catch (l) {
            if (Q(l)) return {
                data: null,
                error: l
            };
            throw l
        }
    }
    async _listOAuthClients(a) {
        var l, r, h, d, m, g, y;
        try {
            const v = {
                    nextPage: null,
                    lastPage: 0,
                    total: 0
                },
                _ = await W(this.fetch, "GET", `${this.url}/admin/oauth/clients`, {
                    headers: this.headers,
                    noResolveJson: !0,
                    query: {
                        page: (r = (l = a ? .page) === null || l === void 0 ? void 0 : l.toString()) !== null && r !== void 0 ? r : "",
                        per_page: (d = (h = a ? .perPage) === null || h === void 0 ? void 0 : h.toString()) !== null && d !== void 0 ? d : ""
                    },
                    xform: ym
                });
            if (_.error) throw _.error;
            const w = await _.json(),
                E = (m = _.headers.get("x-total-count")) !== null && m !== void 0 ? m : 0,
                O = (y = (g = _.headers.get("link")) === null || g === void 0 ? void 0 : g.split(",")) !== null && y !== void 0 ? y : [];
            return O.length > 0 && (O.forEach(k => {
                const B = parseInt(k.split(";")[0].split("=")[1].substring(0, 1)),
                    L = JSON.parse(k.split(";")[1].split("=")[1]);
                v[`${L}Page`] = B
            }), v.total = parseInt(E)), {
                data: Object.assign(Object.assign({}, w), v),
                error: null
            }
        } catch (v) {
            if (Q(v)) return {
                data: {
                    clients: []
                },
                error: v
            };
            throw v
        }
    }
    async _createOAuthClient(a) {
        try {
            return await W(this.fetch, "POST", `${this.url}/admin/oauth/clients`, {
                body: a,
                headers: this.headers,
                xform: l => ({
                    data: l,
                    error: null
                })
            })
        } catch (l) {
            if (Q(l)) return {
                data: null,
                error: l
            };
            throw l
        }
    }
    async _getOAuthClient(a) {
        try {
            return await W(this.fetch, "GET", `${this.url}/admin/oauth/clients/${a}`, {
                headers: this.headers,
                xform: l => ({
                    data: l,
                    error: null
                })
            })
        } catch (l) {
            if (Q(l)) return {
                data: null,
                error: l
            };
            throw l
        }
    }
    async _updateOAuthClient(a, l) {
        try {
            return await W(this.fetch, "PUT", `${this.url}/admin/oauth/clients/${a}`, {
                body: l,
                headers: this.headers,
                xform: r => ({
                    data: r,
                    error: null
                })
            })
        } catch (r) {
            if (Q(r)) return {
                data: null,
                error: r
            };
            throw r
        }
    }
    async _deleteOAuthClient(a) {
        try {
            return await W(this.fetch, "DELETE", `${this.url}/admin/oauth/clients/${a}`, {
                headers: this.headers,
                noResolveJson: !0
            }), {
                data: null,
                error: null
            }
        } catch (l) {
            if (Q(l)) return {
                data: null,
                error: l
            };
            throw l
        }
    }
    async _regenerateOAuthClientSecret(a) {
        try {
            return await W(this.fetch, "POST", `${this.url}/admin/oauth/clients/${a}/regenerate_secret`, {
                headers: this.headers,
                xform: l => ({
                    data: l,
                    error: null
                })
            })
        } catch (l) {
            if (Q(l)) return {
                data: null,
                error: l
            };
            throw l
        }
    }
}

function bm(s = {}) {
    return {
        getItem: a => s[a] || null,
        setItem: (a, l) => {
            s[a] = l
        },
        removeItem: a => {
            delete s[a]
        }
    }
}
const ti = {
    debug: !!(globalThis && zm() && globalThis.localStorage && globalThis.localStorage.getItem("supabase.gotrue-js.locks.debug") === "true")
};
class Bm extends Error {
    constructor(a) {
        super(a), this.isAcquireTimeout = !0
    }
}
class g0 extends Bm {}
async function p0(s, a, l) {
    ti.debug && console.log("@supabase/gotrue-js: navigatorLock: acquire lock", s, a);
    const r = new globalThis.AbortController;
    return a > 0 && setTimeout(() => {
        r.abort(), ti.debug && console.log("@supabase/gotrue-js: navigatorLock acquire timed out", s)
    }, a), await Promise.resolve().then(() => globalThis.navigator.locks.request(s, a === 0 ? {
        mode: "exclusive",
        ifAvailable: !0
    } : {
        mode: "exclusive",
        signal: r.signal
    }, async h => {
        if (h) {
            ti.debug && console.log("@supabase/gotrue-js: navigatorLock: acquired", s, h.name);
            try {
                return await l()
            } finally {
                ti.debug && console.log("@supabase/gotrue-js: navigatorLock: released", s, h.name)
            }
        } else {
            if (a === 0) throw ti.debug && console.log("@supabase/gotrue-js: navigatorLock: not immediately available", s), new g0(`Acquiring an exclusive Navigator LockManager lock "${s}" immediately failed`);
            if (ti.debug) try {
                const d = await globalThis.navigator.locks.query();
                console.log("@supabase/gotrue-js: Navigator LockManager state", JSON.stringify(d, null, "  "))
            } catch (d) {
                console.warn("@supabase/gotrue-js: Error when querying Navigator LockManager state", d)
            }
            return console.warn("@supabase/gotrue-js: Navigator LockManager returned a null lock when using #request without ifAvailable set to true, it appears this browser is not following the LockManager spec https://developer.mozilla.org/en-US/docs/Web/API/LockManager/request"), await l()
        }
    }))
}

function v0() {
    if (typeof globalThis != "object") try {
        Object.defineProperty(Object.prototype, "__magic__", {
            get: function() {
                return this
            },
            configurable: !0
        }), __magic__.globalThis = __magic__, delete Object.prototype.__magic__
    } catch {
        typeof self < "u" && (self.globalThis = self)
    }
}

function qm(s) {
    if (!/^0x[a-fA-F0-9]{40}$/.test(s)) throw new Error(`@supabase/auth-js: Address "${s}" is invalid.`);
    return s.toLowerCase()
}

function y0(s) {
    return parseInt(s, 16)
}

function b0(s) {
    const a = new TextEncoder().encode(s);
    return "0x" + Array.from(a, r => r.toString(16).padStart(2, "0")).join("")
}

function _0(s) {
    var a;
    const {
        chainId: l,
        domain: r,
        expirationTime: h,
        issuedAt: d = new Date,
        nonce: m,
        notBefore: g,
        requestId: y,
        resources: v,
        scheme: _,
        uri: w,
        version: E
    } = s; {
        if (!Number.isInteger(l)) throw new Error(`@supabase/auth-js: Invalid SIWE message field "chainId". Chain ID must be a EIP-155 chain ID. Provided value: ${l}`);
        if (!r) throw new Error('@supabase/auth-js: Invalid SIWE message field "domain". Domain must be provided.');
        if (m && m.length < 8) throw new Error(`@supabase/auth-js: Invalid SIWE message field "nonce". Nonce must be at least 8 characters. Provided value: ${m}`);
        if (!w) throw new Error('@supabase/auth-js: Invalid SIWE message field "uri". URI must be provided.');
        if (E !== "1") throw new Error(`@supabase/auth-js: Invalid SIWE message field "version". Version must be '1'. Provided value: ${E}`);
        if (!((a = s.statement) === null || a === void 0) && a.includes(`
`)) throw new Error(`@supabase/auth-js: Invalid SIWE message field "statement". Statement must not include '\\n'. Provided value: ${s.statement}`)
    }
    const O = qm(s.address),
        k = _ ? `${_}://${r}` : r,
        B = s.statement ? `${s.statement}
` : "",
        L = `${k} wants you to sign in with your Ethereum account:
${O}

${B}`;
    let H = `URI: ${w}
Version: ${E}
Chain ID: ${l}${m?`
Nonce: ${m}`:""}
Issued At: ${d.toISOString()}`;
    if (h && (H += `
Expiration Time: ${h.toISOString()}`), g && (H += `
Not Before: ${g.toISOString()}`), y && (H += `
Request ID: ${y}`), v) {
        let $ = `
Resources:`;
        for (const q of v) {
            if (!q || typeof q != "string") throw new Error(`@supabase/auth-js: Invalid SIWE message field "resources". Every resource must be a valid string. Provided value: ${q}`);
            $ += `
- ${q}`
        }
        H += $
    }
    return `${L}
${H}`
}
class Ge extends Error {
    constructor({
        message: a,
        code: l,
        cause: r,
        name: h
    }) {
        var d;
        super(a, {
            cause: r
        }), this.__isWebAuthnError = !0, this.name = (d = h ? ? (r instanceof Error ? r.name : void 0)) !== null && d !== void 0 ? d : "Unknown Error", this.code = l
    }
}
class Kl extends Ge {
    constructor(a, l) {
        super({
            code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
            cause: l,
            message: a
        }), this.name = "WebAuthnUnknownError", this.originalError = l
    }
}

function j0({
    error: s,
    options: a
}) {
    var l, r, h;
    const {
        publicKey: d
    } = a;
    if (!d) throw Error("options was missing required publicKey property");
    if (s.name === "AbortError") {
        if (a.signal instanceof AbortSignal) return new Ge({
            message: "Registration ceremony was sent an abort signal",
            code: "ERROR_CEREMONY_ABORTED",
            cause: s
        })
    } else if (s.name === "ConstraintError") {
        if (((l = d.authenticatorSelection) === null || l === void 0 ? void 0 : l.requireResidentKey) === !0) return new Ge({
            message: "Discoverable credentials were required but no available authenticator supported it",
            code: "ERROR_AUTHENTICATOR_MISSING_DISCOVERABLE_CREDENTIAL_SUPPORT",
            cause: s
        });
        if (a.mediation === "conditional" && ((r = d.authenticatorSelection) === null || r === void 0 ? void 0 : r.userVerification) === "required") return new Ge({
            message: "User verification was required during automatic registration but it could not be performed",
            code: "ERROR_AUTO_REGISTER_USER_VERIFICATION_FAILURE",
            cause: s
        });
        if (((h = d.authenticatorSelection) === null || h === void 0 ? void 0 : h.userVerification) === "required") return new Ge({
            message: "User verification was required but no available authenticator supported it",
            code: "ERROR_AUTHENTICATOR_MISSING_USER_VERIFICATION_SUPPORT",
            cause: s
        })
    } else {
        if (s.name === "InvalidStateError") return new Ge({
            message: "The authenticator was previously registered",
            code: "ERROR_AUTHENTICATOR_PREVIOUSLY_REGISTERED",
            cause: s
        });
        if (s.name === "NotAllowedError") return new Ge({
            message: s.message,
            code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
            cause: s
        });
        if (s.name === "NotSupportedError") return d.pubKeyCredParams.filter(g => g.type === "public-key").length === 0 ? new Ge({
            message: 'No entry in pubKeyCredParams was of type "public-key"',
            code: "ERROR_MALFORMED_PUBKEYCREDPARAMS",
            cause: s
        }) : new Ge({
            message: "No available authenticator supported any of the specified pubKeyCredParams algorithms",
            code: "ERROR_AUTHENTICATOR_NO_SUPPORTED_PUBKEYCREDPARAMS_ALG",
            cause: s
        });
        if (s.name === "SecurityError") {
            const m = window.location.hostname;
            if (Lm(m)) {
                if (d.rp.id !== m) return new Ge({
                    message: `The RP ID "${d.rp.id}" is invalid for this domain`,
                    code: "ERROR_INVALID_RP_ID",
                    cause: s
                })
            } else return new Ge({
                message: `${window.location.hostname} is an invalid domain`,
                code: "ERROR_INVALID_DOMAIN",
                cause: s
            })
        } else if (s.name === "TypeError") {
            if (d.user.id.byteLength < 1 || d.user.id.byteLength > 64) return new Ge({
                message: "User ID was not between 1 and 64 characters",
                code: "ERROR_INVALID_USER_ID_LENGTH",
                cause: s
            })
        } else if (s.name === "UnknownError") return new Ge({
            message: "The authenticator was unable to process the specified options, or could not create a new credential",
            code: "ERROR_AUTHENTICATOR_GENERAL_ERROR",
            cause: s
        })
    }
    return new Ge({
        message: "a Non-Webauthn related error has occurred",
        code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
        cause: s
    })
}

function S0({
    error: s,
    options: a
}) {
    const {
        publicKey: l
    } = a;
    if (!l) throw Error("options was missing required publicKey property");
    if (s.name === "AbortError") {
        if (a.signal instanceof AbortSignal) return new Ge({
            message: "Authentication ceremony was sent an abort signal",
            code: "ERROR_CEREMONY_ABORTED",
            cause: s
        })
    } else {
        if (s.name === "NotAllowedError") return new Ge({
            message: s.message,
            code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
            cause: s
        });
        if (s.name === "SecurityError") {
            const r = window.location.hostname;
            if (Lm(r)) {
                if (l.rpId !== r) return new Ge({
                    message: `The RP ID "${l.rpId}" is invalid for this domain`,
                    code: "ERROR_INVALID_RP_ID",
                    cause: s
                })
            } else return new Ge({
                message: `${window.location.hostname} is an invalid domain`,
                code: "ERROR_INVALID_DOMAIN",
                cause: s
            })
        } else if (s.name === "UnknownError") return new Ge({
            message: "The authenticator was unable to process the specified options, or could not create a new assertion signature",
            code: "ERROR_AUTHENTICATOR_GENERAL_ERROR",
            cause: s
        })
    }
    return new Ge({
        message: "a Non-Webauthn related error has occurred",
        code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
        cause: s
    })
}
class w0 {
    createNewAbortSignal() {
        if (this.controller) {
            const l = new Error("Cancelling existing WebAuthn API call for new one");
            l.name = "AbortError", this.controller.abort(l)
        }
        const a = new AbortController;
        return this.controller = a, a.signal
    }
    cancelCeremony() {
        if (this.controller) {
            const a = new Error("Manually cancelling existing WebAuthn API call");
            a.name = "AbortError", this.controller.abort(a), this.controller = void 0
        }
    }
}
const x0 = new w0;

function E0(s) {
    if (!s) throw new Error("Credential creation options are required");
    if (typeof PublicKeyCredential < "u" && "parseCreationOptionsFromJSON" in PublicKeyCredential && typeof PublicKeyCredential.parseCreationOptionsFromJSON == "function") return PublicKeyCredential.parseCreationOptionsFromJSON(s);
    const {
        challenge: a,
        user: l,
        excludeCredentials: r
    } = s, h = Yl(s, ["challenge", "user", "excludeCredentials"]), d = ri(a).buffer, m = Object.assign(Object.assign({}, l), {
        id: ri(l.id).buffer
    }), g = Object.assign(Object.assign({}, h), {
        challenge: d,
        user: m
    });
    if (r && r.length > 0) {
        g.excludeCredentials = new Array(r.length);
        for (let y = 0; y < r.length; y++) {
            const v = r[y];
            g.excludeCredentials[y] = Object.assign(Object.assign({}, v), {
                id: ri(v.id).buffer,
                type: v.type || "public-key",
                transports: v.transports
            })
        }
    }
    return g
}

function T0(s) {
    if (!s) throw new Error("Credential request options are required");
    if (typeof PublicKeyCredential < "u" && "parseRequestOptionsFromJSON" in PublicKeyCredential && typeof PublicKeyCredential.parseRequestOptionsFromJSON == "function") return PublicKeyCredential.parseRequestOptionsFromJSON(s);
    const {
        challenge: a,
        allowCredentials: l
    } = s, r = Yl(s, ["challenge", "allowCredentials"]), h = ri(a).buffer, d = Object.assign(Object.assign({}, r), {
        challenge: h
    });
    if (l && l.length > 0) {
        d.allowCredentials = new Array(l.length);
        for (let m = 0; m < l.length; m++) {
            const g = l[m];
            d.allowCredentials[m] = Object.assign(Object.assign({}, g), {
                id: ri(g.id).buffer,
                type: g.type || "public-key",
                transports: g.transports
            })
        }
    }
    return d
}

function A0(s) {
    var a;
    if ("toJSON" in s && typeof s.toJSON == "function") return s.toJSON();
    const l = s;
    return {
        id: s.id,
        rawId: s.id,
        response: {
            attestationObject: ha(new Uint8Array(s.response.attestationObject)),
            clientDataJSON: ha(new Uint8Array(s.response.clientDataJSON))
        },
        type: "public-key",
        clientExtensionResults: s.getClientExtensionResults(),
        authenticatorAttachment: (a = l.authenticatorAttachment) !== null && a !== void 0 ? a : void 0
    }
}

function O0(s) {
    var a;
    if ("toJSON" in s && typeof s.toJSON == "function") return s.toJSON();
    const l = s,
        r = s.getClientExtensionResults(),
        h = s.response;
    return {
        id: s.id,
        rawId: s.id,
        response: {
            authenticatorData: ha(new Uint8Array(h.authenticatorData)),
            clientDataJSON: ha(new Uint8Array(h.clientDataJSON)),
            signature: ha(new Uint8Array(h.signature)),
            userHandle: h.userHandle ? ha(new Uint8Array(h.userHandle)) : void 0
        },
        type: "public-key",
        clientExtensionResults: r,
        authenticatorAttachment: (a = l.authenticatorAttachment) !== null && a !== void 0 ? a : void 0
    }
}

function Lm(s) {
    return s === "localhost" || /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i.test(s)
}

function _m() {
    var s, a;
    return !!(Fe() && "PublicKeyCredential" in window && window.PublicKeyCredential && "credentials" in navigator && typeof((s = navigator ? .credentials) === null || s === void 0 ? void 0 : s.create) == "function" && typeof((a = navigator ? .credentials) === null || a === void 0 ? void 0 : a.get) == "function")
}
async function N0(s) {
    try {
        const a = await navigator.credentials.create(s);
        return a ? a instanceof PublicKeyCredential ? {
            data: a,
            error: null
        } : {
            data: null,
            error: new Kl("Browser returned unexpected credential type", a)
        } : {
            data: null,
            error: new Kl("Empty credential response", a)
        }
    } catch (a) {
        return {
            data: null,
            error: j0({
                error: a,
                options: s
            })
        }
    }
}
async function R0(s) {
    try {
        const a = await navigator.credentials.get(s);
        return a ? a instanceof PublicKeyCredential ? {
            data: a,
            error: null
        } : {
            data: null,
            error: new Kl("Browser returned unexpected credential type", a)
        } : {
            data: null,
            error: new Kl("Empty credential response", a)
        }
    } catch (a) {
        return {
            data: null,
            error: S0({
                error: a,
                options: s
            })
        }
    }
}
const C0 = {
        hints: ["security-key"],
        authenticatorSelection: {
            authenticatorAttachment: "cross-platform",
            requireResidentKey: !1,
            userVerification: "preferred",
            residentKey: "discouraged"
        },
        attestation: "direct"
    },
    D0 = {
        userVerification: "preferred",
        hints: ["security-key"],
        attestation: "direct"
    };

function $l(...s) {
    const a = h => h !== null && typeof h == "object" && !Array.isArray(h),
        l = h => h instanceof ArrayBuffer || ArrayBuffer.isView(h),
        r = {};
    for (const h of s)
        if (h)
            for (const d in h) {
                const m = h[d];
                if (m !== void 0)
                    if (Array.isArray(m)) r[d] = m;
                    else if (l(m)) r[d] = m;
                else if (a(m)) {
                    const g = r[d];
                    a(g) ? r[d] = $l(g, m) : r[d] = $l(m)
                } else r[d] = m
            }
    return r
}

function U0(s, a) {
    return $l(C0, s, a || {})
}

function k0(s, a) {
    return $l(D0, s, a || {})
}
class z0 {
    constructor(a) {
        this.client = a, this.enroll = this._enroll.bind(this), this.challenge = this._challenge.bind(this), this.verify = this._verify.bind(this), this.authenticate = this._authenticate.bind(this), this.register = this._register.bind(this)
    }
    async _enroll(a) {
        return this.client.mfa.enroll(Object.assign(Object.assign({}, a), {
            factorType: "webauthn"
        }))
    }
    async _challenge({
        factorId: a,
        webauthn: l,
        friendlyName: r,
        signal: h
    }, d) {
        var m;
        try {
            const {
                data: g,
                error: y
            } = await this.client.mfa.challenge({
                factorId: a,
                webauthn: l
            });
            if (!g) return {
                data: null,
                error: y
            };
            const v = h ? ? x0.createNewAbortSignal();
            if (g.webauthn.type === "create") {
                const {
                    user: _
                } = g.webauthn.credential_options.publicKey;
                if (!_.name) {
                    const w = r;
                    if (w) _.name = `${_.id}:${w}`;
                    else {
                        const O = (await this.client.getUser()).data.user,
                            k = ((m = O ? .user_metadata) === null || m === void 0 ? void 0 : m.name) || O ? .email || O ? .id || "User";
                        _.name = `${_.id}:${k}`
                    }
                }
                _.displayName || (_.displayName = _.name)
            }
            switch (g.webauthn.type) {
                case "create":
                    {
                        const _ = U0(g.webauthn.credential_options.publicKey, d ? .create),
                            {
                                data: w,
                                error: E
                            } = await N0({
                                publicKey: _,
                                signal: v
                            });
                        return w ? {
                            data: {
                                factorId: a,
                                challengeId: g.id,
                                webauthn: {
                                    type: g.webauthn.type,
                                    credential_response: w
                                }
                            },
                            error: null
                        } : {
                            data: null,
                            error: E
                        }
                    }
                case "request":
                    {
                        const _ = k0(g.webauthn.credential_options.publicKey, d ? .request),
                            {
                                data: w,
                                error: E
                            } = await R0(Object.assign(Object.assign({}, g.webauthn.credential_options), {
                                publicKey: _,
                                signal: v
                            }));
                        return w ? {
                            data: {
                                factorId: a,
                                challengeId: g.id,
                                webauthn: {
                                    type: g.webauthn.type,
                                    credential_response: w
                                }
                            },
                            error: null
                        } : {
                            data: null,
                            error: E
                        }
                    }
            }
        } catch (g) {
            return Q(g) ? {
                data: null,
                error: g
            } : {
                data: null,
                error: new ca("Unexpected error in challenge", g)
            }
        }
    }
    async _verify({
        challengeId: a,
        factorId: l,
        webauthn: r
    }) {
        return this.client.mfa.verify({
            factorId: l,
            challengeId: a,
            webauthn: r
        })
    }
    async _authenticate({
        factorId: a,
        webauthn: {
            rpId: l = typeof window < "u" ? window.location.hostname : void 0,
            rpOrigins: r = typeof window < "u" ? [window.location.origin] : void 0,
            signal: h
        } = {}
    }, d) {
        if (!l) return {
            data: null,
            error: new ds("rpId is required for WebAuthn authentication")
        };
        try {
            if (!_m()) return {
                data: null,
                error: new ca("Browser does not support WebAuthn", null)
            };
            const {
                data: m,
                error: g
            } = await this.challenge({
                factorId: a,
                webauthn: {
                    rpId: l,
                    rpOrigins: r
                },
                signal: h
            }, {
                request: d
            });
            if (!m) return {
                data: null,
                error: g
            };
            const {
                webauthn: y
            } = m;
            return this._verify({
                factorId: a,
                challengeId: m.challengeId,
                webauthn: {
                    type: y.type,
                    rpId: l,
                    rpOrigins: r,
                    credential_response: y.credential_response
                }
            })
        } catch (m) {
            return Q(m) ? {
                data: null,
                error: m
            } : {
                data: null,
                error: new ca("Unexpected error in authenticate", m)
            }
        }
    }
    async _register({
        friendlyName: a,
        webauthn: {
            rpId: l = typeof window < "u" ? window.location.hostname : void 0,
            rpOrigins: r = typeof window < "u" ? [window.location.origin] : void 0,
            signal: h
        } = {}
    }, d) {
        if (!l) return {
            data: null,
            error: new ds("rpId is required for WebAuthn registration")
        };
        try {
            if (!_m()) return {
                data: null,
                error: new ca("Browser does not support WebAuthn", null)
            };
            const {
                data: m,
                error: g
            } = await this._enroll({
                friendlyName: a
            });
            if (!m) return await this.client.mfa.listFactors().then(_ => {
                var w;
                return (w = _.data) === null || w === void 0 ? void 0 : w.all.find(E => E.factor_type === "webauthn" && E.friendly_name === a && E.status !== "unverified")
            }).then(_ => _ ? this.client.mfa.unenroll({
                factorId: _ ? .id
            }) : void 0), {
                data: null,
                error: g
            };
            const {
                data: y,
                error: v
            } = await this._challenge({
                factorId: m.id,
                friendlyName: m.friendly_name,
                webauthn: {
                    rpId: l,
                    rpOrigins: r
                },
                signal: h
            }, {
                create: d
            });
            return y ? this._verify({
                factorId: m.id,
                challengeId: y.challengeId,
                webauthn: {
                    rpId: l,
                    rpOrigins: r,
                    type: y.webauthn.type,
                    credential_response: y.webauthn.credential_response
                }
            }) : {
                data: null,
                error: v
            }
        } catch (m) {
            return Q(m) ? {
                data: null,
                error: m
            } : {
                data: null,
                error: new ca("Unexpected error in register", m)
            }
        }
    }
}
v0();
const M0 = {
    url: Dy,
    storageKey: Uy,
    autoRefreshToken: !0,
    persistSession: !0,
    detectSessionInUrl: !0,
    headers: ky,
    flowType: "implicit",
    debug: !1,
    hasCustomAuthorizationHeader: !1,
    throwOnError: !1,
    lockAcquireTimeout: 1e4
};
async function jm(s, a, l) {
    return await l()
}
const ni = {};
class fs {
    get jwks() {
        var a, l;
        return (l = (a = ni[this.storageKey]) === null || a === void 0 ? void 0 : a.jwks) !== null && l !== void 0 ? l : {
            keys: []
        }
    }
    set jwks(a) {
        ni[this.storageKey] = Object.assign(Object.assign({}, ni[this.storageKey]), {
            jwks: a
        })
    }
    get jwks_cached_at() {
        var a, l;
        return (l = (a = ni[this.storageKey]) === null || a === void 0 ? void 0 : a.cachedAt) !== null && l !== void 0 ? l : Number.MIN_SAFE_INTEGER
    }
    set jwks_cached_at(a) {
        ni[this.storageKey] = Object.assign(Object.assign({}, ni[this.storageKey]), {
            cachedAt: a
        })
    }
    constructor(a) {
        var l, r, h;
        this.userStorage = null, this.memoryStorage = null, this.stateChangeEmitters = new Map, this.autoRefreshTicker = null, this.autoRefreshTickTimeout = null, this.visibilityChangedCallback = null, this.refreshingDeferred = null, this.initializePromise = null, this.detectSessionInUrl = !0, this.hasCustomAuthorizationHeader = !1, this.suppressGetSessionWarning = !1, this.lockAcquired = !1, this.pendingInLock = [], this.broadcastChannel = null, this.logger = console.log;
        const d = Object.assign(Object.assign({}, M0), a);
        if (this.storageKey = d.storageKey, this.instanceID = (l = fs.nextInstanceID[this.storageKey]) !== null && l !== void 0 ? l : 0, fs.nextInstanceID[this.storageKey] = this.instanceID + 1, this.logDebugMessages = !!d.debug, typeof d.debug == "function" && (this.logger = d.debug), this.instanceID > 0 && Fe()) {
            const m = `${this._logPrefix()} Multiple GoTrueClient instances detected in the same browser context. It is not an error, but this should be avoided as it may produce undefined behavior when used concurrently under the same storage key.`;
            console.warn(m), this.logDebugMessages && console.trace(m)
        }
        if (this.persistSession = d.persistSession, this.autoRefreshToken = d.autoRefreshToken, this.admin = new m0({
                url: d.url,
                headers: d.headers,
                fetch: d.fetch
            }), this.url = d.url, this.headers = d.headers, this.fetch = Mm(d.fetch), this.lock = d.lock || jm, this.detectSessionInUrl = d.detectSessionInUrl, this.flowType = d.flowType, this.hasCustomAuthorizationHeader = d.hasCustomAuthorizationHeader, this.throwOnError = d.throwOnError, this.lockAcquireTimeout = d.lockAcquireTimeout, d.lock ? this.lock = d.lock : this.persistSession && Fe() && (!((r = globalThis ? .navigator) === null || r === void 0) && r.locks) ? this.lock = p0 : this.lock = jm, this.jwks || (this.jwks = {
                keys: []
            }, this.jwks_cached_at = Number.MIN_SAFE_INTEGER), this.mfa = {
                verify: this._verify.bind(this),
                enroll: this._enroll.bind(this),
                unenroll: this._unenroll.bind(this),
                challenge: this._challenge.bind(this),
                listFactors: this._listFactors.bind(this),
                challengeAndVerify: this._challengeAndVerify.bind(this),
                getAuthenticatorAssuranceLevel: this._getAuthenticatorAssuranceLevel.bind(this),
                webauthn: new z0(this)
            }, this.oauth = {
                getAuthorizationDetails: this._getAuthorizationDetails.bind(this),
                approveAuthorization: this._approveAuthorization.bind(this),
                denyAuthorization: this._denyAuthorization.bind(this),
                listGrants: this._listOAuthGrants.bind(this),
                revokeGrant: this._revokeOAuthGrant.bind(this)
            }, this.persistSession ? (d.storage ? this.storage = d.storage : zm() ? this.storage = globalThis.localStorage : (this.memoryStorage = {}, this.storage = bm(this.memoryStorage)), d.userStorage && (this.userStorage = d.userStorage)) : (this.memoryStorage = {}, this.storage = bm(this.memoryStorage)), Fe() && globalThis.BroadcastChannel && this.persistSession && this.storageKey) {
            try {
                this.broadcastChannel = new globalThis.BroadcastChannel(this.storageKey)
            } catch (m) {
                console.error("Failed to create a new BroadcastChannel, multi-tab state changes will not be available", m)
            }(h = this.broadcastChannel) === null || h === void 0 || h.addEventListener("message", async m => {
                this._debug("received broadcast notification from other tab or client", m);
                try {
                    await this._notifyAllSubscribers(m.data.event, m.data.session, !1)
                } catch (g) {
                    this._debug("#broadcastChannel", "error", g)
                }
            })
        }
        this.initialize().catch(m => {
            this._debug("#initialize()", "error", m)
        })
    }
    isThrowOnErrorEnabled() {
        return this.throwOnError
    }
    _returnResult(a) {
        if (this.throwOnError && a && a.error) throw a.error;
        return a
    }
    _logPrefix() {
        return `GoTrueClient@${this.storageKey}:${this.instanceID} (${Dm}) ${new Date().toISOString()}`
    }
    _debug(...a) {
        return this.logDebugMessages && this.logger(this._logPrefix(), ...a), this
    }
    async initialize() {
        return this.initializePromise ? await this.initializePromise : (this.initializePromise = (async () => await this._acquireLock(this.lockAcquireTimeout, async () => await this._initialize()))(), await this.initializePromise)
    }
    async _initialize() {
        var a;
        try {
            let l = {},
                r = "none";
            if (Fe() && (l = Jy(window.location.href), this._isImplicitGrantCallback(l) ? r = "implicit" : await this._isPKCECallback(l) && (r = "pkce")), Fe() && this.detectSessionInUrl && r !== "none") {
                const {
                    data: h,
                    error: d
                } = await this._getSessionFromURL(l, r);
                if (d) {
                    if (this._debug("#_initialize()", "error detecting session from URL", d), Ly(d)) {
                        const y = (a = d.details) === null || a === void 0 ? void 0 : a.code;
                        if (y === "identity_already_exists" || y === "identity_not_found" || y === "single_identity_not_deletable") return {
                            error: d
                        }
                    }
                    return {
                        error: d
                    }
                }
                const {
                    session: m,
                    redirectType: g
                } = h;
                return this._debug("#_initialize()", "detected session in URL", m, "redirect type", g), await this._saveSession(m), setTimeout(async () => {
                    g === "recovery" ? await this._notifyAllSubscribers("PASSWORD_RECOVERY", m) : await this._notifyAllSubscribers("SIGNED_IN", m)
                }, 0), {
                    error: null
                }
            }
            return await this._recoverAndRefresh(), {
                error: null
            }
        } catch (l) {
            return Q(l) ? this._returnResult({
                error: l
            }) : this._returnResult({
                error: new ca("Unexpected error during initialization", l)
            })
        } finally {
            await this._handleVisibilityChange(), this._debug("#_initialize()", "end")
        }
    }
    async signInAnonymously(a) {
        var l, r, h;
        try {
            const d = await W(this.fetch, "POST", `${this.url}/signup`, {
                    headers: this.headers,
                    body: {
                        data: (r = (l = a ? .options) === null || l === void 0 ? void 0 : l.data) !== null && r !== void 0 ? r : {},
                        gotrue_meta_security: {
                            captcha_token: (h = a ? .options) === null || h === void 0 ? void 0 : h.captchaToken
                        }
                    },
                    xform: Bt
                }),
                {
                    data: m,
                    error: g
                } = d;
            if (g || !m) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: g
            });
            const y = m.session,
                v = m.user;
            return m.session && (await this._saveSession(m.session), await this._notifyAllSubscribers("SIGNED_IN", y)), this._returnResult({
                data: {
                    user: v,
                    session: y
                },
                error: null
            })
        } catch (d) {
            if (Q(d)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: d
            });
            throw d
        }
    }
    async signUp(a) {
        var l, r, h;
        try {
            let d;
            if ("email" in a) {
                const {
                    email: _,
                    password: w,
                    options: E
                } = a;
                let O = null,
                    k = null;
                this.flowType === "pkce" && ([O, k] = await Fa(this.storage, this.storageKey)), d = await W(this.fetch, "POST", `${this.url}/signup`, {
                    headers: this.headers,
                    redirectTo: E ? .emailRedirectTo,
                    body: {
                        email: _,
                        password: w,
                        data: (l = E ? .data) !== null && l !== void 0 ? l : {},
                        gotrue_meta_security: {
                            captcha_token: E ? .captchaToken
                        },
                        code_challenge: O,
                        code_challenge_method: k
                    },
                    xform: Bt
                })
            } else if ("phone" in a) {
                const {
                    phone: _,
                    password: w,
                    options: E
                } = a;
                d = await W(this.fetch, "POST", `${this.url}/signup`, {
                    headers: this.headers,
                    body: {
                        phone: _,
                        password: w,
                        data: (r = E ? .data) !== null && r !== void 0 ? r : {},
                        channel: (h = E ? .channel) !== null && h !== void 0 ? h : "sms",
                        gotrue_meta_security: {
                            captcha_token: E ? .captchaToken
                        }
                    },
                    xform: Bt
                })
            } else throw new ql("You must provide either an email or phone number and a password");
            const {
                data: m,
                error: g
            } = d;
            if (g || !m) return await We(this.storage, `${this.storageKey}-code-verifier`), this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: g
            });
            const y = m.session,
                v = m.user;
            return m.session && (await this._saveSession(m.session), await this._notifyAllSubscribers("SIGNED_IN", y)), this._returnResult({
                data: {
                    user: v,
                    session: y
                },
                error: null
            })
        } catch (d) {
            if (await We(this.storage, `${this.storageKey}-code-verifier`), Q(d)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: d
            });
            throw d
        }
    }
    async signInWithPassword(a) {
        try {
            let l;
            if ("email" in a) {
                const {
                    email: d,
                    password: m,
                    options: g
                } = a;
                l = await W(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
                    headers: this.headers,
                    body: {
                        email: d,
                        password: m,
                        gotrue_meta_security: {
                            captcha_token: g ? .captchaToken
                        }
                    },
                    xform: vm
                })
            } else if ("phone" in a) {
                const {
                    phone: d,
                    password: m,
                    options: g
                } = a;
                l = await W(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
                    headers: this.headers,
                    body: {
                        phone: d,
                        password: m,
                        gotrue_meta_security: {
                            captcha_token: g ? .captchaToken
                        }
                    },
                    xform: vm
                })
            } else throw new ql("You must provide either an email or phone number and a password");
            const {
                data: r,
                error: h
            } = l;
            if (h) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: h
            });
            if (!r || !r.session || !r.user) {
                const d = new Wa;
                return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: d
                })
            }
            return r.session && (await this._saveSession(r.session), await this._notifyAllSubscribers("SIGNED_IN", r.session)), this._returnResult({
                data: Object.assign({
                    user: r.user,
                    session: r.session
                }, r.weak_password ? {
                    weakPassword: r.weak_password
                } : null),
                error: h
            })
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: l
            });
            throw l
        }
    }
    async signInWithOAuth(a) {
        var l, r, h, d;
        return await this._handleProviderSignIn(a.provider, {
            redirectTo: (l = a.options) === null || l === void 0 ? void 0 : l.redirectTo,
            scopes: (r = a.options) === null || r === void 0 ? void 0 : r.scopes,
            queryParams: (h = a.options) === null || h === void 0 ? void 0 : h.queryParams,
            skipBrowserRedirect: (d = a.options) === null || d === void 0 ? void 0 : d.skipBrowserRedirect
        })
    }
    async exchangeCodeForSession(a) {
        return await this.initializePromise, this._acquireLock(this.lockAcquireTimeout, async () => this._exchangeCodeForSession(a))
    }
    async signInWithWeb3(a) {
        const {
            chain: l
        } = a;
        switch (l) {
            case "ethereum":
                return await this.signInWithEthereum(a);
            case "solana":
                return await this.signInWithSolana(a);
            default:
                throw new Error(`@supabase/auth-js: Unsupported chain "${l}"`)
        }
    }
    async signInWithEthereum(a) {
        var l, r, h, d, m, g, y, v, _, w, E;
        let O, k;
        if ("message" in a) O = a.message, k = a.signature;
        else {
            const {
                chain: B,
                wallet: L,
                statement: H,
                options: $
            } = a;
            let q;
            if (Fe())
                if (typeof L == "object") q = L;
                else {
                    const Me = window;
                    if ("ethereum" in Me && typeof Me.ethereum == "object" && "request" in Me.ethereum && typeof Me.ethereum.request == "function") q = Me.ethereum;
                    else throw new Error("@supabase/auth-js: No compatible Ethereum wallet interface on the window object (window.ethereum) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'ethereum', wallet: resolvedUserWallet }) instead.")
                }
            else {
                if (typeof L != "object" || !$ ? .url) throw new Error("@supabase/auth-js: Both wallet and url must be specified in non-browser environments.");
                q = L
            }
            const I = new URL((l = $ ? .url) !== null && l !== void 0 ? l : window.location.href),
                ye = await q.request({
                    method: "eth_requestAccounts"
                }).then(Me => Me).catch(() => {
                    throw new Error("@supabase/auth-js: Wallet method eth_requestAccounts is missing or invalid")
                });
            if (!ye || ye.length === 0) throw new Error("@supabase/auth-js: No accounts available. Please ensure the wallet is connected.");
            const ie = qm(ye[0]);
            let J = (r = $ ? .signInWithEthereum) === null || r === void 0 ? void 0 : r.chainId;
            if (!J) {
                const Me = await q.request({
                    method: "eth_chainId"
                });
                J = y0(Me)
            }
            const Ne = {
                domain: I.host,
                address: ie,
                statement: H,
                uri: I.href,
                version: "1",
                chainId: J,
                nonce: (h = $ ? .signInWithEthereum) === null || h === void 0 ? void 0 : h.nonce,
                issuedAt: (m = (d = $ ? .signInWithEthereum) === null || d === void 0 ? void 0 : d.issuedAt) !== null && m !== void 0 ? m : new Date,
                expirationTime: (g = $ ? .signInWithEthereum) === null || g === void 0 ? void 0 : g.expirationTime,
                notBefore: (y = $ ? .signInWithEthereum) === null || y === void 0 ? void 0 : y.notBefore,
                requestId: (v = $ ? .signInWithEthereum) === null || v === void 0 ? void 0 : v.requestId,
                resources: (_ = $ ? .signInWithEthereum) === null || _ === void 0 ? void 0 : _.resources
            };
            O = _0(Ne), k = await q.request({
                method: "personal_sign",
                params: [b0(O), ie]
            })
        }
        try {
            const {
                data: B,
                error: L
            } = await W(this.fetch, "POST", `${this.url}/token?grant_type=web3`, {
                headers: this.headers,
                body: Object.assign({
                    chain: "ethereum",
                    message: O,
                    signature: k
                }, !((w = a.options) === null || w === void 0) && w.captchaToken ? {
                    gotrue_meta_security: {
                        captcha_token: (E = a.options) === null || E === void 0 ? void 0 : E.captchaToken
                    }
                } : null),
                xform: Bt
            });
            if (L) throw L;
            if (!B || !B.session || !B.user) {
                const H = new Wa;
                return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: H
                })
            }
            return B.session && (await this._saveSession(B.session), await this._notifyAllSubscribers("SIGNED_IN", B.session)), this._returnResult({
                data: Object.assign({}, B),
                error: L
            })
        } catch (B) {
            if (Q(B)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: B
            });
            throw B
        }
    }
    async signInWithSolana(a) {
        var l, r, h, d, m, g, y, v, _, w, E, O;
        let k, B;
        if ("message" in a) k = a.message, B = a.signature;
        else {
            const {
                chain: L,
                wallet: H,
                statement: $,
                options: q
            } = a;
            let I;
            if (Fe())
                if (typeof H == "object") I = H;
                else {
                    const ie = window;
                    if ("solana" in ie && typeof ie.solana == "object" && ("signIn" in ie.solana && typeof ie.solana.signIn == "function" || "signMessage" in ie.solana && typeof ie.solana.signMessage == "function")) I = ie.solana;
                    else throw new Error("@supabase/auth-js: No compatible Solana wallet interface on the window object (window.solana) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'solana', wallet: resolvedUserWallet }) instead.")
                }
            else {
                if (typeof H != "object" || !q ? .url) throw new Error("@supabase/auth-js: Both wallet and url must be specified in non-browser environments.");
                I = H
            }
            const ye = new URL((l = q ? .url) !== null && l !== void 0 ? l : window.location.href);
            if ("signIn" in I && I.signIn) {
                const ie = await I.signIn(Object.assign(Object.assign(Object.assign({
                    issuedAt: new Date().toISOString()
                }, q ? .signInWithSolana), {
                    version: "1",
                    domain: ye.host,
                    uri: ye.href
                }), $ ? {
                    statement: $
                } : null));
                let J;
                if (Array.isArray(ie) && ie[0] && typeof ie[0] == "object") J = ie[0];
                else if (ie && typeof ie == "object" && "signedMessage" in ie && "signature" in ie) J = ie;
                else throw new Error("@supabase/auth-js: Wallet method signIn() returned unrecognized value");
                if ("signedMessage" in J && "signature" in J && (typeof J.signedMessage == "string" || J.signedMessage instanceof Uint8Array) && J.signature instanceof Uint8Array) k = typeof J.signedMessage == "string" ? J.signedMessage : new TextDecoder().decode(J.signedMessage), B = J.signature;
                else throw new Error("@supabase/auth-js: Wallet method signIn() API returned object without signedMessage and signature fields")
            } else {
                if (!("signMessage" in I) || typeof I.signMessage != "function" || !("publicKey" in I) || typeof I != "object" || !I.publicKey || !("toBase58" in I.publicKey) || typeof I.publicKey.toBase58 != "function") throw new Error("@supabase/auth-js: Wallet does not have a compatible signMessage() and publicKey.toBase58() API");
                k = [`${ye.host} wants you to sign in with your Solana account:`, I.publicKey.toBase58(), ...$ ? ["", $, ""] : [""], "Version: 1", `URI: ${ye.href}`, `Issued At: ${(h=(r=q?.signInWithSolana)===null||r===void 0?void 0:r.issuedAt)!==null&&h!==void 0?h:new Date().toISOString()}`, ...!((d = q ? .signInWithSolana) === null || d === void 0) && d.notBefore ? [`Not Before: ${q.signInWithSolana.notBefore}`] : [], ...!((m = q ? .signInWithSolana) === null || m === void 0) && m.expirationTime ? [`Expiration Time: ${q.signInWithSolana.expirationTime}`] : [], ...!((g = q ? .signInWithSolana) === null || g === void 0) && g.chainId ? [`Chain ID: ${q.signInWithSolana.chainId}`] : [], ...!((y = q ? .signInWithSolana) === null || y === void 0) && y.nonce ? [`Nonce: ${q.signInWithSolana.nonce}`] : [], ...!((v = q ? .signInWithSolana) === null || v === void 0) && v.requestId ? [`Request ID: ${q.signInWithSolana.requestId}`] : [], ...!((w = (_ = q ? .signInWithSolana) === null || _ === void 0 ? void 0 : _.resources) === null || w === void 0) && w.length ? ["Resources", ...q.signInWithSolana.resources.map(J => `- ${J}`)] : []].join(`
`);
                const ie = await I.signMessage(new TextEncoder().encode(k), "utf8");
                if (!ie || !(ie instanceof Uint8Array)) throw new Error("@supabase/auth-js: Wallet signMessage() API returned an recognized value");
                B = ie
            }
        }
        try {
            const {
                data: L,
                error: H
            } = await W(this.fetch, "POST", `${this.url}/token?grant_type=web3`, {
                headers: this.headers,
                body: Object.assign({
                    chain: "solana",
                    message: k,
                    signature: ha(B)
                }, !((E = a.options) === null || E === void 0) && E.captchaToken ? {
                    gotrue_meta_security: {
                        captcha_token: (O = a.options) === null || O === void 0 ? void 0 : O.captchaToken
                    }
                } : null),
                xform: Bt
            });
            if (H) throw H;
            if (!L || !L.session || !L.user) {
                const $ = new Wa;
                return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: $
                })
            }
            return L.session && (await this._saveSession(L.session), await this._notifyAllSubscribers("SIGNED_IN", L.session)), this._returnResult({
                data: Object.assign({}, L),
                error: H
            })
        } catch (L) {
            if (Q(L)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: L
            });
            throw L
        }
    }
    async _exchangeCodeForSession(a) {
        const l = await ra(this.storage, `${this.storageKey}-code-verifier`),
            [r, h] = (l ? ? "").split("/");
        try {
            if (!r && this.flowType === "pkce") throw new Hy;
            const {
                data: d,
                error: m
            } = await W(this.fetch, "POST", `${this.url}/token?grant_type=pkce`, {
                headers: this.headers,
                body: {
                    auth_code: a,
                    code_verifier: r
                },
                xform: Bt
            });
            if (await We(this.storage, `${this.storageKey}-code-verifier`), m) throw m;
            if (!d || !d.session || !d.user) {
                const g = new Wa;
                return this._returnResult({
                    data: {
                        user: null,
                        session: null,
                        redirectType: null
                    },
                    error: g
                })
            }
            return d.session && (await this._saveSession(d.session), await this._notifyAllSubscribers("SIGNED_IN", d.session)), this._returnResult({
                data: Object.assign(Object.assign({}, d), {
                    redirectType: h ? ? null
                }),
                error: m
            })
        } catch (d) {
            if (await We(this.storage, `${this.storageKey}-code-verifier`), Q(d)) return this._returnResult({
                data: {
                    user: null,
                    session: null,
                    redirectType: null
                },
                error: d
            });
            throw d
        }
    }
    async signInWithIdToken(a) {
        try {
            const {
                options: l,
                provider: r,
                token: h,
                access_token: d,
                nonce: m
            } = a, g = await W(this.fetch, "POST", `${this.url}/token?grant_type=id_token`, {
                headers: this.headers,
                body: {
                    provider: r,
                    id_token: h,
                    access_token: d,
                    nonce: m,
                    gotrue_meta_security: {
                        captcha_token: l ? .captchaToken
                    }
                },
                xform: Bt
            }), {
                data: y,
                error: v
            } = g;
            if (v) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: v
            });
            if (!y || !y.session || !y.user) {
                const _ = new Wa;
                return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: _
                })
            }
            return y.session && (await this._saveSession(y.session), await this._notifyAllSubscribers("SIGNED_IN", y.session)), this._returnResult({
                data: y,
                error: v
            })
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: l
            });
            throw l
        }
    }
    async signInWithOtp(a) {
        var l, r, h, d, m;
        try {
            if ("email" in a) {
                const {
                    email: g,
                    options: y
                } = a;
                let v = null,
                    _ = null;
                this.flowType === "pkce" && ([v, _] = await Fa(this.storage, this.storageKey));
                const {
                    error: w
                } = await W(this.fetch, "POST", `${this.url}/otp`, {
                    headers: this.headers,
                    body: {
                        email: g,
                        data: (l = y ? .data) !== null && l !== void 0 ? l : {},
                        create_user: (r = y ? .shouldCreateUser) !== null && r !== void 0 ? r : !0,
                        gotrue_meta_security: {
                            captcha_token: y ? .captchaToken
                        },
                        code_challenge: v,
                        code_challenge_method: _
                    },
                    redirectTo: y ? .emailRedirectTo
                });
                return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: w
                })
            }
            if ("phone" in a) {
                const {
                    phone: g,
                    options: y
                } = a, {
                    data: v,
                    error: _
                } = await W(this.fetch, "POST", `${this.url}/otp`, {
                    headers: this.headers,
                    body: {
                        phone: g,
                        data: (h = y ? .data) !== null && h !== void 0 ? h : {},
                        create_user: (d = y ? .shouldCreateUser) !== null && d !== void 0 ? d : !0,
                        gotrue_meta_security: {
                            captcha_token: y ? .captchaToken
                        },
                        channel: (m = y ? .channel) !== null && m !== void 0 ? m : "sms"
                    }
                });
                return this._returnResult({
                    data: {
                        user: null,
                        session: null,
                        messageId: v ? .message_id
                    },
                    error: _
                })
            }
            throw new ql("You must provide either an email or phone number.")
        } catch (g) {
            if (await We(this.storage, `${this.storageKey}-code-verifier`), Q(g)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: g
            });
            throw g
        }
    }
    async verifyOtp(a) {
        var l, r;
        try {
            let h, d;
            "options" in a && (h = (l = a.options) === null || l === void 0 ? void 0 : l.redirectTo, d = (r = a.options) === null || r === void 0 ? void 0 : r.captchaToken);
            const {
                data: m,
                error: g
            } = await W(this.fetch, "POST", `${this.url}/verify`, {
                headers: this.headers,
                body: Object.assign(Object.assign({}, a), {
                    gotrue_meta_security: {
                        captcha_token: d
                    }
                }),
                redirectTo: h,
                xform: Bt
            });
            if (g) throw g;
            if (!m) throw new Error("An error occurred on token verification.");
            const y = m.session,
                v = m.user;
            return y ? .access_token && (await this._saveSession(y), await this._notifyAllSubscribers(a.type == "recovery" ? "PASSWORD_RECOVERY" : "SIGNED_IN", y)), this._returnResult({
                data: {
                    user: v,
                    session: y
                },
                error: null
            })
        } catch (h) {
            if (Q(h)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: h
            });
            throw h
        }
    }
    async signInWithSSO(a) {
        var l, r, h, d, m;
        try {
            let g = null,
                y = null;
            this.flowType === "pkce" && ([g, y] = await Fa(this.storage, this.storageKey));
            const v = await W(this.fetch, "POST", `${this.url}/sso`, {
                body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, "providerId" in a ? {
                    provider_id: a.providerId
                } : null), "domain" in a ? {
                    domain: a.domain
                } : null), {
                    redirect_to: (r = (l = a.options) === null || l === void 0 ? void 0 : l.redirectTo) !== null && r !== void 0 ? r : void 0
                }), !((h = a ? .options) === null || h === void 0) && h.captchaToken ? {
                    gotrue_meta_security: {
                        captcha_token: a.options.captchaToken
                    }
                } : null), {
                    skip_http_redirect: !0,
                    code_challenge: g,
                    code_challenge_method: y
                }),
                headers: this.headers,
                xform: h0
            });
            return !((d = v.data) === null || d === void 0) && d.url && Fe() && !(!((m = a.options) === null || m === void 0) && m.skipBrowserRedirect) && window.location.assign(v.data.url), this._returnResult(v)
        } catch (g) {
            if (await We(this.storage, `${this.storageKey}-code-verifier`), Q(g)) return this._returnResult({
                data: null,
                error: g
            });
            throw g
        }
    }
    async reauthenticate() {
        return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._reauthenticate())
    }
    async _reauthenticate() {
        try {
            return await this._useSession(async a => {
                const {
                    data: {
                        session: l
                    },
                    error: r
                } = a;
                if (r) throw r;
                if (!l) throw new jt;
                const {
                    error: h
                } = await W(this.fetch, "GET", `${this.url}/reauthenticate`, {
                    headers: this.headers,
                    jwt: l.access_token
                });
                return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: h
                })
            })
        } catch (a) {
            if (Q(a)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: a
            });
            throw a
        }
    }
    async resend(a) {
        try {
            const l = `${this.url}/resend`;
            if ("email" in a) {
                const {
                    email: r,
                    type: h,
                    options: d
                } = a, {
                    error: m
                } = await W(this.fetch, "POST", l, {
                    headers: this.headers,
                    body: {
                        email: r,
                        type: h,
                        gotrue_meta_security: {
                            captcha_token: d ? .captchaToken
                        }
                    },
                    redirectTo: d ? .emailRedirectTo
                });
                return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: m
                })
            } else if ("phone" in a) {
                const {
                    phone: r,
                    type: h,
                    options: d
                } = a, {
                    data: m,
                    error: g
                } = await W(this.fetch, "POST", l, {
                    headers: this.headers,
                    body: {
                        phone: r,
                        type: h,
                        gotrue_meta_security: {
                            captcha_token: d ? .captchaToken
                        }
                    }
                });
                return this._returnResult({
                    data: {
                        user: null,
                        session: null,
                        messageId: m ? .message_id
                    },
                    error: g
                })
            }
            throw new ql("You must provide either an email or phone number and a type")
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: l
            });
            throw l
        }
    }
    async getSession() {
        return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => this._useSession(async l => l))
    }
    async _acquireLock(a, l) {
        this._debug("#_acquireLock", "begin", a);
        try {
            if (this.lockAcquired) {
                const r = this.pendingInLock.length ? this.pendingInLock[this.pendingInLock.length - 1] : Promise.resolve(),
                    h = (async () => (await r, await l()))();
                return this.pendingInLock.push((async () => {
                    try {
                        await h
                    } catch {}
                })()), h
            }
            return await this.lock(`lock:${this.storageKey}`, a, async () => {
                this._debug("#_acquireLock", "lock acquired for storage key", this.storageKey);
                try {
                    this.lockAcquired = !0;
                    const r = l();
                    for (this.pendingInLock.push((async () => {
                            try {
                                await r
                            } catch {}
                        })()), await r; this.pendingInLock.length;) {
                        const h = [...this.pendingInLock];
                        await Promise.all(h), this.pendingInLock.splice(0, h.length)
                    }
                    return await r
                } finally {
                    this._debug("#_acquireLock", "lock released for storage key", this.storageKey), this.lockAcquired = !1
                }
            })
        } finally {
            this._debug("#_acquireLock", "end")
        }
    }
    async _useSession(a) {
        this._debug("#_useSession", "begin");
        try {
            const l = await this.__loadSession();
            return await a(l)
        } finally {
            this._debug("#_useSession", "end")
        }
    }
    async __loadSession() {
        this._debug("#__loadSession()", "begin"), this.lockAcquired || this._debug("#__loadSession()", "used outside of an acquired lock!", new Error().stack);
        try {
            let a = null;
            const l = await ra(this.storage, this.storageKey);
            if (this._debug("#getSession()", "session from storage", l), l !== null && (this._isValidSession(l) ? a = l : (this._debug("#getSession()", "session from storage is not valid"), await this._removeSession())), !a) return {
                data: {
                    session: null
                },
                error: null
            };
            const r = a.expires_at ? a.expires_at * 1e3 - Date.now() < ju : !1;
            if (this._debug("#__loadSession()", `session has${r?"":" not"} expired`, "expires_at", a.expires_at), !r) {
                if (this.userStorage) {
                    const m = await ra(this.userStorage, this.storageKey + "-user");
                    m ? .user ? a.user = m.user : a.user = xu()
                }
                if (this.storage.isServer && a.user && !a.user.__isUserNotAvailableProxy) {
                    const m = {
                        value: this.suppressGetSessionWarning
                    };
                    a.user = r0(a.user, m), m.value && (this.suppressGetSessionWarning = !0)
                }
                return {
                    data: {
                        session: a
                    },
                    error: null
                }
            }
            const {
                data: h,
                error: d
            } = await this._callRefreshToken(a.refresh_token);
            return d ? this._returnResult({
                data: {
                    session: null
                },
                error: d
            }) : this._returnResult({
                data: {
                    session: h
                },
                error: null
            })
        } finally {
            this._debug("#__loadSession()", "end")
        }
    }
    async getUser(a) {
        if (a) return await this._getUser(a);
        await this.initializePromise;
        const l = await this._acquireLock(this.lockAcquireTimeout, async () => await this._getUser());
        return l.data.user && (this.suppressGetSessionWarning = !0), l
    }
    async _getUser(a) {
        try {
            return a ? await W(this.fetch, "GET", `${this.url}/user`, {
                headers: this.headers,
                jwt: a,
                xform: Ln
            }) : await this._useSession(async l => {
                var r, h, d;
                const {
                    data: m,
                    error: g
                } = l;
                if (g) throw g;
                return !(!((r = m.session) === null || r === void 0) && r.access_token) && !this.hasCustomAuthorizationHeader ? {
                    data: {
                        user: null
                    },
                    error: new jt
                } : await W(this.fetch, "GET", `${this.url}/user`, {
                    headers: this.headers,
                    jwt: (d = (h = m.session) === null || h === void 0 ? void 0 : h.access_token) !== null && d !== void 0 ? d : void 0,
                    xform: Ln
                })
            })
        } catch (l) {
            if (Q(l)) return Su(l) && (await this._removeSession(), await We(this.storage, `${this.storageKey}-code-verifier`)), this._returnResult({
                data: {
                    user: null
                },
                error: l
            });
            throw l
        }
    }
    async updateUser(a, l = {}) {
        return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._updateUser(a, l))
    }
    async _updateUser(a, l = {}) {
        try {
            return await this._useSession(async r => {
                const {
                    data: h,
                    error: d
                } = r;
                if (d) throw d;
                if (!h.session) throw new jt;
                const m = h.session;
                let g = null,
                    y = null;
                this.flowType === "pkce" && a.email != null && ([g, y] = await Fa(this.storage, this.storageKey));
                const {
                    data: v,
                    error: _
                } = await W(this.fetch, "PUT", `${this.url}/user`, {
                    headers: this.headers,
                    redirectTo: l ? .emailRedirectTo,
                    body: Object.assign(Object.assign({}, a), {
                        code_challenge: g,
                        code_challenge_method: y
                    }),
                    jwt: m.access_token,
                    xform: Ln
                });
                if (_) throw _;
                return m.user = v.user, await this._saveSession(m), await this._notifyAllSubscribers("USER_UPDATED", m), this._returnResult({
                    data: {
                        user: m.user
                    },
                    error: null
                })
            })
        } catch (r) {
            if (await We(this.storage, `${this.storageKey}-code-verifier`), Q(r)) return this._returnResult({
                data: {
                    user: null
                },
                error: r
            });
            throw r
        }
    }
    async setSession(a) {
        return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._setSession(a))
    }
    async _setSession(a) {
        try {
            if (!a.access_token || !a.refresh_token) throw new jt;
            const l = Date.now() / 1e3;
            let r = l,
                h = !0,
                d = null;
            const {
                payload: m
            } = Hl(a.access_token);
            if (m.exp && (r = m.exp, h = r <= l), h) {
                const {
                    data: g,
                    error: y
                } = await this._callRefreshToken(a.refresh_token);
                if (y) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: y
                });
                if (!g) return {
                    data: {
                        user: null,
                        session: null
                    },
                    error: null
                };
                d = g
            } else {
                const {
                    data: g,
                    error: y
                } = await this._getUser(a.access_token);
                if (y) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: y
                });
                d = {
                    access_token: a.access_token,
                    refresh_token: a.refresh_token,
                    user: g.user,
                    token_type: "bearer",
                    expires_in: r - l,
                    expires_at: r
                }, await this._saveSession(d), await this._notifyAllSubscribers("SIGNED_IN", d)
            }
            return this._returnResult({
                data: {
                    user: d.user,
                    session: d
                },
                error: null
            })
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: {
                    session: null,
                    user: null
                },
                error: l
            });
            throw l
        }
    }
    async refreshSession(a) {
        return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._refreshSession(a))
    }
    async _refreshSession(a) {
        try {
            return await this._useSession(async l => {
                var r;
                if (!a) {
                    const {
                        data: m,
                        error: g
                    } = l;
                    if (g) throw g;
                    a = (r = m.session) !== null && r !== void 0 ? r : void 0
                }
                if (!a ? .refresh_token) throw new jt;
                const {
                    data: h,
                    error: d
                } = await this._callRefreshToken(a.refresh_token);
                return d ? this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: d
                }) : h ? this._returnResult({
                    data: {
                        user: h.user,
                        session: h
                    },
                    error: null
                }) : this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: null
                })
            })
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: {
                    user: null,
                    session: null
                },
                error: l
            });
            throw l
        }
    }
    async _getSessionFromURL(a, l) {
        try {
            if (!Fe()) throw new Ll("No browser detected.");
            if (a.error || a.error_description || a.error_code) throw new Ll(a.error_description || "Error in URL with unspecified error_description", {
                error: a.error || "unspecified_error",
                code: a.error_code || "unspecified_code"
            });
            switch (l) {
                case "implicit":
                    if (this.flowType === "pkce") throw new cm("Not a valid PKCE flow url.");
                    break;
                case "pkce":
                    if (this.flowType === "implicit") throw new Ll("Not a valid implicit grant flow url.");
                    break;
                default:
            }
            if (l === "pkce") {
                if (this._debug("#_initialize()", "begin", "is PKCE flow", !0), !a.code) throw new cm("No code detected.");
                const {
                    data: $,
                    error: q
                } = await this._exchangeCodeForSession(a.code);
                if (q) throw q;
                const I = new URL(window.location.href);
                return I.searchParams.delete("code"), window.history.replaceState(window.history.state, "", I.toString()), {
                    data: {
                        session: $.session,
                        redirectType: null
                    },
                    error: null
                }
            }
            const {
                provider_token: r,
                provider_refresh_token: h,
                access_token: d,
                refresh_token: m,
                expires_in: g,
                expires_at: y,
                token_type: v
            } = a;
            if (!d || !g || !m || !v) throw new Ll("No session defined in URL");
            const _ = Math.round(Date.now() / 1e3),
                w = parseInt(g);
            let E = _ + w;
            y && (E = parseInt(y));
            const O = E - _;
            O * 1e3 <= ii && console.warn(`@supabase/gotrue-js: Session as retrieved from URL expires in ${O}s, should have been closer to ${w}s`);
            const k = E - w;
            _ - k >= 120 ? console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued over 120s ago, URL could be stale", k, E, _) : _ - k < 0 && console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued in the future? Check the device clock for skew", k, E, _);
            const {
                data: B,
                error: L
            } = await this._getUser(d);
            if (L) throw L;
            const H = {
                provider_token: r,
                provider_refresh_token: h,
                access_token: d,
                expires_in: w,
                expires_at: E,
                refresh_token: m,
                token_type: v,
                user: B.user
            };
            return window.location.hash = "", this._debug("#_getSessionFromURL()", "clearing window.location.hash"), this._returnResult({
                data: {
                    session: H,
                    redirectType: a.type
                },
                error: null
            })
        } catch (r) {
            if (Q(r)) return this._returnResult({
                data: {
                    session: null,
                    redirectType: null
                },
                error: r
            });
            throw r
        }
    }
    _isImplicitGrantCallback(a) {
        return typeof this.detectSessionInUrl == "function" ? this.detectSessionInUrl(new URL(window.location.href), a) : !!(a.access_token || a.error_description)
    }
    async _isPKCECallback(a) {
        const l = await ra(this.storage, `${this.storageKey}-code-verifier`);
        return !!(a.code && l)
    }
    async signOut(a = {
        scope: "global"
    }) {
        return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._signOut(a))
    }
    async _signOut({
        scope: a
    } = {
        scope: "global"
    }) {
        return await this._useSession(async l => {
            var r;
            const {
                data: h,
                error: d
            } = l;
            if (d && !Su(d)) return this._returnResult({
                error: d
            });
            const m = (r = h.session) === null || r === void 0 ? void 0 : r.access_token;
            if (m) {
                const {
                    error: g
                } = await this.admin.signOut(m, a);
                if (g && !(qy(g) && (g.status === 404 || g.status === 401 || g.status === 403) || Su(g))) return this._returnResult({
                    error: g
                })
            }
            return a !== "others" && (await this._removeSession(), await We(this.storage, `${this.storageKey}-code-verifier`)), this._returnResult({
                error: null
            })
        })
    }
    onAuthStateChange(a) {
        const l = Qy(),
            r = {
                id: l,
                callback: a,
                unsubscribe: () => {
                    this._debug("#unsubscribe()", "state change callback with id removed", l), this.stateChangeEmitters.delete(l)
                }
            };
        return this._debug("#onAuthStateChange()", "registered callback with id", l), this.stateChangeEmitters.set(l, r), (async () => (await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => {
            this._emitInitialSession(l)
        })))(), {
            data: {
                subscription: r
            }
        }
    }
    async _emitInitialSession(a) {
        return await this._useSession(async l => {
            var r, h;
            try {
                const {
                    data: {
                        session: d
                    },
                    error: m
                } = l;
                if (m) throw m;
                await ((r = this.stateChangeEmitters.get(a)) === null || r === void 0 ? void 0 : r.callback("INITIAL_SESSION", d)), this._debug("INITIAL_SESSION", "callback id", a, "session", d)
            } catch (d) {
                await ((h = this.stateChangeEmitters.get(a)) === null || h === void 0 ? void 0 : h.callback("INITIAL_SESSION", null)), this._debug("INITIAL_SESSION", "callback id", a, "error", d), console.error(d)
            }
        })
    }
    async resetPasswordForEmail(a, l = {}) {
        let r = null,
            h = null;
        this.flowType === "pkce" && ([r, h] = await Fa(this.storage, this.storageKey, !0));
        try {
            return await W(this.fetch, "POST", `${this.url}/recover`, {
                body: {
                    email: a,
                    code_challenge: r,
                    code_challenge_method: h,
                    gotrue_meta_security: {
                        captcha_token: l.captchaToken
                    }
                },
                headers: this.headers,
                redirectTo: l.redirectTo
            })
        } catch (d) {
            if (await We(this.storage, `${this.storageKey}-code-verifier`), Q(d)) return this._returnResult({
                data: null,
                error: d
            });
            throw d
        }
    }
    async getUserIdentities() {
        var a;
        try {
            const {
                data: l,
                error: r
            } = await this.getUser();
            if (r) throw r;
            return this._returnResult({
                data: {
                    identities: (a = l.user.identities) !== null && a !== void 0 ? a : []
                },
                error: null
            })
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: null,
                error: l
            });
            throw l
        }
    }
    async linkIdentity(a) {
        return "token" in a ? this.linkIdentityIdToken(a) : this.linkIdentityOAuth(a)
    }
    async linkIdentityOAuth(a) {
        var l;
        try {
            const {
                data: r,
                error: h
            } = await this._useSession(async d => {
                var m, g, y, v, _;
                const {
                    data: w,
                    error: E
                } = d;
                if (E) throw E;
                const O = await this._getUrlForProvider(`${this.url}/user/identities/authorize`, a.provider, {
                    redirectTo: (m = a.options) === null || m === void 0 ? void 0 : m.redirectTo,
                    scopes: (g = a.options) === null || g === void 0 ? void 0 : g.scopes,
                    queryParams: (y = a.options) === null || y === void 0 ? void 0 : y.queryParams,
                    skipBrowserRedirect: !0
                });
                return await W(this.fetch, "GET", O, {
                    headers: this.headers,
                    jwt: (_ = (v = w.session) === null || v === void 0 ? void 0 : v.access_token) !== null && _ !== void 0 ? _ : void 0
                })
            });
            if (h) throw h;
            return Fe() && !(!((l = a.options) === null || l === void 0) && l.skipBrowserRedirect) && window.location.assign(r ? .url), this._returnResult({
                data: {
                    provider: a.provider,
                    url: r ? .url
                },
                error: null
            })
        } catch (r) {
            if (Q(r)) return this._returnResult({
                data: {
                    provider: a.provider,
                    url: null
                },
                error: r
            });
            throw r
        }
    }
    async linkIdentityIdToken(a) {
        return await this._useSession(async l => {
            var r;
            try {
                const {
                    error: h,
                    data: {
                        session: d
                    }
                } = l;
                if (h) throw h;
                const {
                    options: m,
                    provider: g,
                    token: y,
                    access_token: v,
                    nonce: _
                } = a, w = await W(this.fetch, "POST", `${this.url}/token?grant_type=id_token`, {
                    headers: this.headers,
                    jwt: (r = d ? .access_token) !== null && r !== void 0 ? r : void 0,
                    body: {
                        provider: g,
                        id_token: y,
                        access_token: v,
                        nonce: _,
                        link_identity: !0,
                        gotrue_meta_security: {
                            captcha_token: m ? .captchaToken
                        }
                    },
                    xform: Bt
                }), {
                    data: E,
                    error: O
                } = w;
                return O ? this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: O
                }) : !E || !E.session || !E.user ? this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: new Wa
                }) : (E.session && (await this._saveSession(E.session), await this._notifyAllSubscribers("USER_UPDATED", E.session)), this._returnResult({
                    data: E,
                    error: O
                }))
            } catch (h) {
                if (await We(this.storage, `${this.storageKey}-code-verifier`), Q(h)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: h
                });
                throw h
            }
        })
    }
    async unlinkIdentity(a) {
        try {
            return await this._useSession(async l => {
                var r, h;
                const {
                    data: d,
                    error: m
                } = l;
                if (m) throw m;
                return await W(this.fetch, "DELETE", `${this.url}/user/identities/${a.identity_id}`, {
                    headers: this.headers,
                    jwt: (h = (r = d.session) === null || r === void 0 ? void 0 : r.access_token) !== null && h !== void 0 ? h : void 0
                })
            })
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: null,
                error: l
            });
            throw l
        }
    }
    async _refreshAccessToken(a) {
        const l = `#_refreshAccessToken(${a.substring(0,5)}...)`;
        this._debug(l, "begin");
        try {
            const r = Date.now();
            return await Py(async h => (h > 0 && await Iy(200 * Math.pow(2, h - 1)), this._debug(l, "refreshing attempt", h), await W(this.fetch, "POST", `${this.url}/token?grant_type=refresh_token`, {
                body: {
                    refresh_token: a
                },
                headers: this.headers,
                xform: Bt
            })), (h, d) => {
                const m = 200 * Math.pow(2, h);
                return d && wu(d) && Date.now() + m - r < ii
            })
        } catch (r) {
            if (this._debug(l, "error", r), Q(r)) return this._returnResult({
                data: {
                    session: null,
                    user: null
                },
                error: r
            });
            throw r
        } finally {
            this._debug(l, "end")
        }
    }
    _isValidSession(a) {
        return typeof a == "object" && a !== null && "access_token" in a && "refresh_token" in a && "expires_at" in a
    }
    async _handleProviderSignIn(a, l) {
        const r = await this._getUrlForProvider(`${this.url}/authorize`, a, {
            redirectTo: l.redirectTo,
            scopes: l.scopes,
            queryParams: l.queryParams
        });
        return this._debug("#_handleProviderSignIn()", "provider", a, "options", l, "url", r), Fe() && !l.skipBrowserRedirect && window.location.assign(r), {
            data: {
                provider: a,
                url: r
            },
            error: null
        }
    }
    async _recoverAndRefresh() {
        var a, l;
        const r = "#_recoverAndRefresh()";
        this._debug(r, "begin");
        try {
            const h = await ra(this.storage, this.storageKey);
            if (h && this.userStorage) {
                let m = await ra(this.userStorage, this.storageKey + "-user");
                !this.storage.isServer && Object.is(this.storage, this.userStorage) && !m && (m = {
                    user: h.user
                }, await si(this.userStorage, this.storageKey + "-user", m)), h.user = (a = m ? .user) !== null && a !== void 0 ? a : xu()
            } else if (h && !h.user && !h.user) {
                const m = await ra(this.storage, this.storageKey + "-user");
                m && m ? .user ? (h.user = m.user, await We(this.storage, this.storageKey + "-user"), await si(this.storage, this.storageKey, h)) : h.user = xu()
            }
            if (this._debug(r, "session from storage", h), !this._isValidSession(h)) {
                this._debug(r, "session is not valid"), h !== null && await this._removeSession();
                return
            }
            const d = ((l = h.expires_at) !== null && l !== void 0 ? l : 1 / 0) * 1e3 - Date.now() < ju;
            if (this._debug(r, `session has${d?"":" not"} expired with margin of ${ju}s`), d) {
                if (this.autoRefreshToken && h.refresh_token) {
                    const {
                        error: m
                    } = await this._callRefreshToken(h.refresh_token);
                    m && (console.error(m), wu(m) || (this._debug(r, "refresh failed with a non-retryable error, removing the session", m), await this._removeSession()))
                }
            } else if (h.user && h.user.__isUserNotAvailableProxy === !0) try {
                const {
                    data: m,
                    error: g
                } = await this._getUser(h.access_token);
                !g && m ? .user ? (h.user = m.user, await this._saveSession(h), await this._notifyAllSubscribers("SIGNED_IN", h)) : this._debug(r, "could not get user data, skipping SIGNED_IN notification")
            } catch (m) {
                console.error("Error getting user data:", m), this._debug(r, "error getting user data, skipping SIGNED_IN notification", m)
            } else await this._notifyAllSubscribers("SIGNED_IN", h)
        } catch (h) {
            this._debug(r, "error", h), console.error(h);
            return
        } finally {
            this._debug(r, "end")
        }
    }
    async _callRefreshToken(a) {
        var l, r;
        if (!a) throw new jt;
        if (this.refreshingDeferred) return this.refreshingDeferred.promise;
        const h = `#_callRefreshToken(${a.substring(0,5)}...)`;
        this._debug(h, "begin");
        try {
            this.refreshingDeferred = new Ql;
            const {
                data: d,
                error: m
            } = await this._refreshAccessToken(a);
            if (m) throw m;
            if (!d.session) throw new jt;
            await this._saveSession(d.session), await this._notifyAllSubscribers("TOKEN_REFRESHED", d.session);
            const g = {
                data: d.session,
                error: null
            };
            return this.refreshingDeferred.resolve(g), g
        } catch (d) {
            if (this._debug(h, "error", d), Q(d)) {
                const m = {
                    data: null,
                    error: d
                };
                return wu(d) || await this._removeSession(), (l = this.refreshingDeferred) === null || l === void 0 || l.resolve(m), m
            }
            throw (r = this.refreshingDeferred) === null || r === void 0 || r.reject(d), d
        } finally {
            this.refreshingDeferred = null, this._debug(h, "end")
        }
    }
    async _notifyAllSubscribers(a, l, r = !0) {
        const h = `#_notifyAllSubscribers(${a})`;
        this._debug(h, "begin", l, `broadcast = ${r}`);
        try {
            this.broadcastChannel && r && this.broadcastChannel.postMessage({
                event: a,
                session: l
            });
            const d = [],
                m = Array.from(this.stateChangeEmitters.values()).map(async g => {
                    try {
                        await g.callback(a, l)
                    } catch (y) {
                        d.push(y)
                    }
                });
            if (await Promise.all(m), d.length > 0) {
                for (let g = 0; g < d.length; g += 1) console.error(d[g]);
                throw d[0]
            }
        } finally {
            this._debug(h, "end")
        }
    }
    async _saveSession(a) {
        this._debug("#_saveSession()", a), this.suppressGetSessionWarning = !0, await We(this.storage, `${this.storageKey}-code-verifier`);
        const l = Object.assign({}, a),
            r = l.user && l.user.__isUserNotAvailableProxy === !0;
        if (this.userStorage) {
            !r && l.user && await si(this.userStorage, this.storageKey + "-user", {
                user: l.user
            });
            const h = Object.assign({}, l);
            delete h.user;
            const d = gm(h);
            await si(this.storage, this.storageKey, d)
        } else {
            const h = gm(l);
            await si(this.storage, this.storageKey, h)
        }
    }
    async _removeSession() {
        this._debug("#_removeSession()"), this.suppressGetSessionWarning = !1, await We(this.storage, this.storageKey), await We(this.storage, this.storageKey + "-code-verifier"), await We(this.storage, this.storageKey + "-user"), this.userStorage && await We(this.userStorage, this.storageKey + "-user"), await this._notifyAllSubscribers("SIGNED_OUT", null)
    }
    _removeVisibilityChangedCallback() {
        this._debug("#_removeVisibilityChangedCallback()");
        const a = this.visibilityChangedCallback;
        this.visibilityChangedCallback = null;
        try {
            a && Fe() && window ? .removeEventListener && window.removeEventListener("visibilitychange", a)
        } catch (l) {
            console.error("removing visibilitychange callback failed", l)
        }
    }
    async _startAutoRefresh() {
        await this._stopAutoRefresh(), this._debug("#_startAutoRefresh()");
        const a = setInterval(() => this._autoRefreshTokenTick(), ii);
        this.autoRefreshTicker = a, a && typeof a == "object" && typeof a.unref == "function" ? a.unref() : typeof Deno < "u" && typeof Deno.unrefTimer == "function" && Deno.unrefTimer(a);
        const l = setTimeout(async () => {
            await this.initializePromise, await this._autoRefreshTokenTick()
        }, 0);
        this.autoRefreshTickTimeout = l, l && typeof l == "object" && typeof l.unref == "function" ? l.unref() : typeof Deno < "u" && typeof Deno.unrefTimer == "function" && Deno.unrefTimer(l)
    }
    async _stopAutoRefresh() {
        this._debug("#_stopAutoRefresh()");
        const a = this.autoRefreshTicker;
        this.autoRefreshTicker = null, a && clearInterval(a);
        const l = this.autoRefreshTickTimeout;
        this.autoRefreshTickTimeout = null, l && clearTimeout(l)
    }
    async startAutoRefresh() {
        this._removeVisibilityChangedCallback(), await this._startAutoRefresh()
    }
    async stopAutoRefresh() {
        this._removeVisibilityChangedCallback(), await this._stopAutoRefresh()
    }
    async _autoRefreshTokenTick() {
        this._debug("#_autoRefreshTokenTick()", "begin");
        try {
            await this._acquireLock(0, async () => {
                try {
                    const a = Date.now();
                    try {
                        return await this._useSession(async l => {
                            const {
                                data: {
                                    session: r
                                }
                            } = l;
                            if (!r || !r.refresh_token || !r.expires_at) {
                                this._debug("#_autoRefreshTokenTick()", "no session");
                                return
                            }
                            const h = Math.floor((r.expires_at * 1e3 - a) / ii);
                            this._debug("#_autoRefreshTokenTick()", `access token expires in ${h} ticks, a tick lasts ${ii}ms, refresh threshold is ${Du} ticks`), h <= Du && await this._callRefreshToken(r.refresh_token)
                        })
                    } catch (l) {
                        console.error("Auto refresh tick failed with error. This is likely a transient error.", l)
                    }
                } finally {
                    this._debug("#_autoRefreshTokenTick()", "end")
                }
            })
        } catch (a) {
            if (a.isAcquireTimeout || a instanceof Bm) this._debug("auto refresh token tick lock not available");
            else throw a
        }
    }
    async _handleVisibilityChange() {
        if (this._debug("#_handleVisibilityChange()"), !Fe() || !window ? .addEventListener) return this.autoRefreshToken && this.startAutoRefresh(), !1;
        try {
            this.visibilityChangedCallback = async () => {
                try {
                    await this._onVisibilityChanged(!1)
                } catch (a) {
                    this._debug("#visibilityChangedCallback", "error", a)
                }
            }, window ? .addEventListener("visibilitychange", this.visibilityChangedCallback), await this._onVisibilityChanged(!0)
        } catch (a) {
            console.error("_handleVisibilityChange", a)
        }
    }
    async _onVisibilityChanged(a) {
        const l = `#_onVisibilityChanged(${a})`;
        this._debug(l, "visibilityState", document.visibilityState), document.visibilityState === "visible" ? (this.autoRefreshToken && this._startAutoRefresh(), a || (await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => {
            if (document.visibilityState !== "visible") {
                this._debug(l, "acquired the lock to recover the session, but the browser visibilityState is no longer visible, aborting");
                return
            }
            await this._recoverAndRefresh()
        }))) : document.visibilityState === "hidden" && this.autoRefreshToken && this._stopAutoRefresh()
    }
    async _getUrlForProvider(a, l, r) {
        const h = [`provider=${encodeURIComponent(l)}`];
        if (r ? .redirectTo && h.push(`redirect_to=${encodeURIComponent(r.redirectTo)}`), r ? .scopes && h.push(`scopes=${encodeURIComponent(r.scopes)}`), this.flowType === "pkce") {
            const [d, m] = await Fa(this.storage, this.storageKey), g = new URLSearchParams({
                code_challenge: `${encodeURIComponent(d)}`,
                code_challenge_method: `${encodeURIComponent(m)}`
            });
            h.push(g.toString())
        }
        if (r ? .queryParams) {
            const d = new URLSearchParams(r.queryParams);
            h.push(d.toString())
        }
        return r ? .skipBrowserRedirect && h.push(`skip_http_redirect=${r.skipBrowserRedirect}`), `${a}?${h.join("&")}`
    }
    async _unenroll(a) {
        try {
            return await this._useSession(async l => {
                var r;
                const {
                    data: h,
                    error: d
                } = l;
                return d ? this._returnResult({
                    data: null,
                    error: d
                }) : await W(this.fetch, "DELETE", `${this.url}/factors/${a.factorId}`, {
                    headers: this.headers,
                    jwt: (r = h ? .session) === null || r === void 0 ? void 0 : r.access_token
                })
            })
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: null,
                error: l
            });
            throw l
        }
    }
    async _enroll(a) {
        try {
            return await this._useSession(async l => {
                var r, h;
                const {
                    data: d,
                    error: m
                } = l;
                if (m) return this._returnResult({
                    data: null,
                    error: m
                });
                const g = Object.assign({
                        friendly_name: a.friendlyName,
                        factor_type: a.factorType
                    }, a.factorType === "phone" ? {
                        phone: a.phone
                    } : a.factorType === "totp" ? {
                        issuer: a.issuer
                    } : {}),
                    {
                        data: y,
                        error: v
                    } = await W(this.fetch, "POST", `${this.url}/factors`, {
                        body: g,
                        headers: this.headers,
                        jwt: (r = d ? .session) === null || r === void 0 ? void 0 : r.access_token
                    });
                return v ? this._returnResult({
                    data: null,
                    error: v
                }) : (a.factorType === "totp" && y.type === "totp" && (!((h = y ? .totp) === null || h === void 0) && h.qr_code) && (y.totp.qr_code = `data:image/svg+xml;utf-8,${y.totp.qr_code}`), this._returnResult({
                    data: y,
                    error: null
                }))
            })
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: null,
                error: l
            });
            throw l
        }
    }
    async _verify(a) {
        return this._acquireLock(this.lockAcquireTimeout, async () => {
            try {
                return await this._useSession(async l => {
                    var r;
                    const {
                        data: h,
                        error: d
                    } = l;
                    if (d) return this._returnResult({
                        data: null,
                        error: d
                    });
                    const m = Object.assign({
                            challenge_id: a.challengeId
                        }, "webauthn" in a ? {
                            webauthn: Object.assign(Object.assign({}, a.webauthn), {
                                credential_response: a.webauthn.type === "create" ? A0(a.webauthn.credential_response) : O0(a.webauthn.credential_response)
                            })
                        } : {
                            code: a.code
                        }),
                        {
                            data: g,
                            error: y
                        } = await W(this.fetch, "POST", `${this.url}/factors/${a.factorId}/verify`, {
                            body: m,
                            headers: this.headers,
                            jwt: (r = h ? .session) === null || r === void 0 ? void 0 : r.access_token
                        });
                    return y ? this._returnResult({
                        data: null,
                        error: y
                    }) : (await this._saveSession(Object.assign({
                        expires_at: Math.round(Date.now() / 1e3) + g.expires_in
                    }, g)), await this._notifyAllSubscribers("MFA_CHALLENGE_VERIFIED", g), this._returnResult({
                        data: g,
                        error: y
                    }))
                })
            } catch (l) {
                if (Q(l)) return this._returnResult({
                    data: null,
                    error: l
                });
                throw l
            }
        })
    }
    async _challenge(a) {
        return this._acquireLock(this.lockAcquireTimeout, async () => {
            try {
                return await this._useSession(async l => {
                    var r;
                    const {
                        data: h,
                        error: d
                    } = l;
                    if (d) return this._returnResult({
                        data: null,
                        error: d
                    });
                    const m = await W(this.fetch, "POST", `${this.url}/factors/${a.factorId}/challenge`, {
                        body: a,
                        headers: this.headers,
                        jwt: (r = h ? .session) === null || r === void 0 ? void 0 : r.access_token
                    });
                    if (m.error) return m;
                    const {
                        data: g
                    } = m;
                    if (g.type !== "webauthn") return {
                        data: g,
                        error: null
                    };
                    switch (g.webauthn.type) {
                        case "create":
                            return {
                                data: Object.assign(Object.assign({}, g), {
                                    webauthn: Object.assign(Object.assign({}, g.webauthn), {
                                        credential_options: Object.assign(Object.assign({}, g.webauthn.credential_options), {
                                            publicKey: E0(g.webauthn.credential_options.publicKey)
                                        })
                                    })
                                }),
                                error: null
                            };
                        case "request":
                            return {
                                data: Object.assign(Object.assign({}, g), {
                                    webauthn: Object.assign(Object.assign({}, g.webauthn), {
                                        credential_options: Object.assign(Object.assign({}, g.webauthn.credential_options), {
                                            publicKey: T0(g.webauthn.credential_options.publicKey)
                                        })
                                    })
                                }),
                                error: null
                            }
                    }
                })
            } catch (l) {
                if (Q(l)) return this._returnResult({
                    data: null,
                    error: l
                });
                throw l
            }
        })
    }
    async _challengeAndVerify(a) {
        const {
            data: l,
            error: r
        } = await this._challenge({
            factorId: a.factorId
        });
        return r ? this._returnResult({
            data: null,
            error: r
        }) : await this._verify({
            factorId: a.factorId,
            challengeId: l.id,
            code: a.code
        })
    }
    async _listFactors() {
        var a;
        const {
            data: {
                user: l
            },
            error: r
        } = await this.getUser();
        if (r) return {
            data: null,
            error: r
        };
        const h = {
            all: [],
            phone: [],
            totp: [],
            webauthn: []
        };
        for (const d of (a = l ? .factors) !== null && a !== void 0 ? a : []) h.all.push(d), d.status === "verified" && h[d.factor_type].push(d);
        return {
            data: h,
            error: null
        }
    }
    async _getAuthenticatorAssuranceLevel(a) {
        var l, r, h, d;
        if (a) try {
            const {
                payload: O
            } = Hl(a);
            let k = null;
            O.aal && (k = O.aal);
            let B = k;
            const {
                data: {
                    user: L
                },
                error: H
            } = await this.getUser(a);
            if (H) return this._returnResult({
                data: null,
                error: H
            });
            ((r = (l = L ? .factors) === null || l === void 0 ? void 0 : l.filter(I => I.status === "verified")) !== null && r !== void 0 ? r : []).length > 0 && (B = "aal2");
            const q = O.amr || [];
            return {
                data: {
                    currentLevel: k,
                    nextLevel: B,
                    currentAuthenticationMethods: q
                },
                error: null
            }
        } catch (O) {
            if (Q(O)) return this._returnResult({
                data: null,
                error: O
            });
            throw O
        }
        const {
            data: {
                session: m
            },
            error: g
        } = await this.getSession();
        if (g) return this._returnResult({
            data: null,
            error: g
        });
        if (!m) return {
            data: {
                currentLevel: null,
                nextLevel: null,
                currentAuthenticationMethods: []
            },
            error: null
        };
        const {
            payload: y
        } = Hl(m.access_token);
        let v = null;
        y.aal && (v = y.aal);
        let _ = v;
        ((d = (h = m.user.factors) === null || h === void 0 ? void 0 : h.filter(O => O.status === "verified")) !== null && d !== void 0 ? d : []).length > 0 && (_ = "aal2");
        const E = y.amr || [];
        return {
            data: {
                currentLevel: v,
                nextLevel: _,
                currentAuthenticationMethods: E
            },
            error: null
        }
    }
    async _getAuthorizationDetails(a) {
        try {
            return await this._useSession(async l => {
                const {
                    data: {
                        session: r
                    },
                    error: h
                } = l;
                return h ? this._returnResult({
                    data: null,
                    error: h
                }) : r ? await W(this.fetch, "GET", `${this.url}/oauth/authorizations/${a}`, {
                    headers: this.headers,
                    jwt: r.access_token,
                    xform: d => ({
                        data: d,
                        error: null
                    })
                }) : this._returnResult({
                    data: null,
                    error: new jt
                })
            })
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: null,
                error: l
            });
            throw l
        }
    }
    async _approveAuthorization(a, l) {
        try {
            return await this._useSession(async r => {
                const {
                    data: {
                        session: h
                    },
                    error: d
                } = r;
                if (d) return this._returnResult({
                    data: null,
                    error: d
                });
                if (!h) return this._returnResult({
                    data: null,
                    error: new jt
                });
                const m = await W(this.fetch, "POST", `${this.url}/oauth/authorizations/${a}/consent`, {
                    headers: this.headers,
                    jwt: h.access_token,
                    body: {
                        action: "approve"
                    },
                    xform: g => ({
                        data: g,
                        error: null
                    })
                });
                return m.data && m.data.redirect_url && Fe() && !l ? .skipBrowserRedirect && window.location.assign(m.data.redirect_url), m
            })
        } catch (r) {
            if (Q(r)) return this._returnResult({
                data: null,
                error: r
            });
            throw r
        }
    }
    async _denyAuthorization(a, l) {
        try {
            return await this._useSession(async r => {
                const {
                    data: {
                        session: h
                    },
                    error: d
                } = r;
                if (d) return this._returnResult({
                    data: null,
                    error: d
                });
                if (!h) return this._returnResult({
                    data: null,
                    error: new jt
                });
                const m = await W(this.fetch, "POST", `${this.url}/oauth/authorizations/${a}/consent`, {
                    headers: this.headers,
                    jwt: h.access_token,
                    body: {
                        action: "deny"
                    },
                    xform: g => ({
                        data: g,
                        error: null
                    })
                });
                return m.data && m.data.redirect_url && Fe() && !l ? .skipBrowserRedirect && window.location.assign(m.data.redirect_url), m
            })
        } catch (r) {
            if (Q(r)) return this._returnResult({
                data: null,
                error: r
            });
            throw r
        }
    }
    async _listOAuthGrants() {
        try {
            return await this._useSession(async a => {
                const {
                    data: {
                        session: l
                    },
                    error: r
                } = a;
                return r ? this._returnResult({
                    data: null,
                    error: r
                }) : l ? await W(this.fetch, "GET", `${this.url}/user/oauth/grants`, {
                    headers: this.headers,
                    jwt: l.access_token,
                    xform: h => ({
                        data: h,
                        error: null
                    })
                }) : this._returnResult({
                    data: null,
                    error: new jt
                })
            })
        } catch (a) {
            if (Q(a)) return this._returnResult({
                data: null,
                error: a
            });
            throw a
        }
    }
    async _revokeOAuthGrant(a) {
        try {
            return await this._useSession(async l => {
                const {
                    data: {
                        session: r
                    },
                    error: h
                } = l;
                return h ? this._returnResult({
                    data: null,
                    error: h
                }) : r ? (await W(this.fetch, "DELETE", `${this.url}/user/oauth/grants`, {
                    headers: this.headers,
                    jwt: r.access_token,
                    query: {
                        client_id: a.clientId
                    },
                    noResolveJson: !0
                }), {
                    data: {},
                    error: null
                }) : this._returnResult({
                    data: null,
                    error: new jt
                })
            })
        } catch (l) {
            if (Q(l)) return this._returnResult({
                data: null,
                error: l
            });
            throw l
        }
    }
    async fetchJwk(a, l = {
        keys: []
    }) {
        let r = l.keys.find(g => g.kid === a);
        if (r) return r;
        const h = Date.now();
        if (r = this.jwks.keys.find(g => g.kid === a), r && this.jwks_cached_at + My > h) return r;
        const {
            data: d,
            error: m
        } = await W(this.fetch, "GET", `${this.url}/.well-known/jwks.json`, {
            headers: this.headers
        });
        if (m) throw m;
        return !d.keys || d.keys.length === 0 || (this.jwks = d, this.jwks_cached_at = h, r = d.keys.find(g => g.kid === a), !r) ? null : r
    }
    async getClaims(a, l = {}) {
        try {
            let r = a;
            if (!r) {
                const {
                    data: O,
                    error: k
                } = await this.getSession();
                if (k || !O.session) return this._returnResult({
                    data: null,
                    error: k
                });
                r = O.session.access_token
            }
            const {
                header: h,
                payload: d,
                signature: m,
                raw: {
                    header: g,
                    payload: y
                }
            } = Hl(r);
            l ? .allowExpired || i0(d.exp);
            const v = !h.alg || h.alg.startsWith("HS") || !h.kid || !("crypto" in globalThis && "subtle" in globalThis.crypto) ? null : await this.fetchJwk(h.kid, l ? .keys ? {
                keys: l.keys
            } : l ? .jwks);
            if (!v) {
                const {
                    error: O
                } = await this.getUser(r);
                if (O) throw O;
                return {
                    data: {
                        claims: d,
                        header: h,
                        signature: m
                    },
                    error: null
                }
            }
            const _ = s0(h.alg),
                w = await crypto.subtle.importKey("jwk", v, _, !0, ["verify"]);
            if (!await crypto.subtle.verify(_, w, m, Vy(`${g}.${y}`))) throw new zu("Invalid JWT signature");
            return {
                data: {
                    claims: d,
                    header: h,
                    signature: m
                },
                error: null
            }
        } catch (r) {
            if (Q(r)) return this._returnResult({
                data: null,
                error: r
            });
            throw r
        }
    }
}
fs.nextInstanceID = {};
const B0 = fs,
    q0 = "2.95.3";
let ss = "";
typeof Deno < "u" ? ss = "deno" : typeof document < "u" ? ss = "web" : typeof navigator < "u" && navigator.product === "ReactNative" ? ss = "react-native" : ss = "node";
const L0 = {
        "X-Client-Info": `supabase-js-${ss}/${q0}`
    },
    H0 = {
        headers: L0
    },
    G0 = {
        schema: "public"
    },
    K0 = {
        autoRefreshToken: !0,
        persistSession: !0,
        detectSessionInUrl: !0,
        flowType: "implicit"
    },
    $0 = {};

function ms(s) {
    "@babel/helpers - typeof";
    return ms = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(a) {
        return typeof a
    } : function(a) {
        return a && typeof Symbol == "function" && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
    }, ms(s)
}

function Y0(s, a) {
    if (ms(s) != "object" || !s) return s;
    var l = s[Symbol.toPrimitive];
    if (l !== void 0) {
        var r = l.call(s, a);
        if (ms(r) != "object") return r;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (a === "string" ? String : Number)(s)
}

function V0(s) {
    var a = Y0(s, "string");
    return ms(a) == "symbol" ? a : a + ""
}

function X0(s, a, l) {
    return (a = V0(a)) in s ? Object.defineProperty(s, a, {
        value: l,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : s[a] = l, s
}

function Sm(s, a) {
    var l = Object.keys(s);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(s);
        a && (r = r.filter(function(h) {
            return Object.getOwnPropertyDescriptor(s, h).enumerable
        })), l.push.apply(l, r)
    }
    return l
}

function De(s) {
    for (var a = 1; a < arguments.length; a++) {
        var l = arguments[a] != null ? arguments[a] : {};
        a % 2 ? Sm(Object(l), !0).forEach(function(r) {
            X0(s, r, l[r])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(s, Object.getOwnPropertyDescriptors(l)) : Sm(Object(l)).forEach(function(r) {
            Object.defineProperty(s, r, Object.getOwnPropertyDescriptor(l, r))
        })
    }
    return s
}
const Q0 = s => s ? (...a) => s(...a) : (...a) => fetch(...a),
    J0 = () => Headers,
    Z0 = (s, a, l) => {
        const r = Q0(l),
            h = J0();
        return async (d, m) => {
            var g;
            const y = (g = await a()) !== null && g !== void 0 ? g : s;
            let v = new h(m ? .headers);
            return v.has("apikey") || v.set("apikey", s), v.has("Authorization") || v.set("Authorization", `Bearer ${y}`), r(d, De(De({}, m), {}, {
                headers: v
            }))
        }
    };

function I0(s) {
    return s.endsWith("/") ? s : s + "/"
}

function P0(s, a) {
    var l, r;
    const {
        db: h,
        auth: d,
        realtime: m,
        global: g
    } = s, {
        db: y,
        auth: v,
        realtime: _,
        global: w
    } = a, E = {
        db: De(De({}, y), h),
        auth: De(De({}, v), d),
        realtime: De(De({}, _), m),
        storage: {},
        global: De(De(De({}, w), g), {}, {
            headers: De(De({}, (l = w ? .headers) !== null && l !== void 0 ? l : {}), (r = g ? .headers) !== null && r !== void 0 ? r : {})
        }),
        accessToken: async () => ""
    };
    return s.accessToken ? E.accessToken = s.accessToken : delete E.accessToken, E
}

function W0(s) {
    const a = s ? .trim();
    if (!a) throw new Error("supabaseUrl is required.");
    if (!a.match(/^https?:\/\//i)) throw new Error("Invalid supabaseUrl: Must be a valid HTTP or HTTPS URL.");
    try {
        return new URL(I0(a))
    } catch {
        throw Error("Invalid supabaseUrl: Provided URL is malformed.")
    }
}
var F0 = class extends B0 {
        constructor(s) {
            super(s)
        }
    },
    eb = class {
        constructor(s, a, l) {
            var r, h;
            this.supabaseUrl = s, this.supabaseKey = a;
            const d = W0(s);
            if (!a) throw new Error("supabaseKey is required.");
            this.realtimeUrl = new URL("realtime/v1", d), this.realtimeUrl.protocol = this.realtimeUrl.protocol.replace("http", "ws"), this.authUrl = new URL("auth/v1", d), this.storageUrl = new URL("storage/v1", d), this.functionsUrl = new URL("functions/v1", d);
            const m = `sb-${d.hostname.split(".")[0]}-auth-token`,
                g = {
                    db: G0,
                    realtime: $0,
                    auth: De(De({}, K0), {}, {
                        storageKey: m
                    }),
                    global: H0
                },
                y = P0(l ? ? {}, g);
            if (this.storageKey = (r = y.auth.storageKey) !== null && r !== void 0 ? r : "", this.headers = (h = y.global.headers) !== null && h !== void 0 ? h : {}, y.accessToken) this.accessToken = y.accessToken, this.auth = new Proxy({}, {
                get: (_, w) => {
                    throw new Error(`@supabase/supabase-js: Supabase Client is configured with the accessToken option, accessing supabase.auth.${String(w)} is not possible`)
                }
            });
            else {
                var v;
                this.auth = this._initSupabaseAuthClient((v = y.auth) !== null && v !== void 0 ? v : {}, this.headers, y.global.fetch)
            }
            this.fetch = Z0(a, this._getAccessToken.bind(this), y.global.fetch), this.realtime = this._initRealtimeClient(De({
                headers: this.headers,
                accessToken: this._getAccessToken.bind(this)
            }, y.realtime)), this.accessToken && Promise.resolve(this.accessToken()).then(_ => this.realtime.setAuth(_)).catch(_ => console.warn("Failed to set initial Realtime auth token:", _)), this.rest = new qv(new URL("rest/v1", d).href, {
                headers: this.headers,
                schema: y.db.schema,
                fetch: this.fetch,
                timeout: y.db.timeout,
                urlLengthLimit: y.db.urlLengthLimit
            }), this.storage = new Cy(this.storageUrl.href, this.headers, this.fetch, l ? .storage), y.accessToken || this._listenForAuthEvents()
        }
        get functions() {
            return new Rv(this.functionsUrl.href, {
                headers: this.headers,
                customFetch: this.fetch
            })
        }
        from(s) {
            return this.rest.from(s)
        }
        schema(s) {
            return this.rest.schema(s)
        }
        rpc(s, a = {}, l = {
            head: !1,
            get: !1,
            count: void 0
        }) {
            return this.rest.rpc(s, a, l)
        }
        channel(s, a = {
            config: {}
        }) {
            return this.realtime.channel(s, a)
        }
        getChannels() {
            return this.realtime.getChannels()
        }
        removeChannel(s) {
            return this.realtime.removeChannel(s)
        }
        removeAllChannels() {
            return this.realtime.removeAllChannels()
        }
        async _getAccessToken() {
            var s = this,
                a, l;
            if (s.accessToken) return await s.accessToken();
            const {
                data: r
            } = await s.auth.getSession();
            return (a = (l = r.session) === null || l === void 0 ? void 0 : l.access_token) !== null && a !== void 0 ? a : s.supabaseKey
        }
        _initSupabaseAuthClient({
            autoRefreshToken: s,
            persistSession: a,
            detectSessionInUrl: l,
            storage: r,
            userStorage: h,
            storageKey: d,
            flowType: m,
            lock: g,
            debug: y,
            throwOnError: v
        }, _, w) {
            const E = {
                Authorization: `Bearer ${this.supabaseKey}`,
                apikey: `${this.supabaseKey}`
            };
            return new F0({
                url: this.authUrl.href,
                headers: De(De({}, E), _),
                storageKey: d,
                autoRefreshToken: s,
                persistSession: a,
                detectSessionInUrl: l,
                storage: r,
                userStorage: h,
                flowType: m,
                lock: g,
                debug: y,
                throwOnError: v,
                fetch: w,
                hasCustomAuthorizationHeader: Object.keys(this.headers).some(O => O.toLowerCase() === "authorization")
            })
        }
        _initRealtimeClient(s) {
            return new ty(this.realtimeUrl.href, De(De({}, s), {}, {
                params: De(De({}, {
                    apikey: this.supabaseKey
                }), s ? .params)
            }))
        }
        _listenForAuthEvents() {
            return this.auth.onAuthStateChange((s, a) => {
                this._handleTokenChanged(s, "CLIENT", a ? .access_token)
            })
        }
        _handleTokenChanged(s, a, l) {
            (s === "TOKEN_REFRESHED" || s === "SIGNED_IN") && this.changedAccessToken !== l ? (this.changedAccessToken = l, this.realtime.setAuth(l)) : s === "SIGNED_OUT" && (this.realtime.setAuth(), a == "STORAGE" && this.auth.signOut(), this.changedAccessToken = void 0)
        }
    };
const tb = (s, a, l) => new eb(s, a, l);

function nb() {
    if (typeof window < "u") return !1;
    const s = globalThis.process;
    if (!s) return !1;
    const a = s.version;
    if (a == null) return !1;
    const l = a.match(/^v(\d+)\./);
    return l ? parseInt(l[1], 10) <= 18 : !1
}
nb() && console.warn("⚠️  Node.js 18 and below are deprecated and will no longer be supported in future versions of @supabase/supabase-js. Please upgrade to Node.js 20 or later. For more information, visit: https://github.com/orgs/supabase/discussions/37217");
const ab = "https://kkkrfafifcpmupbfomkj.supabase.co",
    ib = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJib2x0IiwicmVmIjoiMGVjOTBiNTdkNmU5NWZjYmRhMTk4MzJmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4ODE1NzQsImV4cCI6MTc1ODg4MTU3NH0.9I8-U0x86Ak8t2DGaIk0HfvTSLsAyzdnz-Nw00mMkKw",
    Lu = tb(ab, ib);

function sb() {
    const [s, a] = Xe.useState({
        name: "",
        age: "",
        role: "",
        district: "",
        contact_email: "",
        contact_phone: "",
        message: ""
    }), [l, r] = Xe.useState(!1), [h, d] = Xe.useState(!1), [m, g] = Xe.useState(""), y = ["Select a district", "Bangalore Urban", "Bangalore Rural", "Belagavi", "Bellary", "Bidar", "Chikballapur", "Chikmagalur", "Chitradurga", "Davangere", "Dharwad", "Gadag", "Hassan", "Haveri", "Kalaburagi", "Kannur", "Kodagu", "Kolar", "Koppal", "Mandya", "Mangalore", "Mysore", "Raichur", "Ramanagara", "Shimoga", "Tumkur", "Udupi", "Uttara Kannada", "Yadgir"], v = ["Select a role", "Player", "Coach", "Club Administrator", "Volunteer", "Official", "Other"], _ = E => {
        const {
            name: O,
            value: k
        } = E.target;
        a(B => ({ ...B,
            [O]: k
        }))
    }, w = async E => {
        E.preventDefault(), g(""), r(!0);
        try {
            if (s.role === "Select a role" || s.district === "Select a district") {
                g("Please select valid options from dropdowns"), r(!1);
                return
            }
            const {
                error: O
            } = await Lu.from("applications").insert([s]);
            O ? g("Failed to submit application. Please try again.") : (d(!0), a({
                name: "",
                age: "",
                role: "",
                district: "",
                contact_email: "",
                contact_phone: "",
                message: ""
            }), setTimeout(() => d(!1), 5e3))
        } catch {
            g("An error occurred. Please try again.")
        } finally {
            r(!1)
        }
    };
    return u.jsxs("div", {
        className: "join-page",
        children: [u.jsx("section", {
            className: "section join-hero",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsx("h1", {
                    children: "Join Karnataka Minifootball Association"
                }), u.jsx("p", {
                    children: "Be part of our community and help grow minifootball in Karnataka"
                })]
            })
        }), u.jsx("section", {
            className: "section join-content",
            children: u.jsx("div", {
                className: "container",
                children: u.jsxs("div", {
                    className: "join-grid",
                    children: [u.jsxs("div", {
                        className: "join-info",
                        children: [u.jsx("h2", {
                            children: "Why Join KMFA?"
                        }), u.jsxs("div", {
                            className: "benefit",
                            children: [u.jsx("h3", {
                                children: "👥 Community"
                            }), u.jsx("p", {
                                children: "Connect with passionate minifootball enthusiasts across Karnataka"
                            })]
                        }), u.jsxs("div", {
                            className: "benefit",
                            children: [u.jsx("h3", {
                                children: "🏆 Competition"
                            }), u.jsx("p", {
                                children: "Participate in organized tournaments and leagues at various levels"
                            })]
                        }), u.jsxs("div", {
                            className: "benefit",
                            children: [u.jsx("h3", {
                                children: "🎓 Development"
                            }), u.jsx("p", {
                                children: "Access professional coaching and player development programs"
                            })]
                        }), u.jsxs("div", {
                            className: "benefit",
                            children: [u.jsx("h3", {
                                children: "🌟 Recognition"
                            }), u.jsx("p", {
                                children: "Get recognized at state and national minifootball platforms"
                            })]
                        }), u.jsxs("div", {
                            className: "benefit",
                            children: [u.jsx("h3", {
                                children: "🤝 Support"
                            }), u.jsx("p", {
                                children: "Receive support for talent development and career opportunities"
                            })]
                        }), u.jsxs("div", {
                            className: "benefit",
                            children: [u.jsx("h3", {
                                children: "💪 Impact"
                            }), u.jsx("p", {
                                children: "Contribute to grassroots development and community transformation"
                            })]
                        }), u.jsxs("div", {
                            className: "membership-types",
                            children: [u.jsx("h3", {
                                children: "Membership Types"
                            }), u.jsxs("ul", {
                                children: [u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "Individual Players:"
                                    }), " Compete in tournaments and leagues"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "Coaches:"
                                    }), " Lead teams and mentor players"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "Clubs:"
                                    }), " Register as affiliated clubs"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "Volunteers:"
                                    }), " Support KMFA events and programs"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "Officials:"
                                    }), " Referee matches and manage tournaments"]
                                })]
                            })]
                        })]
                    }), u.jsxs("div", {
                        className: "join-form",
                        children: [u.jsx("h2", {
                            children: "Application Form"
                        }), h && u.jsx("div", {
                            className: "alert alert-success",
                            children: "✓ Application submitted successfully! We'll contact you soon."
                        }), m && u.jsxs("div", {
                            className: "alert alert-error",
                            children: ["✗ ", m]
                        }), u.jsxs("form", {
                            onSubmit: w,
                            children: [u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "name",
                                    children: "Full Name *"
                                }), u.jsx("input", {
                                    type: "text",
                                    id: "name",
                                    name: "name",
                                    value: s.name,
                                    onChange: _,
                                    placeholder: "Enter your full name",
                                    required: !0
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "age",
                                    children: "Age *"
                                }), u.jsx("input", {
                                    type: "number",
                                    id: "age",
                                    name: "age",
                                    value: s.age,
                                    onChange: _,
                                    placeholder: "Enter your age",
                                    min: "6",
                                    max: "80",
                                    required: !0
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "role",
                                    children: "Role *"
                                }), u.jsx("select", {
                                    id: "role",
                                    name: "role",
                                    value: s.role,
                                    onChange: _,
                                    required: !0,
                                    children: v.map(E => u.jsx("option", {
                                        value: E,
                                        children: E
                                    }, E))
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "district",
                                    children: "District *"
                                }), u.jsx("select", {
                                    id: "district",
                                    name: "district",
                                    value: s.district,
                                    onChange: _,
                                    required: !0,
                                    children: y.map(E => u.jsx("option", {
                                        value: E,
                                        children: E
                                    }, E))
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "contact_email",
                                    children: "Email Address *"
                                }), u.jsx("input", {
                                    type: "email",
                                    id: "contact_email",
                                    name: "contact_email",
                                    value: s.contact_email,
                                    onChange: _,
                                    placeholder: "your.email@example.com",
                                    required: !0
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "contact_phone",
                                    children: "Phone Number"
                                }), u.jsx("input", {
                                    type: "tel",
                                    id: "contact_phone",
                                    name: "contact_phone",
                                    value: s.contact_phone,
                                    onChange: _,
                                    placeholder: "+91 98765 43210"
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "message",
                                    children: "Additional Information"
                                }), u.jsx("textarea", {
                                    id: "message",
                                    name: "message",
                                    value: s.message,
                                    onChange: _,
                                    placeholder: "Tell us about your minifootball experience, achievements, or goals...",
                                    rows: 4
                                })]
                            }), u.jsx("button", {
                                type: "submit",
                                className: "btn-primary",
                                disabled: l,
                                children: l ? "Submitting..." : "Submit Application"
                            })]
                        }), u.jsxs("div", {
                            className: "form-note",
                            children: [u.jsx("p", {
                                children: "* Required fields"
                            }), u.jsx("p", {
                                children: "We'll review your application and contact you within 7 days."
                            })]
                        })]
                    })]
                })
            })
        })]
    })
}

function lb() {
    const [s, a] = Xe.useState({
        donor_name: "",
        donor_email: "",
        donor_phone: "",
        donation_amount: "",
        donation_purpose: "",
        message: ""
    }), [l, r] = Xe.useState(!1), [h, d] = Xe.useState(!1), [m, g] = Xe.useState(""), y = ["Select purpose", "Grassroots Development", "Youth Programs", "Women Empowerment", "Rural Outreach", "Equipment & Facilities", "Coaching Training", "Scholarships", "General Support"], v = w => {
        const {
            name: E,
            value: O
        } = w.target;
        a(k => ({ ...k,
            [E]: O
        }))
    }, _ = async w => {
        w.preventDefault(), g(""), r(!0);
        try {
            if (s.donation_purpose === "Select purpose") {
                g("Please select a donation purpose"), r(!1);
                return
            }
            const E = parseFloat(s.donation_amount);
            if (isNaN(E) || E <= 0) {
                g("Please enter a valid donation amount"), r(!1);
                return
            }
            const {
                error: O
            } = await Lu.from("donations").insert([{ ...s,
                donation_amount: E
            }]);
            O ? g("Failed to process donation. Please try again.") : (d(!0), a({
                donor_name: "",
                donor_email: "",
                donor_phone: "",
                donation_amount: "",
                donation_purpose: "",
                message: ""
            }), setTimeout(() => d(!1), 5e3))
        } catch {
            g("An error occurred. Please try again.")
        } finally {
            r(!1)
        }
    };
    return u.jsxs("div", {
        className: "donations-page",
        children: [u.jsx("section", {
            className: "section donations-hero",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsx("h1", {
                    children: "Support Our Mission"
                }), u.jsx("p", {
                    children: "Help us build the future of minifootball in Karnataka"
                })]
            })
        }), u.jsx("section", {
            className: "section donations-why",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsxs("div", {
                    className: "section-title",
                    children: [u.jsx("h2", {
                        children: "Why Your Support Matters"
                    }), u.jsx("p", {
                        children: "Your donation directly impacts minifootball development"
                    })]
                }), u.jsxs("div", {
                    className: "impact-grid",
                    children: [u.jsxs("div", {
                        className: "impact-item",
                        children: [u.jsx("h3", {
                            children: "🌱 Grassroots Development"
                        }), u.jsx("p", {
                            children: "Support training programs, equipment, and coaching for young players in rural and urban areas"
                        })]
                    }), u.jsxs("div", {
                        className: "impact-item",
                        children: [u.jsx("h3", {
                            children: "👧 Women Empowerment"
                        }), u.jsx("p", {
                            children: "Enable women and girls to participate in minifootball through dedicated programs and support"
                        })]
                    }), u.jsxs("div", {
                        className: "impact-item",
                        children: [u.jsx("h3", {
                            children: "🏫 School Programs"
                        }), u.jsx("p", {
                            children: "Bring minifootball to 500+ schools across Karnataka, reaching thousands of students"
                        })]
                    }), u.jsxs("div", {
                        className: "impact-item",
                        children: [u.jsx("h3", {
                            children: "🎓 Coaching Training"
                        }), u.jsx("p", {
                            children: "Train certified coaches to deliver professional-quality coaching across the state"
                        })]
                    }), u.jsxs("div", {
                        className: "impact-item",
                        children: [u.jsx("h3", {
                            children: "🤝 Community Events"
                        }), u.jsx("p", {
                            children: "Organize tournaments, leagues, and community engagement programs"
                        })]
                    }), u.jsxs("div", {
                        className: "impact-item",
                        children: [u.jsx("h3", {
                            children: "🌍 Inclusivity"
                        }), u.jsx("p", {
                            children: "Create opportunities for differently-abled athletes and underprivileged communities"
                        })]
                    })]
                })]
            })
        }), u.jsx("section", {
            className: "section donations-content",
            children: u.jsx("div", {
                className: "container",
                children: u.jsxs("div", {
                    className: "donations-grid",
                    children: [u.jsxs("div", {
                        className: "donation-info",
                        children: [u.jsx("h2", {
                            children: "Where Your Money Goes"
                        }), u.jsxs("div", {
                            className: "allocation",
                            children: [u.jsxs("div", {
                                className: "allocation-item",
                                children: [u.jsx("div", {
                                    className: "allocation-bar",
                                    style: {
                                        width: "35%"
                                    }
                                }), u.jsxs("div", {
                                    className: "allocation-label",
                                    children: [u.jsx("span", {
                                        children: "Grassroots & Youth Development"
                                    }), u.jsx("span", {
                                        className: "percentage",
                                        children: "35%"
                                    })]
                                })]
                            }), u.jsxs("div", {
                                className: "allocation-item",
                                children: [u.jsx("div", {
                                    className: "allocation-bar",
                                    style: {
                                        width: "25%"
                                    }
                                }), u.jsxs("div", {
                                    className: "allocation-label",
                                    children: [u.jsx("span", {
                                        children: "Women & Inclusive Programs"
                                    }), u.jsx("span", {
                                        className: "percentage",
                                        children: "25%"
                                    })]
                                })]
                            }), u.jsxs("div", {
                                className: "allocation-item",
                                children: [u.jsx("div", {
                                    className: "allocation-bar",
                                    style: {
                                        width: "20%"
                                    }
                                }), u.jsxs("div", {
                                    className: "allocation-label",
                                    children: [u.jsx("span", {
                                        children: "Coaching & Development"
                                    }), u.jsx("span", {
                                        className: "percentage",
                                        children: "20%"
                                    })]
                                })]
                            }), u.jsxs("div", {
                                className: "allocation-item",
                                children: [u.jsx("div", {
                                    className: "allocation-bar",
                                    style: {
                                        width: "15%"
                                    }
                                }), u.jsxs("div", {
                                    className: "allocation-label",
                                    children: [u.jsx("span", {
                                        children: "Administration & Operations"
                                    }), u.jsx("span", {
                                        className: "percentage",
                                        children: "15%"
                                    })]
                                })]
                            }), u.jsxs("div", {
                                className: "allocation-item",
                                children: [u.jsx("div", {
                                    className: "allocation-bar",
                                    style: {
                                        width: "5%"
                                    }
                                }), u.jsxs("div", {
                                    className: "allocation-label",
                                    children: [u.jsx("span", {
                                        children: "Other Programs"
                                    }), u.jsx("span", {
                                        className: "percentage",
                                        children: "5%"
                                    })]
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "impact-examples",
                            children: [u.jsx("h3", {
                                children: "Your Impact Examples"
                            }), u.jsxs("ul", {
                                children: [u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "₹500:"
                                    }), " Provides coaching for 1 young player for a month"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "₹2,000:"
                                    }), " Supplies equipment for a grassroots team"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "₹5,000:"
                                    }), " Sponsors a rural development tournament"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "₹10,000:"
                                    }), " Trains 5 new coaches"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "₹25,000:"
                                    }), " Supports a complete school program for a year"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "₹50,000+:"
                                    }), " Major program sponsorship or initiative"]
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "donation-methods",
                            children: [u.jsx("h3", {
                                children: "Donation Methods"
                            }), u.jsx("p", {
                                children: "We accept donations through:"
                            }), u.jsxs("ul", {
                                children: [u.jsx("li", {
                                    children: "Bank Transfer"
                                }), u.jsx("li", {
                                    children: "Online Payment Gateways"
                                }), u.jsx("li", {
                                    children: "Cheque/DD"
                                }), u.jsx("li", {
                                    children: "Corporate Sponsorship"
                                })]
                            })]
                        })]
                    }), u.jsxs("div", {
                        className: "donation-form-section",
                        children: [u.jsx("h2", {
                            children: "Make Your Donation"
                        }), h && u.jsx("div", {
                            className: "alert alert-success",
                            children: "✓ Thank you for your donation! We'll send you a confirmation soon."
                        }), m && u.jsxs("div", {
                            className: "alert alert-error",
                            children: ["✗ ", m]
                        }), u.jsxs("form", {
                            onSubmit: _,
                            children: [u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "donor_name",
                                    children: "Full Name *"
                                }), u.jsx("input", {
                                    type: "text",
                                    id: "donor_name",
                                    name: "donor_name",
                                    value: s.donor_name,
                                    onChange: v,
                                    placeholder: "Your name",
                                    required: !0
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "donor_email",
                                    children: "Email Address *"
                                }), u.jsx("input", {
                                    type: "email",
                                    id: "donor_email",
                                    name: "donor_email",
                                    value: s.donor_email,
                                    onChange: v,
                                    placeholder: "your.email@example.com",
                                    required: !0
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "donor_phone",
                                    children: "Phone Number"
                                }), u.jsx("input", {
                                    type: "tel",
                                    id: "donor_phone",
                                    name: "donor_phone",
                                    value: s.donor_phone,
                                    onChange: v,
                                    placeholder: "+91 98765 43210"
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "donation_amount",
                                    children: "Donation Amount (₹) *"
                                }), u.jsx("input", {
                                    type: "number",
                                    id: "donation_amount",
                                    name: "donation_amount",
                                    value: s.donation_amount,
                                    onChange: v,
                                    placeholder: "Enter amount in rupees",
                                    min: "100",
                                    step: "100",
                                    required: !0
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "donation_purpose",
                                    children: "Purpose of Donation *"
                                }), u.jsx("select", {
                                    id: "donation_purpose",
                                    name: "donation_purpose",
                                    value: s.donation_purpose,
                                    onChange: v,
                                    required: !0,
                                    children: y.map(w => u.jsx("option", {
                                        value: w,
                                        children: w
                                    }, w))
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "message",
                                    children: "Message (Optional)"
                                }), u.jsx("textarea", {
                                    id: "message",
                                    name: "message",
                                    value: s.message,
                                    onChange: v,
                                    placeholder: "Share why you support KMFA...",
                                    rows: 3
                                })]
                            }), u.jsx("button", {
                                type: "submit",
                                className: "btn-primary",
                                disabled: l,
                                children: l ? "Processing..." : "Proceed to Donation"
                            })]
                        }), u.jsxs("div", {
                            className: "form-note",
                            children: [u.jsx("p", {
                                children: "* Required fields"
                            }), u.jsx("p", {
                                children: "KMFA is a registered non-profit organization. Donations may be eligible for tax benefits."
                            })]
                        })]
                    })]
                })
            })
        })]
    })
}

function rb() {
    const s = [{
        id: "1",
        title: "State Championship Final",
        category: "Tournaments",
        image: "https://images.pexels.com/photos/8461976/pexels-photo-8461976.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "2",
        title: "Youth Training Session",
        category: "Training",
        image: "https://images.pexels.com/photos/4761863/pexels-photo-4761863.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "3",
        title: "Women's League Match",
        category: "Women",
        image: "https://images.pexels.com/photos/4281890/pexels-photo-4281890.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "4",
        title: "Community Football Festival",
        category: "Community",
        image: "https://images.pexels.com/photos/3355404/pexels-photo-3355404.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "5",
        title: "Rural Outreach Program",
        category: "Outreach",
        image: "https://images.pexels.com/photos/5350060/pexels-photo-5350060.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "6",
        title: "Coaching Workshop",
        category: "Training",
        image: "https://images.pexels.com/photos/3755517/pexels-photo-3755517.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "7",
        title: "School Championship",
        category: "School",
        image: "https://images.pexels.com/photos/3807517/pexels-photo-3807517.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "8",
        title: "Team Celebration",
        category: "Tournaments",
        image: "https://images.pexels.com/photos/3808617/pexels-photo-3808617.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "9",
        title: "Young Players Development",
        category: "Youth",
        image: "https://images.pexels.com/photos/5632397/pexels-photo-5632397.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "10",
        title: "District League Finals",
        category: "Tournaments",
        image: "https://images.pexels.com/photos/6741698/pexels-photo-6741698.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "11",
        title: "Women Empowerment Program",
        category: "Women",
        image: "https://images.pexels.com/photos/4282622/pexels-photo-4282622.jpeg?auto=compress&cs=tinysrgb&w=600"
    }, {
        id: "12",
        title: "Grassroots Development",
        category: "Training",
        image: "https://images.pexels.com/photos/3945683/pexels-photo-3945683.jpeg?auto=compress&cs=tinysrgb&w=600"
    }];
    return u.jsxs("div", {
        className: "gallery-page",
        children: [u.jsx("section", {
            className: "section gallery-hero",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsx("h1", {
                    children: "Gallery"
                }), u.jsx("p", {
                    children: "Moments from our tournaments, events, and community programs"
                })]
            })
        }), u.jsx("section", {
            className: "section gallery-content",
            children: u.jsx("div", {
                className: "container",
                children: u.jsx("div", {
                    className: "gallery-grid",
                    children: s.map(a => u.jsxs("div", {
                        className: "gallery-item",
                        children: [u.jsxs("div", {
                            className: "gallery-image",
                            children: [u.jsx("img", {
                                src: a.image,
                                alt: a.title
                            }), u.jsx("div", {
                                className: "gallery-overlay",
                                children: u.jsx("span", {
                                    className: "category-badge",
                                    children: a.category
                                })
                            })]
                        }), u.jsx("div", {
                            className: "gallery-info",
                            children: u.jsx("h3", {
                                children: a.title
                            })
                        })]
                    }, a.id))
                })
            })
        }), u.jsx("section", {
            className: "section gallery-albums",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsxs("div", {
                    className: "section-title",
                    children: [u.jsx("h2", {
                        children: "Photo Albums"
                    }), u.jsx("p", {
                        children: "Organized collections of our events and programs"
                    })]
                }), u.jsxs("div", {
                    className: "albums-grid",
                    children: [u.jsxs("div", {
                        className: "album-card",
                        children: [u.jsx("img", {
                            src: "https://images.pexels.com/photos/8461976/pexels-photo-8461976.jpeg?auto=compress&cs=tinysrgb&w=600",
                            alt: "State Championship"
                        }), u.jsx("h3", {
                            children: "State Championship 2024"
                        }), u.jsx("p", {
                            children: "32 teams • 500+ players • 10 districts"
                        })]
                    }), u.jsxs("div", {
                        className: "album-card",
                        children: [u.jsx("img", {
                            src: "https://images.pexels.com/photos/4761863/pexels-photo-4761863.jpeg?auto=compress&cs=tinysrgb&w=600",
                            alt: "Youth Programs"
                        }), u.jsx("h3", {
                            children: "Youth Development Programs"
                        }), u.jsx("p", {
                            children: "Training camps • Coaching clinics • Talent showcase"
                        })]
                    }), u.jsxs("div", {
                        className: "album-card",
                        children: [u.jsx("img", {
                            src: "https://images.pexels.com/photos/4281890/pexels-photo-4281890.jpeg?auto=compress&cs=tinysrgb&w=600",
                            alt: "Women's League"
                        }), u.jsx("h3", {
                            children: "Women's Minifootball League"
                        }), u.jsx("p", {
                            children: "24 teams • Professional standards • Gender inclusivity"
                        })]
                    }), u.jsxs("div", {
                        className: "album-card",
                        children: [u.jsx("img", {
                            src: "https://images.pexels.com/photos/3355404/pexels-photo-3355404.jpeg?auto=compress&cs=tinysrgb&w=600",
                            alt: "Community Events"
                        }), u.jsx("h3", {
                            children: "Community Events"
                        }), u.jsx("p", {
                            children: "Grassroots tournaments • Outreach programs • Festivals"
                        })]
                    })]
                })]
            })
        })]
    })
}

function ob() {
    return u.jsxs("div", {
        className: "governance-page",
        children: [u.jsx("section", {
            className: "section governance-hero",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsx("h1", {
                    children: "Governance & Management"
                }), u.jsx("p", {
                    children: "Our commitment to transparency, ethics, and fair governance"
                })]
            })
        }), u.jsx("section", {
            className: "section governance-content",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsxs("div", {
                    className: "governance-section",
                    children: [u.jsx("h2", {
                        children: "Governance Structure"
                    }), u.jsx("p", {
                        children: "KMFA operates under a transparent governance framework designed to ensure accountability, inclusivity, and fair decision-making at all levels."
                    }), u.jsx("div", {
                        className: "structure-chart",
                        children: u.jsxs("div", {
                            className: "org-hierarchy",
                            children: [u.jsx("div", {
                                className: "level",
                                children: u.jsxs("div", {
                                    className: "position",
                                    children: [u.jsx("strong", {
                                        children: "General Assembly"
                                    }), u.jsx("p", {
                                        children: "All Members"
                                    })]
                                })
                            }), u.jsx("div", {
                                className: "connector"
                            }), u.jsx("div", {
                                className: "level",
                                children: u.jsxs("div", {
                                    className: "position",
                                    children: [u.jsx("strong", {
                                        children: "Executive Board"
                                    }), u.jsx("p", {
                                        children: "President • Vice President • Secretary • Treasurer"
                                    })]
                                })
                            }), u.jsx("div", {
                                className: "connector"
                            }), u.jsxs("div", {
                                className: "level grid-3",
                                children: [u.jsxs("div", {
                                    className: "position",
                                    children: [u.jsx("strong", {
                                        children: "Sports Committee"
                                    }), u.jsx("p", {
                                        children: "Tournament Management"
                                    })]
                                }), u.jsxs("div", {
                                    className: "position",
                                    children: [u.jsx("strong", {
                                        children: "Development Committee"
                                    }), u.jsx("p", {
                                        children: "Player & Coach Development"
                                    })]
                                }), u.jsxs("div", {
                                    className: "position",
                                    children: [u.jsx("strong", {
                                        children: "Ethics Committee"
                                    }), u.jsx("p", {
                                        children: "Fair Play & Compliance"
                                    })]
                                })]
                            })]
                        })
                    })]
                }), u.jsxs("div", {
                    className: "governance-section",
                    children: [u.jsx("h2", {
                        children: "Code of Conduct"
                    }), u.jsxs("div", {
                        className: "code-content",
                        children: [u.jsx("h3", {
                            children: "For All Members"
                        }), u.jsxs("ul", {
                            children: [u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Respect:"
                                }), " Treat all participants with dignity and respect"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Integrity:"
                                }), " Act with honesty and transparency in all dealings"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Compliance:"
                                }), " Follow all KMFA rules and FIFA Laws of the Game"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Fair Play:"
                                }), " Promote positive competition and reject cheating or violence"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Inclusivity:"
                                }), " Welcome all individuals regardless of background, gender, or ability"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Responsibility:"
                                }), " Take accountability for actions and decisions"]
                            })]
                        }), u.jsx("h3", {
                            children: "For Players"
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Maintain professional conduct on and off the field"
                            }), u.jsx("li", {
                                children: "Respect referees' decisions and opposition players"
                            }), u.jsx("li", {
                                children: "Refuse to engage in match-fixing, doping, or other violations"
                            }), u.jsx("li", {
                                children: "Represent your club and KMFA with honor"
                            })]
                        }), u.jsx("h3", {
                            children: "For Coaches"
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Provide quality, ethical coaching and mentorship"
                            }), u.jsx("li", {
                                children: "Prioritize player welfare and development"
                            }), u.jsx("li", {
                                children: "Maintain confidentiality of sensitive player information"
                            }), u.jsx("li", {
                                children: "Model professional behavior and fair play principles"
                            })]
                        }), u.jsx("h3", {
                            children: "For Officials"
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Apply rules fairly and consistently"
                            }), u.jsx("li", {
                                children: "Maintain independence and impartiality"
                            }), u.jsx("li", {
                                children: "Avoid conflicts of interest"
                            }), u.jsx("li", {
                                children: "Make decisions based solely on the Laws of the Game"
                            })]
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "governance-section",
                    children: [u.jsx("h2", {
                        children: "Fair Play & Transparency Principles"
                    }), u.jsxs("div", {
                        className: "principles-grid",
                        children: [u.jsxs("div", {
                            className: "principle-card",
                            children: [u.jsx("h3", {
                                children: "Transparency"
                            }), u.jsx("p", {
                                children: "All decisions, rules, and financial matters are communicated clearly to members and stakeholders"
                            })]
                        }), u.jsxs("div", {
                            className: "principle-card",
                            children: [u.jsx("h3", {
                                children: "Accountability"
                            }), u.jsx("p", {
                                children: "Leadership is answerable to the membership for actions and decisions"
                            })]
                        }), u.jsxs("div", {
                            className: "principle-card",
                            children: [u.jsx("h3", {
                                children: "Fairness"
                            }), u.jsx("p", {
                                children: "All competitions are conducted on level playing fields with equal opportunities for success"
                            })]
                        }), u.jsxs("div", {
                            className: "principle-card",
                            children: [u.jsx("h3", {
                                children: "Inclusivity"
                            }), u.jsx("p", {
                                children: "Governance structure includes representation from diverse backgrounds and perspectives"
                            })]
                        }), u.jsxs("div", {
                            className: "principle-card",
                            children: [u.jsx("h3", {
                                children: "Integrity"
                            }), u.jsx("p", {
                                children: "All officials, coaches, and members uphold highest standards of ethical conduct"
                            })]
                        }), u.jsxs("div", {
                            className: "principle-card",
                            children: [u.jsx("h3", {
                                children: "Democratic"
                            }), u.jsx("p", {
                                children: "Decisions are made through democratic processes with member participation"
                            })]
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "governance-section",
                    children: [u.jsx("h2", {
                        children: "Ethics & Compliance"
                    }), u.jsxs("div", {
                        className: "ethics-content",
                        children: [u.jsx("h3", {
                            children: "Anti-Corruption Measures"
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Zero tolerance policy for match-fixing and financial manipulation"
                            }), u.jsx("li", {
                                children: "Independent Ethics Committee to investigate violations"
                            }), u.jsx("li", {
                                children: "Confidential reporting mechanism for misconduct"
                            }), u.jsx("li", {
                                children: "Appropriate penalties for violations"
                            })]
                        }), u.jsx("h3", {
                            children: "Safeguarding Policies"
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Child protection and welfare policies"
                            }), u.jsx("li", {
                                children: "Background checks for coaches and officials working with minors"
                            }), u.jsx("li", {
                                children: "Training in safeguarding for all staff and volunteers"
                            }), u.jsx("li", {
                                children: "Clear grievance procedures for reporting concerns"
                            })]
                        }), u.jsx("h3", {
                            children: "Anti-Discrimination Policy"
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Zero tolerance for discrimination based on gender, caste, religion, or ability"
                            }), u.jsx("li", {
                                children: "Equal opportunities for all in membership, competition, and leadership"
                            }), u.jsx("li", {
                                children: "Mechanisms to address discrimination complaints"
                            }), u.jsx("li", {
                                children: "Regular diversity and inclusion awareness programs"
                            })]
                        }), u.jsx("h3", {
                            children: "Financial Management"
                        }), u.jsxs("ul", {
                            children: [u.jsx("li", {
                                children: "Regular audits of all financial transactions"
                            }), u.jsx("li", {
                                children: "Transparent budget planning and allocation"
                            }), u.jsx("li", {
                                children: "Public disclosure of financial reports"
                            }), u.jsx("li", {
                                children: "Anti-money laundering compliance"
                            })]
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "governance-section",
                    children: [u.jsx("h2", {
                        children: "Dispute Resolution"
                    }), u.jsxs("div", {
                        className: "dispute-process",
                        children: [u.jsx("h3", {
                            children: "Process for Resolving Disputes"
                        }), u.jsxs("ol", {
                            children: [u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Informal Resolution:"
                                }), " Attempt amicable settlement between parties"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Formal Complaint:"
                                }), " Submit written complaint to Disputes Committee"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Investigation:"
                                }), " Fair and impartial investigation of claims"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Hearing:"
                                }), " Opportunity for both parties to present their case"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Decision:"
                                }), " Fair judgment based on KMFA rules and regulations"]
                            }), u.jsxs("li", {
                                children: [u.jsx("strong", {
                                    children: "Appeal:"
                                }), " Right to appeal to Executive Board"]
                            })]
                        }), u.jsx("h3", {
                            children: "Appeals Process"
                        }), u.jsx("p", {
                            children: "Members have the right to appeal any decision through proper channels. Appeals must be filed within 30 days of the original decision and will be reviewed by an independent Appeals Panel."
                        })]
                    })]
                }), u.jsxs("div", {
                    className: "governance-section",
                    children: [u.jsx("h2", {
                        children: "Annual Reporting & Transparency"
                    }), u.jsxs("ul", {
                        children: [u.jsx("li", {
                            children: "Annual General Meeting with full membership participation"
                        }), u.jsx("li", {
                            children: "Published annual reports detailing activities and achievements"
                        }), u.jsx("li", {
                            children: "Financial statements audited by independent auditors"
                        }), u.jsx("li", {
                            children: "Member feedback and suggestions actively sought and considered"
                        }), u.jsx("li", {
                            children: "Regular communication updates to all stakeholders"
                        })]
                    })]
                })]
            })
        })]
    })
}

function ub() {
    const [s, a] = Xe.useState({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: "",
        inquiry_type: ""
    }), [l, r] = Xe.useState(!1), [h, d] = Xe.useState(!1), [m, g] = Xe.useState(""), y = ["Select inquiry type", "General Query", "Membership", "Sponsorship", "Event Registration", "Complaint", "Other"], v = w => {
        const {
            name: E,
            value: O
        } = w.target;
        a(k => ({ ...k,
            [E]: O
        }))
    }, _ = async w => {
        w.preventDefault(), g(""), r(!0);
        try {
            if (s.inquiry_type === "Select inquiry type") {
                g("Please select an inquiry type"), r(!1);
                return
            }
            const {
                error: E
            } = await Lu.from("contact_messages").insert([s]);
            E ? g("Failed to send message. Please try again.") : (d(!0), a({
                name: "",
                email: "",
                phone: "",
                subject: "",
                message: "",
                inquiry_type: ""
            }), setTimeout(() => d(!1), 5e3))
        } catch {
            g("An error occurred. Please try again.")
        } finally {
            r(!1)
        }
    };
    return u.jsxs("div", {
        className: "contact-page",
        children: [u.jsx("section", {
            className: "section contact-hero",
            children: u.jsxs("div", {
                className: "container",
                children: [u.jsx("h1", {
                    children: "Contact Us"
                }), u.jsx("p", {
                    children: "Get in touch with Karnataka Minifootball Association"
                })]
            })
        }), u.jsx("section", {
            className: "section contact-content",
            children: u.jsx("div", {
                className: "container",
                children: u.jsxs("div", {
                    className: "contact-grid",
                    children: [u.jsxs("div", {
                        className: "contact-info",
                        children: [u.jsx("h2", {
                            children: "Get in Touch"
                        }), u.jsxs("div", {
                            className: "contact-method",
                            children: [u.jsx("h3", {
                                children: "📍 Address"
                            }), u.jsx("p", {
                                children: "Karnataka, India"
                            })]
                        }), u.jsxs("div", {
                            className: "contact-method",
                            children: [u.jsx("h3", {
                                children: "📞 Phone"
                            }), u.jsx("p", {
                                children: "+91 XXXXX XXXXX"
                            }), u.jsx("p", {
                                className: "time-note",
                                children: "Monday - Friday: 10 AM - 6 PM IST"
                            })]
                        }), u.jsxs("div", {
                            className: "contact-method",
                            children: [u.jsx("h3", {
                                children: "📧 Email"
                            }), u.jsx("p", {
                                children: u.jsx("a", {
                                    href: "mailto:info@kmfa.org",
                                    children: "info@kmfa.org"
                                })
                            }), u.jsx("p", {
                                className: "time-note",
                                children: "Response within 24 hours"
                            })]
                        }), u.jsxs("div", {
                            className: "contact-method",
                            children: [u.jsx("h3", {
                                children: "🎯 Different Departments"
                            }), u.jsxs("ul", {
                                children: [u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "General Queries:"
                                    }), " info@kmfa.org"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "Membership:"
                                    }), " membership@kmfa.org"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "Events & Tournaments:"
                                    }), " events@kmfa.org"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "Sponsorship:"
                                    }), " sponsors@kmfa.org"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "Development Programs:"
                                    }), " development@kmfa.org"]
                                }), u.jsxs("li", {
                                    children: [u.jsx("strong", {
                                        children: "Complaints:"
                                    }), " compliance@kmfa.org"]
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "contact-method",
                            children: [u.jsx("h3", {
                                children: "🌐 Follow Us"
                            }), u.jsxs("div", {
                                className: "social-links",
                                children: [u.jsx("a", {
                                    href: "#",
                                    children: "Facebook"
                                }), u.jsx("a", {
                                    href: "#",
                                    children: "Twitter"
                                }), u.jsx("a", {
                                    href: "#",
                                    children: "Instagram"
                                }), u.jsx("a", {
                                    href: "#",
                                    children: "LinkedIn"
                                })]
                            })]
                        }), u.jsxs("div", {
                            className: "contact-hours",
                            children: [u.jsx("h3", {
                                children: "⏰ Office Hours"
                            }), u.jsxs("ul", {
                                children: [u.jsx("li", {
                                    children: "Monday - Friday: 10:00 AM - 6:00 PM"
                                }), u.jsx("li", {
                                    children: "Saturday: 10:00 AM - 4:00 PM"
                                }), u.jsx("li", {
                                    children: "Sunday: Closed"
                                }), u.jsx("li", {
                                    children: "Public Holidays: Closed"
                                })]
                            })]
                        })]
                    }), u.jsxs("div", {
                        className: "contact-form",
                        children: [u.jsx("h2", {
                            children: "Send us a Message"
                        }), h && u.jsx("div", {
                            className: "alert alert-success",
                            children: "✓ Message sent successfully! We'll respond soon."
                        }), m && u.jsxs("div", {
                            className: "alert alert-error",
                            children: ["✗ ", m]
                        }), u.jsxs("form", {
                            onSubmit: _,
                            children: [u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "name",
                                    children: "Full Name *"
                                }), u.jsx("input", {
                                    type: "text",
                                    id: "name",
                                    name: "name",
                                    value: s.name,
                                    onChange: v,
                                    placeholder: "Your name",
                                    required: !0
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "email",
                                    children: "Email Address *"
                                }), u.jsx("input", {
                                    type: "email",
                                    id: "email",
                                    name: "email",
                                    value: s.email,
                                    onChange: v,
                                    placeholder: "your.email@example.com",
                                    required: !0
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "phone",
                                    children: "Phone Number"
                                }), u.jsx("input", {
                                    type: "tel",
                                    id: "phone",
                                    name: "phone",
                                    value: s.phone,
                                    onChange: v,
                                    placeholder: "+91 98765 43210"
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "inquiry_type",
                                    children: "Inquiry Type *"
                                }), u.jsx("select", {
                                    id: "inquiry_type",
                                    name: "inquiry_type",
                                    value: s.inquiry_type,
                                    onChange: v,
                                    required: !0,
                                    children: y.map(w => u.jsx("option", {
                                        value: w,
                                        children: w
                                    }, w))
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "subject",
                                    children: "Subject *"
                                }), u.jsx("input", {
                                    type: "text",
                                    id: "subject",
                                    name: "subject",
                                    value: s.subject,
                                    onChange: v,
                                    placeholder: "Message subject",
                                    required: !0
                                })]
                            }), u.jsxs("div", {
                                className: "form-group",
                                children: [u.jsx("label", {
                                    htmlFor: "message",
                                    children: "Message *"
                                }), u.jsx("textarea", {
                                    id: "message",
                                    name: "message",
                                    value: s.message,
                                    onChange: v,
                                    placeholder: "Your message...",
                                    rows: 5,
                                    required: !0
                                })]
                            }), u.jsx("button", {
                                type: "submit",
                                className: "btn-primary",
                                disabled: l,
                                children: l ? "Sending..." : "Send Message"
                            })]
                        }), u.jsx("div", {
                            className: "form-note",
                            children: u.jsx("p", {
                                children: "* Required fields"
                            })
                        })]
                    })]
                })
            })
        })]
    })
}

function cb() {
    const [s, a] = Xe.useState("home"), l = () => {
        switch (s) {
            case "home":
                return u.jsx(Wf, {
                    onNavigate: a
                });
            case "about":
                return u.jsx(wv, {});
            case "goals":
                return u.jsx(xv, {});
            case "achievements":
                return u.jsx(Ev, {});
            case "events":
                return u.jsx(Tv, {});
            case "join":
                return u.jsx(sb, {});
            case "donations":
                return u.jsx(lb, {});
            case "gallery":
                return u.jsx(rb, {});
            case "governance":
                return u.jsx(ob, {});
            case "contact":
                return u.jsx(ub, {});
            default:
                return u.jsx(Wf, {
                    onNavigate: a
                })
        }
    };
    return u.jsxs("div", {
        className: "app",
        children: [u.jsx(jv, {
            currentPage: s,
            onNavigate: a
        }), u.jsx("main", {
            children: l()
        }), u.jsx(Sv, {
            onNavigate: a
        })]
    })
}
_v.createRoot(document.getElementById("root")).render(u.jsx(dv.StrictMode, {
    children: u.jsx(cb, {})
}));